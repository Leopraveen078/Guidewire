"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { BillingScenarios } from "../../../ui/actions/bc/scenarios/BillingScenarios.js";

const billingScenarios = new BillingScenarios();

When(/^I make down payment$/, async function (t, stepArguments) {
   
});

When(/^I make 1st Installment payment$/, async function (t, stepArguments) {
   
});

When(/^I make 2nd Installment payment$/, async function (t, stepArguments) {
   
});

When(/^I make 3rd Installment payment$/, async function (t, stepArguments) {
   
});


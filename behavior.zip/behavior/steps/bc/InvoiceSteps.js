"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { AccountScenarios } from "../../../ui/actions/bc/scenarios/AccountScenarios.js";
import { InvoicePage } from "../../../ui/actions/bc/scenarios/InvoicePage.js";
import { DetailsPage } from "../../../ui/actions/bc/scenarios/DetailsPage.js";
import { BatchProcessScenarios } from "../../../ui/actions/bc/scenarios/BatchProcessScenario.js";
import { PaymentScenarios } from "../../../ui/actions/bc/scenarios/PaymentScenarios.js";
import { WindowNavigation_Ext } from "../../../ui/actions/gw/WindowNavigation_Ext.js"
import { LoginPage } from "../../../ui/pages/gw/generated/LoginPage.js";

const bcAccountScenarios = new AccountScenarios();
const invoicePage = new InvoicePage();
const detailspage = new DetailsPage();
const batchProcessScenarios = new BatchProcessScenarios();
const bcPaymentScenarios = new PaymentScenarios();
const windowNavigation_Ext = new WindowNavigation_Ext();
const loginPage = new LoginPage();


Then(/^I verify the policy (.*) cancellation reflecting on billing center$/, async function (t, stepArguments) {
    let cancellationType = stepArguments[0];

    // switch to BC window, since its already opened for PC-Policy Issuance
    await windowNavigation_Ext.switchToBCWindow(t.ctx.htmlReport);
    await windowNavigation_Ext.windowRefresh(t.ctx.htmlReport);
    await windowNavigation_Ext.windowRefresh(t.ctx.htmlReport);
    if (await loginPage.loginPage_username_TextBox.component.visible) {
        console.log("LOGIN PAGE APPEARED, RELOGGING...");
        await windowNavigation_Ext.loginToBillingCenter(t.ctx.htmlReport, "controller");
    }

    await bcAccountScenarios.openAccount(t.ctx.htmlReport, t.ctx.accountNumber);
    await invoicePage.openInvoices(t.ctx.htmlReport);
    await invoicePage.checkFullPayPolicyCancelledInvoice(t.ctx.htmlReport, cancellationType);
});

Then(/^I verify the invoice details for Billed$/, async function (t) {

    // switch to BC window, since its already opened for PC-Policy Issuance
    await windowNavigation_Ext.switchToBCWindow(t.ctx.htmlReport);
    await windowNavigation_Ext.windowRefresh(t.ctx.htmlReport);
    await windowNavigation_Ext.windowRefresh(t.ctx.htmlReport);
    if (await loginPage.loginPage_username_TextBox.component.visible) {
        console.log("LOGIN PAGE APPEARED, RELOGGING...");
        await windowNavigation_Ext.loginToBillingCenter(t.ctx.htmlReport, "controller");
    }

    await bcAccountScenarios.openAccount(t.ctx.htmlReport, t.ctx.accountNumber);
    await invoicePage.openInvoices(t.ctx.htmlReport);
    await invoicePage.checkStatusAndDueColumnIndex(0, 'Billed', '-', t.ctx.htmlReport);
    await detailspage.reversePaymentAction(t.ctx.htmlReport, t.ctx.testData);
    await invoicePage.openInvoices(t.ctx.htmlReport);
    await invoicePage.checkStatusAndDueAndAmount(0, 'Billed', t.ctx.htmlReport);
    await bcAccountScenarios.openAccount(t.ctx.htmlReport, t.ctx.accountNumber);
    await bcPaymentScenarios.makePayment(t.ctx.htmlReport, t.ctx.amount);
    await bcPaymentScenarios.verifyPaidAmountOnAccountSummary(t.ctx.htmlReport, t.ctx.amount);
});
"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { BatchProcessScenarios } from "../../../ui/actions/bc/scenarios/BatchProcessScenario.js";

const batchProcessScenarios = new BatchProcessScenarios();

When(/^I run BC (.*) batch process$/, async function (t, stepArguments) {
    let batchName = stepArguments[0];
    await batchProcessScenarios.runBatchProcess(t.ctx.htmlReport, batchName);
});


"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { CheckPage } from "../../../ui/actions/cc/scenarios/CheckPage";

let checkPage = new CheckPage();

Given(/^I search for a check with its (.*)$/, async function (t, stepArguments) {
  const identifier = stepArguments[0];

  if (identifier == "Claim Number") {
    await checkPage.searchCheckByClaimNumber(data.claimNumber);
  }
  else if (identifier == "Invoice Number") {
    await checkPage.searchCheckByInvoiceNumber(data.invoiceNumber);
  }
});

Then(/^the check was found$/, async function () {
  await checkPage.findCheckWithClaimNumberExists(data.claimNumber);
});
"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { ClaimPage } from "../../../ui/actions/cc/scenarios/ClaimPage.js";
import { RecoveryPage } from "../../../ui/actions/cc/scenarios/Recoverypage"
import { t } from "testcafe";

let claimPage = new ClaimPage();
let recoveryPage = new RecoveryPage();

Given(/^with a recovery$/, async function () {
  await claimPage.openClaim();
  await recoveryPage.createRecovery();
});

When(/^I search for the recovery$/, async function () {
  await recoveryPage.navigateToSearchRecoveriesPage();
  await recoveryPage.searchRecoveryByClaimNumber();
});

Then(/^the recovery is found$/, async function () {
  let resultCount = await recoveryPage.getRecoverySearchResultCount();
  await t.expect(resultCount).eql(1);
});
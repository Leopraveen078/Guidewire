"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { ContactPage } from "../../../ui/actions/cc/scenarios/ContactPage.js";

let contactPage = new ContactPage();

When(/^I search for a known contact in the Global Address Box with their (.*)$/, async function (t, stepArguments) {
  let identifier = stepArguments[0]
  await contactPage.searchForContact(identifier);
});

Then(/^the contact is found$/, async function () {
  await contactPage.verifyContactFound();
})

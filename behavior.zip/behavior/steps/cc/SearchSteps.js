"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { SearchPage } from "../../../ui/actions/cc/scenarios/SearchPage.js";

let searchPage = new SearchPage();

When(/^I search for the policy using the Policy Number$/, async function () {
  await searchPage.searchForPolicy();
});

Then(/^I could find the policy$/, async function () {
  await searchPage.findPolicyWithPolicyNumberExists();
})
Then(/^I could find the policy$/, async function () {
  await searchPage.findPolicyWithPolicyNumberExists();
})
Then(/^I verify Claim Search under search Claim Page$/, async function (t) {
  await searchAccountsPage.verifySearchAccountsPageAccountSearch(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^I verify Claim Search under Claim menu dropdown$/, async function (t) {
  await searchAccountsPage.verifyAccountMenuAccountSearch(t.ctx.htmlReport);
});

Then(/^I search for a Claim by (.*) as (.*),(.*),(.*)$/, async function (t, stepArguments) {

  var featureData = {
      searchPolicyBy: [
          {
              Identifier: stepArguments[0],
              First_Name: stepArguments[1],
              Last_Name: stepArguments[2],
              Zip_Code: stepArguments[3],
              ClaimNumber: "",
          }
      ]
  }
  console.log(featureData)
  Object.assign(t.ctx.testData, featureData)
  console.log(Object.assign(t.ctx.testData, featureData));
  if (featureData.searchPolicyBy != "") {
      for (let iteration = 0; iteration < featureData.searchPolicyBy.length; iteration++) {
          await searchPage.searchForPolicy(t.ctx.htmlReport, t.ctx.testData, iteration);
      }
  }
});


"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { SearchPage } from "../../../ui/actions/cc/scenarios/SearchPage.js";
import { CloseClaimPage } from "../../../ui/actions/cc/scenarios/CloseClaimPage.js";
import { t } from "testcafe";

let searchPage = new SearchPage();
let closeClaimPage = new CloseClaimPage(); 

Then(/^I do a Close Claim$/, async function () {
    await searchPage.SearchByClaimNumber(t.ctx.htmlReport, t.ctx.claimNumber ); 
    await closeClaimPage.handleMandatoryClaimActivities(t.ctx.htmlReport, t.ctx.testData);
    await closeClaimPage.navigateToCloseClaim(t.ctx.htmlReport); 
    await closeClaimPage.initiateCloseClaim(t.ctx.htmlReport, t.ctx.testData);
    await closeClaimPage.verifyClaimCloseStatus(t.ctx.htmlReport, 'Closed');
});
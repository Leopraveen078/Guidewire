"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { SelectPolicyPage } from "../../../ui/actions/cc/scenarios/SelectPolicyPage"
import { BasicInfoPage } from "../../../ui/actions/cc/scenarios/BasicInfoPage";
import { SummaryPage } from "../../../ui/actions/cc/scenarios/SummaryPage";
import { ClaimPage } from "../../../ui/actions/cc/scenarios/ClaimPage";
import { SaveAndAssignClaimPage } from "../../../ui/actions/cc/scenarios/SaveAndAssignClaimPage"
import { t } from "testcafe";

let selectPolicyPage = new SelectPolicyPage();
let basicInfoPage = new BasicInfoPage();
let saveAndAssignClaimPage = new SaveAndAssignClaimPage();
let summaryPage = new SummaryPage();
let claimPage = new ClaimPage();

Then(/^I create a claim$/, async function () {
  await claimPage.initiateClaim(t.ctx.htmlReport);
  await selectPolicyPage.selectPolicyWithLossData(t.ctx.htmlReport, t.ctx.testData);
  await basicInfoPage.enterBasicInformationDetails(t.ctx.htmlReport, t.ctx.testData);
  await saveAndAssignClaimPage.saveAndAssignClaim(t.ctx.htmlReport, t.ctx.testData);
  await claimPage.viewCreatedClaim(t.ctx.htmlReport);
  await summaryPage.expectedFNOLReserve(t.ctx.htmlReport, t.ctx.testData);

});


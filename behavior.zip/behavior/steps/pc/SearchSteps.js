'use strict';
const { Given, When, Then, After } = require('@cucumber/cucumber');

import { ContactSearchPage } from "../../../ui/actions/pc/ootb/scenarios/Search/ContactSearchPage";
import { SearchPoliciesPage } from "../../../ui/actions/pc/ootb/scenarios/Search/SearchPoliciesPage";
import { SearchAccountsPage } from "../../../ui/actions/pc/ootb/scenarios/Search/SearchAccountsPage";

let contactSearchPage = new ContactSearchPage();
let searchPoliciesPage = new SearchPoliciesPage();
let searchAccountsPage = new SearchAccountsPage();

Given(/^I search for a Person contact by First and Last Name as '(.*)','(.*)'$/, async function (t, stepArguments) {
    var featureData = {
        searchContactBy: [
            {
                type: "Person",
                firstName: stepArguments[0],
                lastName: stepArguments[1],
            }
        ]
    }
    Object.assign(t.ctx.testData, featureData)
    await contactSearchPage.searchForContact(t.ctx.htmlReport, t.ctx.testData);
});

When(/^I search for a (.*) contact by TaxID as '(.*)'$/, async function (t, stepArguments) {
    var featureData = {
        searchContactBy: [
            {
                type: stepArguments[0],
                taxId: stepArguments[1]
            }
        ]
    }
    Object.assign(t.ctx.testData, featureData)
    await contactSearchPage.searchForContact(t.ctx.htmlReport, t.ctx.testData)
});

When(/^I search for a Company contact by Name as '(.*)'$/, async function (t, stepArguments) {
    var featureData = {
        searchContactBy: [
            {
                type: "Company",
                name: stepArguments[0]
            }
        ]
    }
    Object.assign(t.ctx.testData, featureData)
    await contactSearchPage.searchForContact(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^I search for a Policy by (.*) as (.*),(.*),(.*)$/, async function (t, stepArguments) {

    var featureData = {
        searchPolicyBy: [
            {
                Identifier: stepArguments[0],
                First_Name: stepArguments[1],
                Last_Name: stepArguments[2],
                Zip_Code: stepArguments[3],
                AccountNumber: "",
                PolicyNumber: ""
            }
        ]
    }
    console.log(featureData)
    Object.assign(t.ctx.testData, featureData)
    console.log(Object.assign(t.ctx.testData, featureData));
    if (featureData.searchPolicyBy != "") {
        for (let iteration = 0; iteration < featureData.searchPolicyBy.length; iteration++) {
            await searchPoliciesPage.searchForPolicy(t.ctx.htmlReport, t.ctx.testData, iteration);
        }
    }
});

Then(/^I search for a AccountNumber by (.*) as (.*),(.*),(.*)$/, async function (t, stepArguments) {

    var featureData = {
        searchPolicyBy: [
            {
                Identifier: stepArguments[0],
                First_Name: stepArguments[1],
                Last_Name: stepArguments[2],
                Zip_Code: stepArguments[3],
                AccountNumber: "",
                PolicyNumber: ""
            }
        ]
    }
    console.log(featureData)
    Object.assign(t.ctx.testData, featureData)
    console.log(Object.assign(t.ctx.testData, featureData));
    if (featureData.searchPolicyBy != "") {
        for (let iteration = 0; iteration < featureData.searchPolicyBy.length; iteration++) {
            await searchPoliciesPage.searchForAccount(t.ctx.htmlReport, t.ctx.testData, iteration);
        }
    }
});

Then(/^I verify Account Search under Search Accounts Page$/, async function (t) {
    await searchAccountsPage.verifySearchAccountsPageAccountSearch(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^I verify Account Search under Account menu dropdown$/, async function (t) {
    await searchAccountsPage.verifyAccountMenuAccountSearch(t.ctx.htmlReport);
});

Then(/^I verify Policy Search under Search Policy Page$/, async function (t) {
    await searchPoliciesPage.verifySearchPolicyPagePolicySearch(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^I verify Policy Search under Policy menu dropdown$/, async function (t) {
    await searchPoliciesPage.verifyPolicyMenuPolicySearch(t.ctx.htmlReport);
});

Then(/^I select PolicyTapbar and enter the existing a Policy number$/, async function (t) {
    for (let iteration = 0; iteration < t.ctx.testData.searchPolicyBy.length; iteration++) {
        await searchPoliciesPage.PolicysearchTab(t.ctx.htmlReport, t.ctx.testData, iteration);
    }
});

Then(/^I select claimTapbar and enter the existing a claim number$/, async function (t) {
    for (let iteration = 0; iteration < t.ctx.testData.searchPolicyBy.length; iteration++) {
        await searchPoliciesPage.PolicysearchTab(t.ctx.htmlReport, t.ctx.testData, iteration);
    }

});

Then(/^Verify retrieval of Account and Policy number after Search from Search Policy Screen$/, async function (t) {
    await searchPoliciesPage.confirmPolicySearchResults(t.ctx.htmlReport, t.ctx.testData);
});



Then(/^the contact was found$/, async function (t) {
    await contactSearchPage.checkContactSearchResult(t.ctx.htmlReport);
});

Then(/^the policy was found$/, async function (t) {
    await searchPoliciesPage.checkPolicySearchResult(t.ctx.htmlReport);
});




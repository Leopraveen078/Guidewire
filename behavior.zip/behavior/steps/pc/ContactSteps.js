'use strict';
const { Given, When, Then, After } = require('@cucumber/cucumber');
const { NewContactPage } = require('../../../ui/actions/pc/ootb/scenarios/Contact/NewContactPage');


let newContactPage = new NewContactPage();

Given(/^I create a Person Contact with First name as '(.*)', Last name as '(.*)' and TaxId as '(.*)'$/, async function (t, stepArguments) {
    var featureData = {
        newContact: [
            {
                type: "Person",
                firstName: stepArguments[0],
                lastName: stepArguments[1],
                taxId: stepArguments[2]
            }
        ]
    }
    Object.assign(t.ctx.testData, featureData)
    await newContactPage.createNewContact(t.ctx.htmlReport, t.ctx.testData);
});

Given(/^I create a Company Contact with Name as '(.*)' and TaxId as '(.*)'$/, async function (t, stepArguments) {
    var featureData = {
        newContact: [
            {
                type: "Company",
                name: stepArguments[0],
                taxId: stepArguments[1]
            }
        ]
    }
    Object.assign(t.ctx.testData, featureData)
    await newContactPage.createNewContact(t.ctx.htmlReport, t.ctx.testData);
});


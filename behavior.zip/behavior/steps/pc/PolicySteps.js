"use strict";
const { When, Then } = require("@cucumber/cucumber");

import { AccountSummaryPage } from "../../../ui/actions/pc/ootb/scenarios/Account/AccountSummaryPage";
import { NewSubmissionsPage } from "../../../ui/actions/pc/ootb/scenarios/Policy/NewSubmissionsPage.js";
import { PolicyTypeQuestionsPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Home/PolicyTypeQuestionsPage.js";
import { EligibilityQuestionsPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Home/EligibilityQuestionsPage.js";
import { PolicyInfoPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Common/PolicyInfoPage.js";
import { PropertyAddressPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Home/PropertyAddressPage.js";
import { CoveragesPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Home/CoveragesPage.js";
import { DwellingPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Home/DwellingPage.js";
import { DwellingConstructionPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Home/DwellingConstructionPage.js";
import { PolicyReviewPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Common/PolicyReviewPage.js";
import { PremiumEstimatePage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Common/PremiumEstimatePage.js";
import { PaymentPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Common/PaymentPage.js";
import { RequiredDocumentsPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Common/RequiredDocumentsPage.js"
import { SubmissionBoundPage } from "../../../ui/actions/pc/ootb/scenarios/LOBWizardStepGroup/Common/SubmissionBoundPage.js";
import { AccountScenarios } from "../../../ui/actions/bc/scenarios/AccountScenarios.js";
import { InvoicePage } from "../../../ui/actions/bc/scenarios/InvoicePage.js";
import { PaymentScenarios } from "../../../ui/actions/bc/scenarios/PaymentScenarios.js";
import { WindowNavigation_Ext } from "../../../ui/actions/gw/WindowNavigation_Ext.js";
import { BatchProcessScenarios } from "../../../ui/actions/bc/scenarios/BatchProcessScenario.js";
import { LoginPage } from "../../../ui/pages/gw/generated/LoginPage.js";

const bcAccountScenarios = new AccountScenarios();
const bcInvoiceScenarios = new InvoicePage();
const bcPaymentScenarios = new PaymentScenarios();
const batchProcessScenarios = new BatchProcessScenarios();
const accountSummaryPage = new AccountSummaryPage();
const newSubmissionsPage = new NewSubmissionsPage();
const policyTypeQuestionsPage = new PolicyTypeQuestionsPage();
const eligibilityQuestionsPage = new EligibilityQuestionsPage();
const policyInfoPage = new PolicyInfoPage();
const propertyAddressPage = new PropertyAddressPage();
const coveragesPage = new CoveragesPage()
const dwellingPage = new DwellingPage();
const dwellingConstructionPage = new DwellingConstructionPage();
const policyReviewPage = new PolicyReviewPage();
const premiumEstimatePage = new PremiumEstimatePage();
const paymentPage = new PaymentPage();
const submissionBoundPage = new SubmissionBoundPage();
const windowNavigation_Ext = new WindowNavigation_Ext();
const requiredDocumentsPage = new RequiredDocumentsPage();
const loginPage = new LoginPage();

Then(/^I create a (.*) (.*) policy$/, async function (t, stepArguments) {
    let productType = stepArguments[1];
    console.log("Product Type -- " + productType);

    let policyType = ""
    if (stepArguments[0] === 'PL') {
        policyType = "Personal Residential";
    } else if (stepArguments[0] === 'CL') {
        policyType = "Commercial Residential";
    } else {
        policyType = "INVALID POLICY TYPE KEYWORD ON FEATURE FILE"
    }
    console.log("Policy Type -- " + policyType);

    await accountSummaryPage.clickNewSubmission(t.ctx.htmlReport);
    await newSubmissionsPage.initiateNewSubmission(t.ctx.htmlReport, t.ctx.testData, policyType);
    await policyTypeQuestionsPage.enterPolicyTypeQuestionsDetails(t.ctx.htmlReport, t.ctx.testData);
    await eligibilityQuestionsPage.enterEligibilityQuestionsDetails(t.ctx.htmlReport, t.ctx.testData);
    await policyInfoPage.enterPolicyInfoDetails(t.ctx.htmlReport, t.ctx.testData);
    await propertyAddressPage.enterPropertyAddressDetails(t.ctx.htmlReport, t.ctx.testData)
    await coveragesPage.enterCoveragesDetails(t.ctx.htmlReport, t.ctx.testData);
    await dwellingPage.enterDwellingDetails(t.ctx.htmlReport, t.ctx.testData);
    await dwellingConstructionPage.enterDwellingConstructionDetails(t.ctx.htmlReport, t.ctx.testData);
    await premiumEstimatePage.enterPremiumEstimateDetails(t.ctx.htmlReport, t.ctx.testData);
    await paymentPage.enterPaymentDetails(t.ctx.htmlReport, t.ctx.testData);
    await requiredDocumentsPage.enterRequiredDocuments(t.ctx.htmlReport, t.ctx.testData);
    await windowNavigation_Ext.openNewBCWindow(t.ctx.htmlReport);
    await windowNavigation_Ext.loginToBillingCenter(t.ctx.htmlReport, "controller");
    await bcAccountScenarios.openAccount(t.ctx.htmlReport, t.ctx.accountNumber);
    await bcInvoiceScenarios.checkDownPaymentInvoiceStatusAndAmount(t.ctx.htmlReport, 'Planned');
    await batchProcessScenarios.runBatchProcess(t.ctx.htmlReport, 'Invoice')
    await bcPaymentScenarios.verifyDownPaymentStatus(t.ctx.htmlReport, t.ctx.accountNumber, 'Billed');
    await bcPaymentScenarios.makePayment(t.ctx.htmlReport, t.ctx.amount);
    await bcPaymentScenarios.verifyPaidAmountOnAccountSummary(t.ctx.htmlReport, t.ctx.amount);
    await windowNavigation_Ext.switchToPCWindow(t.ctx.htmlReport);
    await windowNavigation_Ext.windowRefresh(t.ctx.htmlReport);
    if (await loginPage.loginPage_username_TextBox.component.visible) {
        console.log("LOGIN PAGE APPEARED, RELOGGING...");
        await windowNavigation_Ext.loginToPolicyCenter(t.ctx.htmlReport, "underwriter");
    }
    await paymentPage.issuePolicy(t.ctx.htmlReport);
    await submissionBoundPage.viewPolicyDetails(t.ctx.htmlReport, t.ctx.testData);
});

When(/^I create a CL CRM policy$/, async function (t) {
    await accountSummaryPage.clickNewSubmission(t.ctx.htmlReport);
    await newSubmissionsPage.initiateNewSubmission(t.ctx.htmlReport, t.ctx.testData, "Commercial Residential");
});

When(/^I bind the submission$/, async function (t) {
    await policyReviewPage.clickQuoteInPolicyReview(t.ctx.htmlReport, t.ctx.testData);
    await quotePage.clickNextInQuotesPage(t.ctx.htmlReport);
    await formsPage.clickNextInFormsPage(t.ctx.htmlReport);
    await paymentPage.bindOnly(t.ctx.htmlReport, t.ctx.testData);
});

When(/^I issue the submission$/, async function (t) {
    await policyReviewPage.clickQuoteInPolicyReview(t.ctx.htmlReport, t.ctx.testData);
    await quotePage.clickNextInQuotesPage(t.ctx.htmlReport);
    await formsPage.clickNextInFormsPage(t.ctx.htmlReport);
    await paymentPage.enterDetailsAndIssuePolicy(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^the submission should be quoted$/, async function (t) {
    await quotePage.assertSubmissionQuoted(t.ctx.htmlReport);
});

Then(/^the submission should be bound$/, async function (t) {
    await submissionBoundPage.assertSubmissionBound(t.ctx.htmlReport);
});

When(/^I save the submission to draft$/, async function (t) {
    await policyReviewPage.saveSubmissionInDraft(t.ctx.htmlReport);
});

Then(/^the submission is in (.*) status$/, async function (t, stepArguments) {
    let expSubmissionStatus = stepArguments[0];
    await policyReviewPage.assertSubmssionStatus(t.ctx.htmlReport, expSubmissionStatus)
});



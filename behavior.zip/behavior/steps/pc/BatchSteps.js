"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { BatchProcessScenarios } from "../../../ui/actions/pc/ootb/scenarios/Other/BatchProcessScenario";

const batchProcessScenarios = new BatchProcessScenarios();

When(/^I run PC (.*) batch process$/, async function (t, stepArguments) {
    let batchName = stepArguments[0];
    await batchProcessScenarios.runBatchProcess(t.ctx.htmlReport, batchName);
});


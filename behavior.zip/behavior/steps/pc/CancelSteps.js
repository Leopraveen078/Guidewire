"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { TabBarScenarios } from "../../../ui/actions/pc/ootb/scenarios/Navigation/TabBarScenarios";
import { CancelPolicyPage } from "../../../ui/actions/pc/ootb/scenarios/Policy/CancelPolicyPage";


let tabBarScenarios = new TabBarScenarios();
let cancelPolicyPage = new CancelPolicyPage();

Then(/^I cancel the policy as Flat$/, async function (t) {
    await tabBarScenarios.searchByPolicyNumber(t.ctx.htmlReport, t.ctx.policyNumber);
    await cancelPolicyPage.navigateToCancelPolicy(t.ctx.htmlReport);
    await cancelPolicyPage.cancelPolicy(t.ctx.htmlReport, t.ctx.testData, 'flat');
    await cancelPolicyPage.viewAndVerifyPolicyCancelled(t.ctx.htmlReport);
});

Then(/^I cancel the policy as Pro rata$/, async function (t) {
    await tabBarScenarios.searchByPolicyNumber(t.ctx.htmlReport, t.ctx.policyNumber);
    await cancelPolicyPage.navigateToCancelPolicy(t.ctx.htmlReport);
    await cancelPolicyPage.cancelPolicy(t.ctx.htmlReport, t.ctx.testData, 'prorata');
    await cancelPolicyPage.viewAndVerifyPolicyCancelled(t.ctx.htmlReport);
});

Then(/^I schedule the policy cancellation$/, async function (t) {
    await tabBarScenarios.searchByPolicyNumber(t.ctx.htmlReport, t.ctx.policyNumber);
    await cancelPolicyPage.navigateToCancelPolicy(t.ctx.htmlReport);
    await cancelPolicyPage.cancelPolicy(t.ctx.htmlReport, t.ctx.testData, 'prorata');
    await cancelPolicyPage.viewAndVerifyPolicyCancellationScheduled(t.ctx.htmlReport);
});

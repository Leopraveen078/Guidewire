"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { RewritePolicyPage } from "../../../ui/actions/pc/ootb/scenarios/Policy/RewritePolicyPage.js";
import { TabBarScenarios } from "../../../ui/actions/pc/ootb/scenarios/Navigation/TabBarScenarios";
import { RewriteBoundPage } from "../../../ui/actions/pc/ootb/scenarios/Policy/RewriteBoundPage.js";

const rewritePolicyPage = new RewritePolicyPage();
const tabBarScenarios = new TabBarScenarios();
const rewriteBoundPage = new RewriteBoundPage();



Then(/^I do a policy rewrite transaction$/, async function (t) {

    await tabBarScenarios.searchByPolicyNumber(t.ctx.htmlReport, t.ctx.policyNumber);
    await rewritePolicyPage.navigateToRewritePolicy(t.ctx.htmlReport);
    await rewritePolicyPage.handlePolicyRewriteAcrossScreens(t.ctx.htmlReport, t.ctx.testData);
    await rewritePolicyPage.finalizePolicyRewrite(t.ctx.htmlReport);
    await rewriteBoundPage.viewYourRewritePolicy(t.ctx.htmlReport);

});




"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { RenewalRenewingPage } from "../../../ui/actions/pc/ootb/scenarios/Policy/RenewalRenewingPage";
import { RenewPolicyPage } from "../../../ui/actions/pc/ootb/scenarios/Policy/RenewPolicyPage";
import { WindowNavigation_Ext } from "../../../ui/actions/gw/WindowNavigation_Ext";
import { TabBarScenarios } from "../../../ui/actions/pc/ootb/scenarios/Navigation/TabBarScenarios";
import { LoginPage } from "../../../ui/pages/gw/generated/LoginPage.js";

const renewPolicyPage = new RenewPolicyPage();
const renewalRenewingPage = new RenewalRenewingPage();
const windowNavigation_Ext = new WindowNavigation_Ext();
const tabBarScenarios = new TabBarScenarios();
const loginPage = new LoginPage();

When(/^I do the Manual Renewal$/, async function (t) {

});

When(/^I run the batch process for the Automatic Renewal$/, async function (t) {
    await batchProcessScenarios.runRenewalBatchProcess(t.ctx.htmlReport);
});

Then(/^Policy should be successfully renewed$/, async function (t) {
    await renewalBoundPage.verifyRenewalBound(t.ctx.htmlReport)
});

Then(/^Policy should be Automatically renewed$/, async function (t) {
    await tabBarScenarios.searchByPolicyNumber(t.ctx.htmlReport, t.ctx.policyNumber);
    await policySummaryPage.navigateToPolicyTransactions(t.ctx.htmlReport);
    await policyTransactionPage.assertPolicyIsRenewed(t.ctx.htmlReport);
});

Then(/^I renew the Policy$/, async function (t) {
  
    // handling if involved multiple centers being accessed earlier
    await windowNavigation_Ext.switchToPCWindow(t.ctx.htmlReport);
    await windowNavigation_Ext.windowRefresh(t.ctx.htmlReport);
    if (await loginPage.loginPage_username_TextBox.component.visible) {
        console.log("LOGIN PAGE APPEARED, RELOGGING...");
        await windowNavigation_Ext.loginToPolicyCenter(t.ctx.htmlReport, "underwriter");
    }
    
    await tabBarScenarios.searchByPolicyNumber(t.ctx.htmlReport, t.ctx.policyNumber)
    await renewPolicyPage.navigateToRenewalPolicy(t.ctx.htmlReport);
    await renewPolicyPage.initiaterenewalPolicy(t.ctx.htmlReport);
    await renewPolicyPage.viewAndVerifyPolicyRenewed(t.ctx.htmlReport)

});
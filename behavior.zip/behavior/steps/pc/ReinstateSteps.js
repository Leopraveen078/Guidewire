"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { TabBarScenarios } from "../../../ui/actions/pc/ootb/scenarios/Navigation/TabBarScenarios";
import { ReinstatePolicyPage } from "../../../ui/actions/pc/ootb/scenarios/Policy/ReinstatePolicyPage";
import { WindowNavigation_Ext } from "../../../ui/actions/gw/WindowNavigation_Ext";
import { LoginPage } from "../../../ui/pages/gw/generated/LoginPage.js";


let tabBarScenarios = new TabBarScenarios();
let reinstatePolicyPage = new ReinstatePolicyPage();
let windowNavigation_Ext = new WindowNavigation_Ext();
const loginPage = new LoginPage();

Then(/^I reinstate the policy$/, async function (t) {

    // switch to BC window, since its already opened for PC-Policy Issuance
    await windowNavigation_Ext.switchToPCWindow(t.ctx.htmlReport);
    await windowNavigation_Ext.windowRefresh(t.ctx.htmlReport);
    await windowNavigation_Ext.windowRefresh(t.ctx.htmlReport);
    if (await loginPage.loginPage_username_TextBox.component.visible) {
        console.log("LOGIN PAGE APPEARED, RELOGGING...");
        await windowNavigation_Ext.loginToPolicyCenter(t.ctx.htmlReport, "underwriter");
    }
    await tabBarScenarios.searchByPolicyNumber(t.ctx.htmlReport, t.ctx.policyNumber);
    await reinstatePolicyPage.navigateToReinstatePolicy(t.ctx.htmlReport);
    await reinstatePolicyPage.reinstatePolicy(t.ctx.htmlReport, t.ctx.testData);
    await reinstatePolicyPage.viewAndVerifyPolicyReinstated(t.ctx.htmlReport);
});


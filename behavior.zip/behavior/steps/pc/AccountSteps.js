'use strict';
const { Given, When, Then, After } = require('@cucumber/cucumber');
import { TabBarScenarios } from "../../../ui/actions/pc/ootb/scenarios/Navigation/TabBarScenarios.js";
import { CreateAccountPage } from "../../../ui/actions/pc/ootb/scenarios/Account/CreateAccountPage.js";
import { SearchAccountsPage } from "../../../ui/actions/pc/ootb/scenarios/Search/SearchAccountsPage.js";
import { AccountSummaryPage } from "../../../ui/actions/pc/ootb/scenarios/Account/AccountSummaryPage.js";
import { NewNotePage } from "../../../ui/actions/pc/ootb/scenarios/Other/NewNotePage.js";
import { AccountFileNotesPage } from "../../../ui/actions/pc/ootb/scenarios/Account/AccountFileNotes.js";

const tabBarScenarios = new TabBarScenarios();
const createAccountPage = new CreateAccountPage();
const searchAccountsPage = new SearchAccountsPage();
const accountSummaryPage = new AccountSummaryPage();
const newNotePage = new NewNotePage();
const accountFileNotesPage = new AccountFileNotesPage();

Then(/^I create a PL account$/, async function (t) {
    await tabBarScenarios.clickNewAccount(t.ctx.htmlReport);
    await createAccountPage.newAccountCreation(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^I select account and enter the existing  a PL account number$/, async function (t) {
    await tabBarScenarios.searchByAccountNumber(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^Verify whether Account details are retrieved succesfully$/, async function (t) {
    await tabBarScenarios.verifyAccountSummaryWithAccountnumber(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^I select search then click Account from the list$/, async function (t) {
    await tabBarScenarios.selectSearchAccounts(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^Verify retrival of Account number after  click of Search_button from Account_search screen$/, async function (t) {
    await tabBarScenarios.verifyAccountNumberOnSearchWindow(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^I create a CL account$/, async function (t) {
    await tabBarScenarios.clickNewAccount(t.ctx.htmlReport);
    await createAccountPage.newAccountCreation(t.ctx.htmlReport, t.ctx.testData);
});

When(/^I search for the account by the account holder's name$/, async function (t) {
    await tabBarScenarios.selectSearchAccounts(t.ctx.htmlReport);
    await searchAccountsPage.searchAccounts(t.ctx.htmlReport, t.ctx.testData);
});

Then(/^the account is found$/, async function (t) {
    await searchAccountsPage.verifyAccountExists(t.ctx.htmlReport);
});

Then(/^An activity - '(.*)' is added to the account$/, async function (t, stepArguments, dataTable) {
    let activityDetails = dataTable.rowsHash();
    let featureParam = {
        activityCategory: activityDetails.activityCategory,
        activity: stepArguments[0]
    }
    await accountSummaryPage.createNewActivity(t.ctx.htmlReport, featureParam);
});

Then(/^the '(.*)' is in the Account's Current Activities$/, async function (t, stepArguments) {
    let featureParam = {
        activity: stepArguments[0]
    }
    await accountSummaryPage.verifyAddedActivity(t.ctx.htmlReport, featureParam);
});

Then(/^A note - '(.*)' is added to the account$/, async function (t, stepArguments, dataTable) {
    let noteDetails = dataTable.rowsHash();
    let featureParam = {
        newNoteTopic: noteDetails.noteTopic,
        newNoteText: stepArguments[0]
    }
    await accountSummaryPage.clickNewNote(t.ctx.htmlReport);
    await newNotePage.addNote(t.ctx.htmlReport, featureParam);
});

Then(/^I can view the account note - '(.*)'$/, async function (t, stepArguments) {
    let featureParam = {
        newNoteText: stepArguments[0]
    }
    await accountSummaryPage.navigateToNotesPage(t.ctx.htmlReport);
    await accountFileNotesPage.searchAndVerifyAddedNotes(t.ctx.htmlReport, featureParam);
});

Then(/^I view account summary$/, async function (t) {
    await accountSummaryPage.confirmPageNavigation(t.ctx.htmlReport);
});

"use strict";
const { Given, When, Then } = require("@cucumber/cucumber");
import { TabBarScenarios } from "../../../ui/actions/pc/ootb/scenarios/Navigation/TabBarScenarios";
import { PolicyChangeBoundPage } from "../../../ui/actions/pc/ootb/scenarios/Policy/PolicyChangeBoundPage";
import { PolicyChangePage } from "../../../ui/actions/pc/ootb/scenarios/Policy/PolicyChangePage";


let tabBarScenarios = new TabBarScenarios();
let changePolicyPage = new PolicyChangePage();
let policyChangeBoundPage = new PolicyChangeBoundPage();

When(/^I change policy$/, async function (t) {
    await tabBarScenarios.searchByPolicyNumber(t.ctx.htmlReport, t.ctx.policyNumber);
    await changePolicyPage.navigateToPolicyChange(t.ctx.htmlReport, t.ctx.testData);
    await changePolicyPage.initiatePolicyChange(t.ctx.htmlReport, t.ctx.testData);
    await changePolicyPage.coverageIncreasePolicyChange(t.ctx.htmlReport, t.ctx.testData)
    await changePolicyPage.issueChangePolicy(t.ctx.htmlReport, t.ctx.testData)
    await policyChangeBoundPage.viewYourChangedPolicy(t.ctx.htmlReport);

});




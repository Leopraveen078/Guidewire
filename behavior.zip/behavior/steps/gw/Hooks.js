'use strict';
const { Given, After, Then } = require('@cucumber/cucumber');
import HtmlReport from '../../../ui/util/common/htmlReport';

//Initialize TestData and Creating HTML header
Given(/^(.*) scenario being initialized$/, async function (t, stepArguments) {
    console.log(`Initializing Scenario - `+stepArguments[0])
    let testCaseParam = {
        TC_NAME: stepArguments[0]
    };
    console.log(`Browser & OS: ${t.browser.prettyUserAgent}`)

    // loading TestData
    t.ctx.testData = require('../../../ui/testData/'+testCaseParam.TC_NAME+'.js')
    // loading html report
    t.ctx.htmlReport = new HtmlReport(testCaseParam, "", t.browser.prettyUserAgent)
    // loading testcase name
    t.ctx.testcaseName = testCaseParam.TC_NAME
    await t.ctx.htmlReport.createHeader(testCaseParam.TC_NAME)
    
});

// Report closure
After({name: "TestRun Closure"}, async function (t) {
    console.log(`TestRun Closure`)
    await t.wait(3000)
    await t.ctx.htmlReport.insertHtmlRow("", "", "Test Run Ended", "");
    await t.ctx.htmlReport.addFooter();
});

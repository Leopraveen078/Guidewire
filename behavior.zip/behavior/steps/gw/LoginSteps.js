'use strict';
const { Given, When, Then, And, After } = require('@cucumber/cucumber');
import { LoginScenario_Ext } from '../../../ui/actions/gw/LoginScenario_Ext.js'
import { onApp } from "../../../ui/pages/gw/registry/onApp.js";
import { ClientFunction, t } from "testcafe";
import { WindowNavigation_Ext } from '../../../ui/actions/gw/WindowNavigation_Ext';
import { Application_Ext } from '../../../ui/actions/gw/Application_Ext.js';

const onPCApp = new onApp("PC");
const onBCApp = new onApp("BC");
const onCCApp = new onApp("CC");
const onCMApp = new onApp("CM");
const loginScenario_ext = new LoginScenario_Ext();
const windowNavigation_Ext = new WindowNavigation_Ext();
const application_Ext = new Application_Ext();


Given(/^I login to (.*) as a Super user$/, async function (t, stepArguments) {
    var featureData = {
        app: stepArguments[0]
    }

    // setting onApp..
    if (featureData.app.includes('PC')) {
        console.log('Loading up onPCApp...');
        await onPCApp.navigateToApp();
    } else if (featureData.app.includes('BC')) {
        console.log('Loading up onBCApp...');
        await onBCApp.navigateToApp();
    } else if (featureData.app.includes('CC')) {
        console.log('Loading up onCCApp...');
        await onCCApp.navigateToApp();
    } else if (featureData.app.includes('CM')) {
        console.log('Loading up onCMApp...');
        await onCMApp.navigateToApp();
    }

    await loginScenario_ext.loginWithDefaultUser_ext(t.ctx.htmlReport, featureData);

    // save Window
    if (featureData.app.includes('PC')) {
        t.ctx.pcWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('BC')) {
        t.ctx.bcWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('CC')) {
        t.ctx.ccWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('CM')) {
        t.ctx.cmWindow = await t.getCurrentWindow();
    }

    await application_Ext.saveEnv();
    await application_Ext.saveApplicationDate(t.ctx.htmlReport);

});

When(/^I login as a (.*) user with (.*) role$/, async function (t, stepArguments) {
    
    let featureData = {
        app: stepArguments[0],
        role: stepArguments[1]
    }

    // setting onApp..
    if (featureData.app.includes('PC')) {
        console.log('Loading up onPCApp...');
        await onPCApp.navigateToApp();
    } else if (featureData.app.includes('BC')) {
        console.log('Loading up onBCApp...');
        await onBCApp.navigateToApp();
    } else if (featureData.app.includes('CC')) {
        console.log('Loading up onCCApp...');
        await onCCApp.navigateToApp();
    } else if (featureData.app.includes('CM')) {
        console.log('Loading up onCMApp...');
        await onCMApp.navigateToApp();
    }

    await loginScenario_ext.loginWithRole_ext(t.ctx.htmlReport, featureData);

    // save Window
    if (featureData.app.includes('PC')) {
        t.ctx.pcWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('BC')) {
        t.ctx.bcWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('CC')) {
        t.ctx.ccWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('CM')) {
        t.ctx.cmWindow = await t.getCurrentWindow();
    }

    await application_Ext.saveEnv(t.ctx.htmlReport);
    await application_Ext.saveApplicationDate(t.ctx.htmlReport);

});


When(/^I launch (.*) on another window and login as (.*) role$/, async function (t, stepArguments) {
    let featureData = {
        app: stepArguments[0],
        role: stepArguments[1]
    }

    console.log(`Opening new window`)
    await windowNavigation_Ext.openNewWindow(t.ctx.htmlReport);

    // setting onApp..
    if (featureData.app.includes('PC')) {
        console.log('Loading up onPCApp...');
        await onPCApp.navigateToApp();
    } else if (featureData.app.includes('BC')) {
        console.log('Loading up onBCApp...');
        await onBCApp.navigateToApp();
    } else if (featureData.app.includes('CC')) {
        console.log('Loading up onCCApp...');
        await onCCApp.navigateToApp();
    } else if (featureData.app.includes('CM')) {
        console.log('Loading up onCMApp...');
        await onCMApp.navigateToApp();
    }

    await loginScenario_ext.loginWithRole_ext(t.ctx.htmlReport, featureData);

    // save Window
    if (featureData.app.includes('PC')) {
        t.ctx.pcWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('BC')) {
        t.ctx.bcWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('CC')) {
        t.ctx.ccWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('CM')) {
        t.ctx.cmWindow = await t.getCurrentWindow();
    }

});

Given(/^I am a (.*) user$/, async function (t, stepArguments) {
    let featureData = {
        app: stepArguments[0]
    }

    // setting onApp..
    if (featureData.app.includes('PC')) {
        console.log('Loading up onPCApp...');
        await onPCApp.navigateToApp();
    } else if (featureData.app.includes('BC')) {
        console.log('Loading up onBCApp...');
        await onBCApp.navigateToApp();
    } else if (featureData.app.includes('CC')) {
        console.log('Loading up onCCApp...');
        await onCCApp.navigateToApp();
    } else if (featureData.app.includes('CM')) {
        console.log('Loading up onCMApp...');
        await onCMApp.navigateToApp();
    }

    await loginScenario_ext.loginWithUser_ext(t.ctx.htmlReport, featureData.app);

    // save Window
    if (featureData.app.includes('PC')) {
        t.ctx.pcWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('BC')) {
        t.ctx.bcWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('CC')) {
        t.ctx.ccWindow = await t.getCurrentWindow();
    } else if (featureData.app.includes('CM')) {
        t.ctx.cmWindow = await t.getCurrentWindow();
    }

    await application_Ext.saveEnv();
    await application_Ext.saveApplicationDate(t.ctx.htmlReport);

});

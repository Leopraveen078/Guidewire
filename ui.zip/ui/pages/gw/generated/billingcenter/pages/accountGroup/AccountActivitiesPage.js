import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class AccountActivitiesPage {
	accountActivitiesPageAccountActivitiesPage_UpLink = PcfButton('#AccountActivitiesPage-AccountActivitiesPage_UpLink');
	accountActivitiesPageAccountActivitySubtypesFilter = PcfSelectInput('#AccountActivitiesPage-AccountActivitySubtypesFilter');
	accountActivitiesPageActivityFilter = PcfSelectInput('#AccountActivitiesPage-ActivityFilter');
	accountActivitiesPageActivityPattern = PcfSelectInput('#AccountActivitiesPage-ActivityPattern');
	accountActivitiesPageCreateDateHeader = PcfButton('#AccountActivitiesPage-CreateDateHeader');
	accountActivitiesPageEscalatedHeader = PcfButton('#AccountActivitiesPage-EscalatedHeader');
	accountActivitiesPage_ListPaging = PcfButton('#AccountActivitiesPage-_ListPaging');
	accountActivitiesPage_Paging = PcfButton('#AccountActivitiesPage-_Paging');
	accountActivitiesPage__crumb__ = PcfComponent('#AccountActivitiesPage-__crumb__');
	accountActivitiesPage_msgs = PcfButton('#AccountActivitiesPage-_msgs');
	accountActivitiesPageassignedToHeader = PcfButton('#AccountActivitiesPage-assignedToHeader');
	accountActivitiesPageduedateHeader = PcfButton('#AccountActivitiesPage-duedateHeader');
	accountActivitiesPagepriorityHeader = PcfButton('#AccountActivitiesPage-priorityHeader');
	accountActivitiesPagestatusHeader = PcfButton('#AccountActivitiesPage-statusHeader');
	accountActivitiesPagesubjectHeader = PcfButton('#AccountActivitiesPage-subjectHeader');
}

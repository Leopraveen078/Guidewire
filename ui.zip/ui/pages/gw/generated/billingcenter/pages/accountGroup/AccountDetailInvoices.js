import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class AccountDetailInvoices {
	accountDetailInvoicesScreenAccountDetailInvoices_InvoiceTotalAmount = PcfComponent("#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-AccountInvoicesLV-AmountFooter");
	accountDetailInvoicesScreenAccountDetailInvoices_InvoiceNumberSortUpIcon = PcfComponent("#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-AccountInvoicesLV-InvoiceNumberHeader_toggleSort > div.gw-sort-icon--up");
	accountDetailInvoicesScreenAccountDetailInvoices_InvoiceSentAlertBar = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-AccountDetailInvoices_InvoiceSentAlertBar');
	accountDetailInvoices_InvoiceSentAlertBarCloseBtn = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-AccountDetailInvoices_InvoiceSentAlertBar-CloseBtn');
	detailPanelAccountInvoicesLV = PcfListView('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-AccountInvoicesLV');
	accountInvoicesLV_tbAccountDetailInvoices_NewInvoiceButton = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-AccountInvoicesLV_tb-AccountDetailInvoices_NewInvoiceButton');
	accountInvoicesLV_tbAccountDetailInvoices_PaymentArrangementButton_acc = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-AccountInvoicesLV_tb-AccountDetailInvoices_PaymentArrangementButton_acc');
	accountInvoicesLV_tbAccountDetailInvoices_RemoveInvoicesButton = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-AccountInvoicesLV_tb-AccountDetailInvoices_RemoveInvoicesButton');
	accountInvoicesLV_tbInvoiceStreamFilter = PcfSelectInput('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-AccountInvoicesLV_tb-InvoiceStreamFilter');
	accountInvoicesLV_tbprint = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-AccountInvoicesLV_tb-print');
	detailPanelInvoiceDetailCardTab = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailCardTab');
	accountInvoiceInformationInputSetAdHoc = PcfComponent('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV-AccountInvoiceInformationInputSet-AdHoc');
	accountInvoiceInformationInputSetInvoiceDate = PcfDateValueInput('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV-AccountInvoiceInformationInputSet-InvoiceDate');
	accountInvoiceInformationInputSetPaymentDueDate = PcfDateValueInput('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV-AccountInvoiceInformationInputSet-PaymentDueDate');
	accountInvoiceInformationInputSetStatus = PcfTextInput('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV-AccountInvoiceInformationInputSet-Status');
	invoiceDetailDVPriorAmountDue = PcfTextInput('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV-PriorAmountDue');
	invoiceDetailDVTotalAmountDue = PcfTextInput('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV-TotalAmountDue');
	invoiceDetailDVTotalCharges = PcfTextInput('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV-TotalCharges');
	invoiceDetailDV_tbCancel = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV_tb-Cancel');
	invoiceDetailDV_tbEdit = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV_tb-Edit');
	invoiceDetailDV_tbInvoiceDetailDV_ResendInvoice = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV_tb-InvoiceDetailDV_ResendInvoice');
	invoiceDetailDV_tbUpdate = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceDetailDV_tb-Update');
	detailPanelInvoiceItemsLV = PcfListView('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceItemsLV');
	invoiceItemsLV_tbAggregationTypeSelector = PcfSelectInput('#AccountDetailInvoices-AccountDetailInvoicesScreen-DetailPanel-InvoiceItemsLV_tb-AggregationTypeSelector');
	accountDetailInvoicesScreen_msgs = PcfButton('#AccountDetailInvoices-AccountDetailInvoicesScreen-_msgs');
	accountDetailInvoicesAccountDetailInvoices_UpLink = PcfButton('#AccountDetailInvoices-AccountDetailInvoices_UpLink');
	accountDetailInvoices_Paging = PcfButton('#AccountDetailInvoices-_Paging');
	accountDetailInvoices__crumb__ = PcfComponent('#AccountDetailInvoices-__crumb__');
	accountDetailInvoices_AccountDetailInvoicesScreen_ttlBar = PcfComponent('#AccountDetailInvoices-AccountDetailInvoicesScreen-ttlBar');
	
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class Ext {
	cSRSummaryScreenAccountDetailSummary_DelinquencyAlertAlertBar = PcfButton('#CSRSummary_Ext-CSRSummaryScreen-AccountDetailSummary_DelinquencyAlertAlertBar');
	cSRSummary_ExtCSRSummaryScreenAccountDetailSummary_DelinquencyAlertAlertBarCloseBtn = PcfButton('#CSRSummary_Ext-CSRSummaryScreen-AccountDetailSummary_DelinquencyAlertAlertBar-CloseBtn');
	cSRSummaryScreenAccountNumber = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-AccountNumber');
	cSRSummaryScreenBillingType = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-BillingType');
	cSRSummaryScreenBillsRemaining = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-BillsRemaining');
	cSRSummaryScreenCSRSummaryTransactionsLV = PcfListView('#CSRSummary_Ext-CSRSummaryScreen-CSRSummaryTransactionsLV');
	cSRSummaryTransactionsLV_tbPolicyFilter = PcfSelectInput('#CSRSummary_Ext-CSRSummaryScreen-CSRSummaryTransactionsLV_tb-PolicyFilter');
	cSRSummaryScreenLastInvAmount = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-LastInvAmount');
	cSRSummaryScreenNextInvoiceAmount = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-NextInvoiceAmount');
	cSRSummaryScreenNextInvoiceDate = PcfDateValueInput('#CSRSummary_Ext-CSRSummaryScreen-NextInvoiceDate');
	cSRSummaryScreenOutstandingAmount = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-OutstandingAmount');
	cSRSummaryScreenPrimaryPayer = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-PrimaryPayer');
	cSRSummaryScreenSuspenseAmount = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-SuspenseAmount');
	cSRSummaryScreenTotalCurrentlyBilled = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-TotalCurrentlyBilled');
	cSRSummaryScreenTotalPastDue = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-TotalPastDue');
	cSRSummaryScreenTotalUnbilled = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-TotalUnbilled');
	cSRSummaryScreenUnappliedAmount = PcfTextInput('#CSRSummary_Ext-CSRSummaryScreen-UnappliedAmount');
	cSRSummaryScreen_msgs = PcfButton('#CSRSummary_Ext-CSRSummaryScreen-_msgs');
	cSRSummary_ExtCSRSummary_Ext_UpLink = PcfButton('#CSRSummary_Ext-CSRSummary_Ext_UpLink');
	cSRSummary_Ext_Paging = PcfButton('#CSRSummary_Ext-_Paging');
	cSRSummary_Ext__crumb__ = PcfComponent('#CSRSummary_Ext-__crumb__');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class DesktopFundsTracking {
	desktopFundsTrackingCoastaltoCLA = PcfTextInput('#DesktopFundsTracking-CoastaltoCLA');
	desktopFundsTrackingCoastaltopla = PcfTextInput('#DesktopFundsTracking-Coastaltopla');
	desktopFundsTrackingDesktopFundsTracking_UpLink = PcfButton('#DesktopFundsTracking-DesktopFundsTracking_UpLink');
	desktopFundsTrackingPrintDepositSlipToolbarButton = PcfButton('#DesktopFundsTracking-PrintDepositSlipToolbarButton');
	desktopFundsTrackingToolbarButton = PcfButton('#DesktopFundsTracking-ToolbarButton');
	desktopFundsTracking_Paging = PcfButton('#DesktopFundsTracking-_Paging');
	desktopFundsTracking__crumb__ = PcfComponent('#DesktopFundsTracking-__crumb__');
	desktopFundsTracking_msgs = PcfButton('#DesktopFundsTracking-_msgs');
	desktopFundsTrackingallocationDetailsLV = PcfListView('#DesktopFundsTracking-allocationDetailsLV');
	desktopFundsTrackingclatoCoastal = PcfTextInput('#DesktopFundsTracking-clatoCoastal');
	desktopFundsTrackingclatopla = PcfTextInput('#DesktopFundsTracking-clatopla');
	desktopFundsTrackingdate = PcfDateValueInput('#DesktopFundsTracking-date');
	desktopFundsTrackingdatejump = PcfTextInput('#DesktopFundsTracking-datejump');
	desktopFundsTrackingnoData = PcfButton('#DesktopFundsTracking-noData');
	noDataCloseBtn = PcfButton('#DesktopFundsTracking-noData-CloseBtn');
	desktopFundsTrackingplatoCoastal = PcfTextInput('#DesktopFundsTracking-platoCoastal');
	desktopFundsTrackingplatocla = PcfTextInput('#DesktopFundsTracking-platocla');
}

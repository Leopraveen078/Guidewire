import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class DesktopEscheatments {
	desktopEscheatmentsDesktopEscheatments_UpLink = PcfButton('#DesktopEscheatments-DesktopEscheatments_UpLink');
	desktopEscheatments_Paging = PcfButton('#DesktopEscheatments-_Paging');
	desktopEscheatments__crumb__ = PcfComponent('#DesktopEscheatments-__crumb__');
	desktopEscheatments_msgs = PcfButton('#DesktopEscheatments-_msgs');
	escheatmentSearchDVCheckNumberCriterion = PcfTextInput('#DesktopEscheatments-escheatSeach-EscheatmentSearchDV-CheckNumberCriterion');
	escheatmentSearchDVEarliestIssueDateCriterion = PcfDateValueInput('#DesktopEscheatments-escheatSeach-EscheatmentSearchDV-EarliestIssueDateCriterion');
	escheatmentSearchDVLatestIssueDateCriterion = PcfDateValueInput('#DesktopEscheatments-escheatSeach-EscheatmentSearchDV-LatestIssueDateCriterion');
	escheatmentSearchDVPayeeCriterion = PcfTextInput('#DesktopEscheatments-escheatSeach-EscheatmentSearchDV-PayeeCriterion');
	policyNumberCriterionSelectPolicyNumberCriterion = PcfButton('#DesktopEscheatments-escheatSeach-EscheatmentSearchDV-PolicyNumberCriterion-SelectPolicyNumberCriterion');
	desktopEscheatmentsescheatSeachEscheatmentSearchDVSearchAndResetInputSetSearchLinksInputSetReset = PcfButton('#DesktopEscheatments-escheatSeach-EscheatmentSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Reset');
	desktopEscheatmentsescheatSeachEscheatmentSearchDVSearchAndResetInputSetSearchLinksInputSetSearch = PcfButton('#DesktopEscheatments-escheatSeach-EscheatmentSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Search');
	escheatmentSearchDVStatusCriterion = PcfSelectInput('#DesktopEscheatments-escheatSeach-EscheatmentSearchDV-StatusCriterion');
	escheatmentSearchDVSubtypeCriterion = PcfSelectInput('#DesktopEscheatments-escheatSeach-EscheatmentSearchDV-SubtypeCriterion');
	escheatmentSearchDVUWCompany = PcfSelectInput('#DesktopEscheatments-escheatSeach-EscheatmentSearchDV-UWCompany');
	escheatSeachEscheatmentSearchResultsLV = PcfListView('#DesktopEscheatments-escheatSeach-EscheatmentSearchResultsLV');
	escheatmentSearchResultsLV_tbprint = PcfButton('#DesktopEscheatments-escheatSeach-EscheatmentSearchResultsLV_tb-print');
	escheatmentSearchResultsLV_tbreverse = PcfButton('#DesktopEscheatments-escheatSeach-EscheatmentSearchResultsLV_tb-reverse');
}

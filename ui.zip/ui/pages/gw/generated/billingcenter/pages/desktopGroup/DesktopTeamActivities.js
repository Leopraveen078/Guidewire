import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class DesktopTeamActivities {
	desktopTeamActivitiesDesktopActivitiesScreenAccount = PcfTextInput('#DesktopTeamActivities-DesktopActivitiesScreen-Account');
	desktopTeamActivitiesDesktopActivitiesScreenDesktopActivitiesLV = PcfListView('#DesktopTeamActivities-DesktopActivitiesScreen-DesktopActivitiesLV');
	desktopTeamActivitiesDesktopActivitiesScreenDesktopActivities_AssignButton = PcfButton('#DesktopTeamActivities-DesktopActivitiesScreen-DesktopActivities_AssignButton');
	desktopTeamActivitiesDesktopActivitiesScreen_msgs = PcfButton('#DesktopTeamActivities-DesktopActivitiesScreen-_msgs');
	desktopTeamActivitiesDesktopTeamActivities_UpLink = PcfButton('#DesktopTeamActivities-DesktopTeamActivities_UpLink');
	desktopTeamActivities_Paging = PcfButton('#DesktopTeamActivities-_Paging');
	desktopTeamActivities__crumb__ = PcfComponent('#DesktopTeamActivities-__crumb__');
}

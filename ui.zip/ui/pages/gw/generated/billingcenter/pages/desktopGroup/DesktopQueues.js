import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class DesktopQueues {
	activityLVRefActivityLV = PcfListView('#DesktopQueues-ActivityLVRef-ActivityLV');
	activityLV_tbAvailableQueues = PcfSelectInput('#DesktopQueues-ActivityLVRef-ActivityLV_tb-AvailableQueues');
	activityLV_tbDesktopActivities_AssignButton = PcfButton('#DesktopQueues-ActivityLVRef-ActivityLV_tb-DesktopActivities_AssignButton');
	activityLV_tbNextItemButton = PcfButton('#DesktopQueues-ActivityLVRef-ActivityLV_tb-NextItemButton');
	activityLV_tbassigneSelectedBtn = PcfButton('#DesktopQueues-ActivityLVRef-ActivityLV_tb-assigneSelectedBtn');
	desktopQueuesDesktopQueues_UpLink = PcfButton('#DesktopQueues-DesktopQueues_UpLink');
	desktopQueues_Paging = PcfButton('#DesktopQueues-_Paging');
	desktopQueues__crumb__ = PcfComponent('#DesktopQueues-__crumb__');
	desktopQueues_msgs = PcfButton('#DesktopQueues-_msgs');
}

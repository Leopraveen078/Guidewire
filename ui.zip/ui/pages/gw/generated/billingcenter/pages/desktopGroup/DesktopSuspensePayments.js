import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class DesktopSuspensePayments {
	desktopSuspensePaymentsScreenCreateDisbursement = PcfButton('#DesktopSuspensePayments-DesktopSuspensePaymentsScreen-CreateDisbursement');
	desktopSuspensePaymentsScreenCurrencyToUse = PcfSelectInput('#DesktopSuspensePayments-DesktopSuspensePaymentsScreen-CurrencyToUse');
	desktopSuspensePaymentsScreenDesktopSuspensePaymentsLV = PcfListView('#DesktopSuspensePayments-DesktopSuspensePaymentsScreen-DesktopSuspensePaymentsLV');
	desktopSuspensePaymentsScreenNewPayment = PcfButton('#DesktopSuspensePayments-DesktopSuspensePaymentsScreen-NewPayment');
	desktopSuspensePaymentsScreenReverseSuspensePayments = PcfButton('#DesktopSuspensePayments-DesktopSuspensePaymentsScreen-ReverseSuspensePayments');
	desktopSuspensePaymentsScreenSearchValue = PcfTextInput('#DesktopSuspensePayments-DesktopSuspensePaymentsScreen-SearchValue');
	desktopSuspensePaymentsScreen_msgs = PcfButton('#DesktopSuspensePayments-DesktopSuspensePaymentsScreen-_msgs');
	desktopSuspensePaymentsDesktopSuspensePayments_UpLink = PcfButton('#DesktopSuspensePayments-DesktopSuspensePayments_UpLink');
	desktopSuspensePayments_Paging = PcfButton('#DesktopSuspensePayments-_Paging');
	desktopSuspensePayments__crumb__ = PcfComponent('#DesktopSuspensePayments-__crumb__');
}

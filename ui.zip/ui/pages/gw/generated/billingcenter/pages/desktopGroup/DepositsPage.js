import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class DepositsPage {
	depositsPageDepositsPage_UpLink = PcfButton('#DepositsPage-DepositsPage_UpLink');
	depositsScreenBatchDescTextInput = PcfTextInput('#DepositsPage-DepositsScreen-BatchDescTextInput');
	depositsScreenBatchesCardTab = PcfButton('#DepositsPage-DepositsScreen-BatchesCardTab');
	depositsScreenDepositBatchesLV = PcfListView('#DepositsPage-DepositsScreen-DepositBatchesLV');
	depositBatchesLV_tbAdd = PcfButton('#DepositsPage-DepositsScreen-DepositBatchesLV_tb-Add');
	depositBatchesLV_tbRemove = PcfButton('#DepositsPage-DepositsScreen-DepositBatchesLV_tb-Remove');
	depositsScreenDepositDate = PcfDateValueInput('#DepositsPage-DepositsScreen-DepositDate');
	depositsScreenDepositDetailsCardTab = PcfButton('#DepositsPage-DepositsScreen-DepositDetailsCardTab');
	depositsScreenDepositID = PcfTextInput('#DepositsPage-DepositsScreen-DepositID');
	depositsScreenDepositPaymentsLV = PcfListView('#DepositsPage-DepositsScreen-DepositPaymentsLV');
	depositPaymentsLV_tbAdd = PcfButton('#DepositsPage-DepositsScreen-DepositPaymentsLV_tb-Add');
	depositPaymentsLV_tbRemove = PcfButton('#DepositsPage-DepositsScreen-DepositPaymentsLV_tb-Remove');
	depositsScreenDepositStatusTypeKeyInput = PcfSelectInput('#DepositsPage-DepositsScreen-DepositStatusTypeKeyInput');
	depositsScreenDepositsLV = PcfListView('#DepositsPage-DepositsScreen-DepositsLV');
	depositsLV_tbAdd = PcfButton('#DepositsPage-DepositsScreen-DepositsLV_tb-Add');
	depositsLV_tbCancel = PcfButton('#DepositsPage-DepositsScreen-DepositsLV_tb-Cancel');
	depositsLV_tbEdit = PcfButton('#DepositsPage-DepositsScreen-DepositsLV_tb-Edit');
	depositsLV_tbPrintDepositSlipToolbarButton = PcfButton('#DepositsPage-DepositsScreen-DepositsLV_tb-PrintDepositSlipToolbarButton');
	depositsLV_tbPrintDepositSummaryToolbarButton = PcfButton('#DepositsPage-DepositsScreen-DepositsLV_tb-PrintDepositSummaryToolbarButton');
	depositsLV_tbRemove = PcfButton('#DepositsPage-DepositsScreen-DepositsLV_tb-Remove');
	depositsLV_tbUpdate = PcfButton('#DepositsPage-DepositsScreen-DepositsLV_tb-Update');
	depositsScreenPaymentsCardTab = PcfButton('#DepositsPage-DepositsScreen-PaymentsCardTab');
	depositsScreen_msgs = PcfButton('#DepositsPage-DepositsScreen-_msgs');
	depositsScreenbatchescount = PcfTextInput('#DepositsPage-DepositsScreen-batchescount');
	depositsScreendeposittotal = PcfTextInput('#DepositsPage-DepositsScreen-deposittotal');
	depositsScreentotalitems = PcfTextInput('#DepositsPage-DepositsScreen-totalitems');
	depositsPage_Paging = PcfButton('#DepositsPage-_Paging');
	depositsPage__crumb__ = PcfComponent('#DepositsPage-__crumb__');
}

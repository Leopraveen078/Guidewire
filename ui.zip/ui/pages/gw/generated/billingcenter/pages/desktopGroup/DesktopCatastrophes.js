import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class DesktopCatastrophes {
	desktopCatastrophesDesktopCatastrophes_UpLink = PcfButton('#DesktopCatastrophes-DesktopCatastrophes_UpLink');
	desktopCatastrophesToolbarButton = PcfButton('#DesktopCatastrophes-ToolbarButton');
	desktopCatastrophes_ListPaging = PcfButton('#DesktopCatastrophes-_ListPaging');
	desktopCatastrophes_Paging = PcfButton('#DesktopCatastrophes-_Paging');
	desktopCatastrophes__crumb__ = PcfComponent('#DesktopCatastrophes-__crumb__');
	desktopCatastrophes_msgs = PcfButton('#DesktopCatastrophes-_msgs');
	desktopCatastrophescancelHeader = PcfTextInput('#DesktopCatastrophes-cancelHeader');
	desktopCatastrophesreleaseDateHeader = PcfButton('#DesktopCatastrophes-releaseDateHeader');
	desktopCatastrophesstatusFilter = PcfSelectInput('#DesktopCatastrophes-statusFilter');
	desktopCatastrophesstatusHeader = PcfButton('#DesktopCatastrophes-statusHeader');
	desktopCatastrophessubjectHeader = PcfButton('#DesktopCatastrophes-subjectHeader');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class DesktopBulkWriteoff {
	desktopBulkWriteoffDesktopBulkWriteoff_UpLink = PcfButton('#DesktopBulkWriteoff-DesktopBulkWriteoff_UpLink');
	desktopBulkWriteoffToolbarButton = PcfButton('#DesktopBulkWriteoff-ToolbarButton');
	desktopBulkWriteoff_ListPaging = PcfButton('#DesktopBulkWriteoff-_ListPaging');
	desktopBulkWriteoff_Paging = PcfButton('#DesktopBulkWriteoff-_Paging');
	desktopBulkWriteoff__crumb__ = PcfComponent('#DesktopBulkWriteoff-__crumb__');
	desktopBulkWriteoff_msgs = PcfButton('#DesktopBulkWriteoff-_msgs');
	desktopBulkWriteoffasofdateHeader = PcfButton('#DesktopBulkWriteoff-asofdateHeader');
	desktopBulkWriteoffcancelHeader = PcfTextInput('#DesktopBulkWriteoff-cancelHeader');
	desktopBulkWriteoffprocessedDateHeader = PcfButton('#DesktopBulkWriteoff-processedDateHeader');
	desktopBulkWriteoffstatus = PcfSelectInput('#DesktopBulkWriteoff-status');
	desktopBulkWriteoffstatusHeader = PcfButton('#DesktopBulkWriteoff-statusHeader');
	desktopBulkWriteofftotalnbrpolciesHeader = PcfButton('#DesktopBulkWriteoff-totalnbrpolciesHeader');
	desktopBulkWriteofftotalwrittenoffHeader = PcfButton('#DesktopBulkWriteoff-totalwrittenoffHeader');
}

import { PcfComponent } from '@gtui/gt-ui-framework';

export class AccountsGroupMenuActions {
	accountsMenuActionsAccountsMenuActions_NewAccount = PcfComponent('#AccountsGroup-AccountsMenuActions-AccountsMenuActions_NewAccount');
	accountsGroupAccountsMenuActions = PcfComponent('#AccountsGroup-AccountsMenuActions');
}

import { PcfComponent } from '@gtui/gt-ui-framework';

export class ProducersGroupMenuActions {
	producersGroupProducersMenuActions = PcfComponent('#ProducersGroup-ProducersMenuActions');
	producersMenuActionsProducersMenuActions_NewIRSOffice = PcfComponent('#ProducersGroup-ProducersMenuActions-ProducersMenuActions_NewIRSOffice');
	producersMenuActionsProducersMenuActions_NewProducer = PcfComponent('#ProducersGroup-ProducersMenuActions-ProducersMenuActions_NewProducer');
}

import { PcfComponent } from '@gtui/gt-ui-framework';

export class DesktopGroupMenuLinks {
	menuLinksDesktopGroup_BatchesPage = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_BatchesPage');
	menuLinksDesktopGroup_DepositsPage = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DepositsPage');
	menuLinksDesktopGroup_DesktopActivities = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopActivities');
	menuLinksDesktopGroup_DesktopAgencyItems = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopAgencyItems');
	menuLinksDesktopGroup_DesktopApprovals = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopApprovals');
	menuLinksDesktopGroup_DesktopBatchPaymentsSearch = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopBatchPaymentsSearch');
	menuLinksDesktopGroup_DesktopBulkWriteoff = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopBulkWriteoff');
	menuLinksDesktopGroup_DesktopCatastrophes = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopCatastrophes');
	menuLinksDesktopGroup_DesktopDelinquencies = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopDelinquencies');
	menuLinksDesktopGroup_DesktopDisbursements = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopDisbursements');
	menuLinksDesktopGroup_DesktopEscheatments = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopEscheatments');
	menuLinksDesktopGroup_DesktopFundsTracking = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopFundsTracking');
	menuLinksDesktopGroup_DesktopHeldCharges = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopHeldCharges');
	menuLinksDesktopGroup_DesktopQueues = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopQueues');
	menuLinksDesktopGroup_DesktopSuspensePayments = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopSuspensePayments');
	menuLinksDesktopGroup_DesktopTeamActivities = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopTeamActivities');
	menuLinksDesktopGroup_DesktopTroubleTickets = PcfComponent('#DesktopGroup-MenuLinks-DesktopGroup_DesktopTroubleTickets');
	desktopGroupMenuLinks = PcfComponent('#DesktopGroup-MenuLinks');
}

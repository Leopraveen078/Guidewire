import { PcfComponent } from '@gtui/gt-ui-framework';

export class DesktopGroupMenuActions {
	desktopMenuActionsDesktopMenuActions_NewBatchPayment = PcfComponent('#DesktopGroup-DesktopMenuActions-DesktopMenuActions_NewBatchPayment');
	desktopMenuActions_NewPaymentDesktopMenuActions_MultiPaymentEntryWizard = PcfComponent('#DesktopGroup-DesktopMenuActions-DesktopMenuActions_NewPayment-DesktopMenuActions_MultiPaymentEntryWizard');
	desktopMenuActions_NewPaymentDesktopMenuActions_NewSuspensePayment = PcfComponent('#DesktopGroup-DesktopMenuActions-DesktopMenuActions_NewPayment-DesktopMenuActions_NewSuspensePayment');
	desktopMenuActionsDesktopMenuActions_NewPayment = PcfComponent('#DesktopGroup-DesktopMenuActions-DesktopMenuActions_NewPayment');
	desktopMenuActionsDesktopMenuActions_UserPreferences = PcfComponent('#DesktopGroup-DesktopMenuActions-DesktopMenuActions_UserPreferences');
	desktopGroupDesktopMenuActions = PcfComponent('#DesktopGroup-DesktopMenuActions');
	desktopMenuActionsNewAssignedActivity = PcfComponent('#DesktopGroup-DesktopMenuActions-NewAssignedActivity');
	desktopMenuActionsNewCrossCenterActivity = PcfComponent('#DesktopGroup-DesktopMenuActions-NewCrossCenterActivity');
	desktopMenuActionsNewSharedActivity = PcfComponent('#DesktopGroup-DesktopMenuActions-NewSharedActivity');
}

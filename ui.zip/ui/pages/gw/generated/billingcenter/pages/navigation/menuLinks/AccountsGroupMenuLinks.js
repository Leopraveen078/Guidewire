import { PcfComponent } from '@gtui/gt-ui-framework';

export class AccountsGroupMenuLinks {
	menuLinksAccountsGroup_Accounts = PcfComponent('#AccountsGroup-MenuLinks-AccountsGroup_Accounts');
	accountsGroupMenuLinks = PcfComponent('#AccountsGroup-MenuLinks');
}

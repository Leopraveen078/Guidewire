import { PcfComponent } from '@gtui/gt-ui-framework';

export class ServerToolsMenuActions {
	serverToolsInternalToolsMenuActions = PcfComponent('#ServerTools-InternalToolsMenuActions');
	internalToolsMenuActionsInternalToolsMenuActions_Logout = PcfComponent('#ServerTools-InternalToolsMenuActions-InternalToolsMenuActions_Logout');
	internalToolsMenuActionsReturnToApp = PcfComponent('#ServerTools-InternalToolsMenuActions-ReturnToApp');
	internalToolsMenuActionsadminDataLoader = PcfComponent('#ServerTools-InternalToolsMenuActions-adminDataLoader');
	internalToolsMenuActionsglMappingDataLoader = PcfComponent('#ServerTools-InternalToolsMenuActions-glMappingDataLoader');
	internalToolsMenuActionsmortgageeDataLoader = PcfComponent('#ServerTools-InternalToolsMenuActions-mortgageeDataLoader');
	internalToolsMenuActionsplanDataLoader = PcfComponent('#ServerTools-InternalToolsMenuActions-planDataLoader');
	internalToolsMenuActionssampleDataLoader = PcfComponent('#ServerTools-InternalToolsMenuActions-sampleDataLoader');
}

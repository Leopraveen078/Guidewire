import { PcfComponent } from '@gtui/gt-ui-framework';

export class PoliciesGroupMenuLinks {
	policiesGroupMenuLinks = PcfComponent('#PoliciesGroup-MenuLinks');
	menuLinksPoliciesGroup_Policies = PcfComponent('#PoliciesGroup-MenuLinks-PoliciesGroup_Policies');
}

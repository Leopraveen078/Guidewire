import { PcfComponent } from '@gtui/gt-ui-framework';

export class ReportTabBar {
	tabBarReportTab = PcfComponent('#TabBar-ReportTab');
	tabBarWidgetmoreoptions = PcfComponent('#TabBarWidget--more-options');
}

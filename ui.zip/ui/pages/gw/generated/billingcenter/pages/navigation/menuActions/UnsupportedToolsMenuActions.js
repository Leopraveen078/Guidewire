import { PcfComponent } from '@gtui/gt-ui-framework';

export class UnsupportedToolsMenuActions {
	unsupportedToolsInternalToolsMenuActions = PcfComponent('#UnsupportedTools-InternalToolsMenuActions');
	unsupportedToolsInternalToolsMenuActionsInternalToolsMenuActions_Logout = PcfComponent('#UnsupportedTools-InternalToolsMenuActions-InternalToolsMenuActions_Logout');
	unsupportedToolsInternalToolsMenuActionsReturnToApp = PcfComponent('#UnsupportedTools-InternalToolsMenuActions-ReturnToApp');
	unsupportedToolsInternalToolsMenuActionsadminDataLoader = PcfComponent('#UnsupportedTools-InternalToolsMenuActions-adminDataLoader');
	unsupportedToolsInternalToolsMenuActionsglMappingDataLoader = PcfComponent('#UnsupportedTools-InternalToolsMenuActions-glMappingDataLoader');
	unsupportedToolsInternalToolsMenuActionsmortgageeDataLoader = PcfComponent('#UnsupportedTools-InternalToolsMenuActions-mortgageeDataLoader');
	unsupportedToolsInternalToolsMenuActionsplanDataLoader = PcfComponent('#UnsupportedTools-InternalToolsMenuActions-planDataLoader');
	unsupportedToolsInternalToolsMenuActionssampleDataLoader = PcfComponent('#UnsupportedTools-InternalToolsMenuActions-sampleDataLoader');
}

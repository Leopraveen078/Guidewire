import { PcfComponent } from '@gtui/gt-ui-framework';

export class AcceleratedMenuActionsAcceleratedMenuActions {
	policyDetailAcceleratedMenuActionsPolicyGroup_EffectiveDate = PcfComponent('#PolicyGroup-PolicyDetailAcceleratedMenuActions-PolicyGroup_EffectiveDate');
	policyGroup_EffectiveDatePolicyGroup_EffectiveDate_Arg = PcfComponent('#PolicyGroup-PolicyDetailAcceleratedMenuActions-PolicyGroup_EffectiveDate-PolicyGroup_EffectiveDate_Arg');
	acceleratedMenuActionsgetId = PcfComponent('#AcceleratedMenuActions.getId()');
}

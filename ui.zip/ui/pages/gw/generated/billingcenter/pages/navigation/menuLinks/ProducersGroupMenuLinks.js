import { PcfComponent } from '@gtui/gt-ui-framework';

export class ProducersGroupMenuLinks {
	producersGroupMenuLinks = PcfComponent('#ProducersGroup-MenuLinks');
	menuLinksProducersGroup_Producers = PcfComponent('#ProducersGroup-MenuLinks-ProducersGroup_Producers');
}

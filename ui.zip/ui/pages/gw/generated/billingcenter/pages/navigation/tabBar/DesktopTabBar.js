import { PcfComponent } from '@gtui/gt-ui-framework';

export class DesktopTabBar {
	desktopTabDesktopGroup_BatchesPage = PcfComponent('#TabBar-DesktopTab-DesktopGroup_BatchesPage');
	desktopTabDesktopGroup_DepositsPage = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DepositsPage');
	desktopTabDesktopGroup_DesktopActivities = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopActivities');
	desktopTabDesktopGroup_DesktopAgencyItems = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopAgencyItems');
	desktopTabDesktopGroup_DesktopApprovals = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopApprovals');
	desktopTabDesktopGroup_DesktopBatchPaymentsSearch = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopBatchPaymentsSearch');
	desktopTabDesktopGroup_DesktopBulkWriteoff = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopBulkWriteoff');
	desktopTabDesktopGroup_DesktopCatastrophes = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopCatastrophes');
	desktopTabDesktopGroup_DesktopDelinquencies = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopDelinquencies');
	desktopTabDesktopGroup_DesktopDisbursements = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopDisbursements');
	desktopTabDesktopGroup_DesktopEscheatments = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopEscheatments');
	desktopTabDesktopGroup_DesktopFundsTracking = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopFundsTracking');
	desktopTabDesktopGroup_DesktopHeldCharges = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopHeldCharges');
	desktopTabDesktopGroup_DesktopQueues = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopQueues');
	desktopTabDesktopGroup_DesktopSuspensePayments = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopSuspensePayments');
	desktopTabDesktopGroup_DesktopTeamActivities = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopTeamActivities');
	desktopTabDesktopGroup_DesktopTroubleTickets = PcfComponent('#TabBar-DesktopTab-DesktopGroup_DesktopTroubleTickets');
	tabBarDesktopTab = PcfComponent('#TabBar-DesktopTab');
	moreoptions = PcfComponent('#TabBarWidget--more-options');
}

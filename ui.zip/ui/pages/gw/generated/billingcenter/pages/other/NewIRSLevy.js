import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class NewIRSLevy {
	iRSLevyDetailScreenCancel = PcfButton('#NewIRSLevy-IRSLevyDetailScreen-Cancel');
	iRSLevyDetailScreenEdit = PcfButton('#NewIRSLevy-IRSLevyDetailScreen-Edit');
	iRSLevyDVagencyTIN = PcfTextInput('#NewIRSLevy-IRSLevyDetailScreen-IRSLevyDV-agencyTIN');
	iRSLevyDVbaCheckThresLow = PcfTextInput('#NewIRSLevy-IRSLevyDetailScreen-IRSLevyDV-baCheckThresLow');
	iRSLevyDVbaClosedDate = PcfDateValueInput('#NewIRSLevy-IRSLevyDetailScreen-IRSLevyDV-baClosedDate');
	iRSLevyDVbaStartDate = PcfDateValueInput('#NewIRSLevy-IRSLevyDetailScreen-IRSLevyDV-baStartDate');
	iRSLevyDVirsinspector = PcfSelectInput('#NewIRSLevy-IRSLevyDetailScreen-IRSLevyDV-irsinspector');
	iRSLevyDVirsoffice = PcfSelectInput('#NewIRSLevy-IRSLevyDetailScreen-IRSLevyDV-irsoffice');
	iRSLevyDVpayableTo = PcfSelectInput('#NewIRSLevy-IRSLevyDetailScreen-IRSLevyDV-payableTo');
	iRSLevyDetailScreenUpdate = PcfButton('#NewIRSLevy-IRSLevyDetailScreen-Update');
	iRSLevyDetailScreen_msgs = PcfButton('#NewIRSLevy-IRSLevyDetailScreen-_msgs');
	newIRSLevyNewIRSLevy_UpLink = PcfButton('#NewIRSLevy-NewIRSLevy_UpLink');
	newIRSLevy_Paging = PcfButton('#NewIRSLevy-_Paging');
	newIRSLevy__crumb__ = PcfComponent('#NewIRSLevy-__crumb__');
}

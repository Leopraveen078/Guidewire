import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class NewBackupWithholding {
	backupWithholdingDVbackupWithholdingEffectiveDate = PcfDateValueInput('#NewBackupWithholding-BackupWithholdDetailScreen-BackupWithholdingDV-backupWithholdingEffectiveDate');
	backupWithholdingDVbackupWithholdingExpieryDate = PcfDateValueInput('#NewBackupWithholding-BackupWithholdDetailScreen-BackupWithholdingDV-backupWithholdingExpieryDate');
	backupWithholdingDVbackupWithholdingPercentage = PcfTextInput('#NewBackupWithholding-BackupWithholdDetailScreen-BackupWithholdingDV-backupWithholdingPercentage');
	backupWithholdDetailScreenCancel = PcfButton('#NewBackupWithholding-BackupWithholdDetailScreen-Cancel');
	backupWithholdDetailScreenEdit = PcfButton('#NewBackupWithholding-BackupWithholdDetailScreen-Edit');
	backupWithholdDetailScreenUpdate = PcfButton('#NewBackupWithholding-BackupWithholdDetailScreen-Update');
	backupWithholdDetailScreen_msgs = PcfButton('#NewBackupWithholding-BackupWithholdDetailScreen-_msgs');
	newBackupWithholdingNewBackupWithholding_UpLink = PcfButton('#NewBackupWithholding-NewBackupWithholding_UpLink');
	newBackupWithholding_Paging = PcfButton('#NewBackupWithholding-_Paging');
	newBackupWithholding__crumb__ = PcfComponent('#NewBackupWithholding-__crumb__');
}

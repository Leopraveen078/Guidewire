import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class NewBankAccount {
	newBankAccountBankAccountDetailScreenBankAccountDVAddressBaseInputSetAddress_AddressLine1 = PcfTextInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-AddressBaseInputSet-Address_AddressLine1');
	newBankAccountBankAccountDetailScreenBankAccountDVAddressBaseInputSetAddress_AddressLine2 = PcfTextInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-AddressBaseInputSet-Address_AddressLine2');
	newBankAccountBankAccountDetailScreenBankAccountDVAddressBaseInputSetAddress_City = PcfButton('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-AddressBaseInputSet-Address_City');
	newBankAccountBankAccountDetailScreenBankAccountDVAddressBaseInputSetAddress_CityAutoFillIcon = PcfButton('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-AddressBaseInputSet-Address_City-AutoFillIcon');
	newBankAccountBankAccountDetailScreenBankAccountDVAddressBaseInputSetAddress_Country = PcfSelectInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-AddressBaseInputSet-Address_Country');
	newBankAccountBankAccountDetailScreenBankAccountDVAddressBaseInputSetAddress_County = PcfTextInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-AddressBaseInputSet-Address_County');
	newBankAccountBankAccountDetailScreenBankAccountDVAddressBaseInputSetAddress_State = PcfSelectInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-AddressBaseInputSet-Address_State');
	newBankAccountBankAccountDetailScreenBankAccountDVAddressBaseInputSetAddress_ZIP = PcfButton('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-AddressBaseInputSet-Address_ZIP');
	newBankAccountBankAccountDetailScreenBankAccountDVAddressBaseInputSetAddress_ZIPAutoFillIcon = PcfButton('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-AddressBaseInputSet-Address_ZIP-AutoFillIcon');
	bankAccountDVbaCheckThres = PcfTextInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baCheckThres');
	bankAccountDVbaCheckThresLow = PcfTextInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baCheckThresLow');
	bankAccountDVbaClosedDate = PcfDateValueInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baClosedDate');
	bankAccountDVbaName = PcfTextInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baName');
	bankAccountDVbaNumber = PcfTextInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baNumber');
	bankAccountDVbaPaymentType = PcfSelectInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baPaymentType');
	bankAccountDVbaRouting = PcfTextInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baRouting');
	bankAccountDVbaRoutingCode1 = PcfTextInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baRoutingCode1');
	bankAccountDVbaRoutingCode2 = PcfTextInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baRoutingCode2');
	bankAccountDVbaStartDate = PcfDateValueInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baStartDate');
	bankAccountDVbaUWCompany = PcfSelectInput('#NewBankAccount-BankAccountDetailScreen-BankAccountDV-baUWCompany');
	bankAccountDetailScreenCancel = PcfButton('#NewBankAccount-BankAccountDetailScreen-Cancel');
	bankAccountDetailScreenEdit = PcfButton('#NewBankAccount-BankAccountDetailScreen-Edit');
	bankAccountDetailScreenUpdate = PcfButton('#NewBankAccount-BankAccountDetailScreen-Update');
	bankAccountDetailScreen_msgs = PcfButton('#NewBankAccount-BankAccountDetailScreen-_msgs');
	newBankAccountNewBankAccount_UpLink = PcfButton('#NewBankAccount-NewBankAccount_UpLink');
	newBankAccount_Paging = PcfButton('#NewBankAccount-_Paging');
	newBankAccount__crumb__ = PcfComponent('#NewBankAccount-__crumb__');
}

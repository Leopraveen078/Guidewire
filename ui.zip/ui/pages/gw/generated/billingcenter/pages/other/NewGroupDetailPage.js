import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class NewGroupDetailPage {
	newGroupDetailPageGroupDetailScreenGroupDetailDVEmailAddress = PcfTextInput('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-EmailAddress');
	newGroupDetailPageGroupDetailScreenGroupDetailDVGroupUsersLV = PcfListView('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-GroupUsersLV');
	newGroupDetailPageGroupDetailScreenGroupDetailDVGroupUsersLV_tbAdd = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-GroupUsersLV_tb-Add');
	newGroupDetailPageGroupDetailScreenGroupDetailDVGroupUsersLV_tbGroupDetailDV_ClearBackupUserButton = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-GroupUsersLV_tb-GroupDetailDV_ClearBackupUserButton');
	newGroupDetailPageGroupDetailScreenGroupDetailDVGroupUsersLV_tbRemove = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-GroupUsersLV_tb-Remove');
	newGroupDetailPageGroupDetailScreenGroupDetailDVName = PcfTextInput('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-Name');
	newGroupDetailPageGroupDetailScreenGroupDetailDVNameKanji = PcfTextInput('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-NameKanji');
	newGroupDetailPageGroupDetailScreenGroupDetailDVParent = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-Parent');
	newGroupDetailPageGroupDetailScreenGroupDetailDVParentGroupPickerMenuIcon = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-Parent-GroupPickerMenuIcon');
	newGroupDetailPageGroupDetailScreenGroupDetailDVParentGroupSearchMenuIcon = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-Parent-GroupSearchMenuIcon');
	newGroupDetailPageGroupDetailScreenGroupDetailDVSecurityZone = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-SecurityZone');
	newGroupDetailPageGroupDetailScreenGroupDetailDVSupervisor = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-Supervisor');
	newGroupDetailPageGroupDetailScreenGroupDetailDVSupervisorSupervisorUserSearchMenuItem = PcfComponent('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-Supervisor-SupervisorUserSearchMenuItem');
	newGroupDetailPageGroupDetailScreenGroupDetailDVSupervisorSupervisorUserSelectMenuItem = PcfComponent('#NewGroupDetailPage-GroupDetailScreen-GroupDetailDV-Supervisor-SupervisorUserSelectMenuItem');
	groupDetailToolbarButtonSetCancel = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailToolbarButtonSet-Cancel');
	groupDetailToolbarButtonSetEdit = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailToolbarButtonSet-Edit');
	groupDetailToolbarButtonSetGroupDetailPage_RegionsCard_DeleteButton = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailToolbarButtonSet-GroupDetailPage_RegionsCard_DeleteButton');
	groupDetailToolbarButtonSetUpdate = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetailToolbarButtonSet-Update');
	groupDetailScreenGroupDetail_BasicCardTab = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetail_BasicCardTab');
	groupDetailScreenGroupDetail_QueuesCardTab = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetail_QueuesCardTab');
	groupDetailScreenGroupDetail_RegionsCardTab = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupDetail_RegionsCardTab');
	groupQueuesLVRefGroupQueuesLV = PcfListView('#NewGroupDetailPage-GroupDetailScreen-GroupQueuesDV-GroupQueuesLVRef-GroupQueuesLV');
	groupQueuesLV_tbAdd = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupQueuesDV-GroupQueuesLVRef-GroupQueuesLV_tb-Add');
	groupQueuesLV_tbRemove = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupQueuesDV-GroupQueuesLVRef-GroupQueuesLV_tb-Remove');
	groupRegionLVRefGroupRegionLV = PcfListView('#NewGroupDetailPage-GroupDetailScreen-GroupRegionLVRef-GroupRegionLV');
	groupRegionLV_tbAdd = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupRegionLVRef-GroupRegionLV_tb-Add');
	groupRegionLV_tbRemove = PcfButton('#NewGroupDetailPage-GroupDetailScreen-GroupRegionLVRef-GroupRegionLV_tb-Remove');
	groupDetailScreen_msgs = PcfButton('#NewGroupDetailPage-GroupDetailScreen-_msgs');
	newGroupDetailPageNewGroupDetailPage_UpLink = PcfButton('#NewGroupDetailPage-NewGroupDetailPage_UpLink');
	newGroupDetailPage_Paging = PcfButton('#NewGroupDetailPage-_Paging');
	newGroupDetailPage__crumb__ = PcfComponent('#NewGroupDetailPage-__crumb__');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class NewActivityPattern {
	activityPatternDVAssignableGroup = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-AssignableGroup');
	activityPatternDVAssignableQueue = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-AssignableQueue');
	activityPatternDVCategory = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-Category');
	activityPatternDVCode = PcfTextInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-Code');
	activityPatternDVDescription = PcfTextInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-Description');
	activityPatternDVEscalationDays = PcfTextInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-EscalationDays');
	activityPatternDVEscalationHours = PcfTextInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-EscalationHours');
	activityPatternDVEscalationIncludeDays = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-EscalationIncludeDays');
	activityPatternDVEscalationStartPoint = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-EscalationStartPoint');
	activityPatternDVMandatory = PcfComponent('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-Mandatory');
	activityPatternDVMediumSubject = PcfTextInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-MediumSubject');
	activityPatternDVPatternLevel = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-PatternLevel');
	activityPatternDVPriority = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-Priority');
	activityPatternDVSourceCenter = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-SourceCenter');
	activityPatternDVSubject = PcfTextInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-Subject');
	activityPatternDVTargetCenter = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-TargetCenter');
	activityPatternDVTargetDays = PcfTextInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-TargetDays');
	activityPatternDVTargetHours = PcfTextInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-TargetHours');
	activityPatternDVTargetIncludeDays = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-TargetIncludeDays');
	activityPatternDVTargetStartPoint = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-TargetStartPoint');
	activityPatternDVType = PcfSelectInput('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-Type');
	activityPatternDVdisplayonmenu = PcfComponent('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDV-displayonmenu');
	activityPatternDetailScreenActivityPatternDetailScreen_DeleteButton = PcfButton('#NewActivityPattern-ActivityPatternDetailScreen-ActivityPatternDetailScreen_DeleteButton');
	activityPatternDetailScreenCancel = PcfButton('#NewActivityPattern-ActivityPatternDetailScreen-Cancel');
	activityPatternDetailScreenEdit = PcfButton('#NewActivityPattern-ActivityPatternDetailScreen-Edit');
	newActivityPatternActivityPatternDetailScreenLocalizedValuesDVLocalizedValuesLV = PcfListView('#NewActivityPattern-ActivityPatternDetailScreen-LocalizedValuesDV-LocalizedValuesLV');
	activityPatternDetailScreenUpdate = PcfButton('#NewActivityPattern-ActivityPatternDetailScreen-Update');
	activityPatternDetailScreen_msgs = PcfButton('#NewActivityPattern-ActivityPatternDetailScreen-_msgs');
	newActivityPatternNewActivityPattern_UpLink = PcfButton('#NewActivityPattern-NewActivityPattern_UpLink');
	newActivityPattern_Paging = PcfButton('#NewActivityPattern-_Paging');
	newActivityPattern__crumb__ = PcfComponent('#NewActivityPattern-__crumb__');
}

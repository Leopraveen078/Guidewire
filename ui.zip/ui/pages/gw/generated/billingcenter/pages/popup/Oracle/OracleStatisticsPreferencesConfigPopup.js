import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class OracleStatisticsPreferencesConfigPopup {
	oracleStatisticsPreferencesConfigPopupOracleStatisticsPreferencesConfigPopup_UpLink = PcfButton('#OracleStatisticsPreferencesConfigPopup-OracleStatisticsPreferencesConfigPopup_UpLink');
	oracleStatisticsPreferencesConfigPopup_Paging = PcfButton('#OracleStatisticsPreferencesConfigPopup-_Paging');
	oracleStatisticsPreferencesConfigPopup__crumb__ = PcfComponent('#OracleStatisticsPreferencesConfigPopup-__crumb__');
	oracleStatisticsPreferencesConfigPopup_msgs = PcfButton('#OracleStatisticsPreferencesConfigPopup-_msgs');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class CommissionAdjustmentPopup {
	commissionAdjustmentPopupCommissionAdjustmentPopup_UpLink = PcfButton('#CommissionAdjustmentPopup-CommissionAdjustmentPopup_UpLink');
	commissionAdjustmentPopup_Paging = PcfButton('#CommissionAdjustmentPopup-_Paging');
	commissionAdjustmentPopup__crumb__ = PcfComponent('#CommissionAdjustmentPopup-__crumb__');
	commissionAdjustmentPopup_msgs = PcfButton('#CommissionAdjustmentPopup-_msgs');
	commissionAdjustmentPopupamount = PcfTextInput('#CommissionAdjustmentPopup-amount');
	commissionAdjustmentPopupdate = PcfDateValueInput('#CommissionAdjustmentPopup-date');
	commissionAdjustmentPopuppolicyperiod = PcfTextInput('#CommissionAdjustmentPopup-policyperiod');
	commissionAdjustmentPopupproducer = PcfTextInput('#CommissionAdjustmentPopup-producer');
	commissionAdjustmentPopupreason = PcfTextInput('#CommissionAdjustmentPopup-reason');
}

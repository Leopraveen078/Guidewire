import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class PickDocumentsPopup {
	pickDocumentsPopupPickDocumentsPopup_UpLink = PcfButton('#PickDocumentsPopup-PickDocumentsPopup_UpLink');
	pickDocumentsScreenDocumentAttachmentsLV = PcfListView('#PickDocumentsPopup-PickDocumentsScreen-DocumentAttachmentsLV');
	documentAttachmentsLV_tbattach = PcfButton('#PickDocumentsPopup-PickDocumentsScreen-DocumentAttachmentsLV_tb-attach');
	documentAttachmentsLV_tbunselect = PcfButton('#PickDocumentsPopup-PickDocumentsScreen-DocumentAttachmentsLV_tb-unselect');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVAuthorCriterion = PcfTextInput('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-AuthorCriterion');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVDateSearchCriteriaDateSearchCriteriaChosenOption = PcfSelectInput('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-DateSearchCriteria-DateSearchCriteriaChosenOption');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVDateSearchCriteriaDateSearchCriteriaDirectChoice_Choice = PcfButton('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-DateSearchCriteria-DateSearchCriteriaDirectChoice_Choice');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVDateSearchCriteriaDateSearchCriteriaEndDate = PcfDateValueInput('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-DateSearchCriteria-DateSearchCriteriaEndDate');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVDateSearchCriteriaDateSearchCriteriaRangeChoice_Choice = PcfButton('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-DateSearchCriteria-DateSearchCriteriaRangeChoice_Choice');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVDateSearchCriteriaDateSearchCriteriaRangeValue = PcfSelectInput('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-DateSearchCriteria-DateSearchCriteriaRangeValue');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVDateSearchCriteriaDateSearchCriteriaStartDate = PcfDateValueInput('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-DateSearchCriteria-DateSearchCriteriaStartDate');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVIncludeObsoletes = PcfComponent('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-IncludeObsoletes');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVLanguage = PcfSelectInput('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-Language');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVSearchAndResetInputSetSearchLinksInputSetReset = PcfButton('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Reset');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVSearchAndResetInputSetSearchLinksInputSetSearch = PcfButton('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Search');
	pickDocumentsPopupPickDocumentsScreenDocumentSearchDVTypeCriterion = PcfSelectInput('#PickDocumentsPopup-PickDocumentsScreen-DocumentSearchDV-TypeCriterion');
	pickDocumentsScreenPickExistingDocumentPopup_CancelButton = PcfButton('#PickDocumentsPopup-PickDocumentsScreen-PickExistingDocumentPopup_CancelButton');
	pickDocumentsScreen_msgs = PcfButton('#PickDocumentsPopup-PickDocumentsScreen-_msgs');
	pickDocumentsPopup_Paging = PcfButton('#PickDocumentsPopup-_Paging');
	pickDocumentsPopup__crumb__ = PcfComponent('#PickDocumentsPopup-__crumb__');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class BatchSelectionPopup {
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVAuthorCriterion = PcfTextInput('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-AuthorCriterion');
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVCreatedBy = PcfTextInput('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-CreatedBy');
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVCreatedDate = PcfDateValueInput('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-CreatedDate');
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVLOBCodeTypeKeyCell = PcfSelectInput('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-LOBCodeTypeKeyCell');
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVSearchAndResetInputSetSearchLinksInputSetReset = PcfButton('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Reset');
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVSearchAndResetInputSetSearchLinksInputSetSearch = PcfButton('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Search');
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVSourceTypeKeyCell = PcfSelectInput('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-SourceTypeKeyCell');
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVStatusTypeKeyCell = PcfSelectInput('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-StatusTypeKeyCell');
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVTypeCriterion = PcfTextInput('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-TypeCriterion');
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVUpdatedBy = PcfTextInput('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-UpdatedBy');
	batchSelectionPopupAccountDetailDocumentsScreenBatchSearchDVUpdatedDate = PcfDateValueInput('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchSearchDV-UpdatedDate');
	accountDetailDocumentsScreenBatchesLV = PcfListView('#BatchSelectionPopup-AccountDetailDocumentsScreen-BatchesLV');
	batchSelectionPopupAccountDetailDocumentsScreen_msgs = PcfButton('#BatchSelectionPopup-AccountDetailDocumentsScreen-_msgs');
	batchSelectionPopupBatchSelectionPopup_UpLink = PcfButton('#BatchSelectionPopup-BatchSelectionPopup_UpLink');
	batchSelectionPopup_Paging = PcfButton('#BatchSelectionPopup-_Paging');
	batchSelectionPopup__crumb__ = PcfComponent('#BatchSelectionPopup-__crumb__');
}

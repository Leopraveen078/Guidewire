import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class AgencyCycleExceptionCommentsPopup {
	agencyCycleExceptionCommentsPopupAgencyCycleExceptionCommentsPopup_UpLink = PcfButton('#AgencyCycleExceptionCommentsPopup-AgencyCycleExceptionCommentsPopup_UpLink');
	agencyCycleExceptionCommentsPopupCancel = PcfButton('#AgencyCycleExceptionCommentsPopup-Cancel');
	agencyCycleExceptionCommentsPopupEdit = PcfButton('#AgencyCycleExceptionCommentsPopup-Edit');
	agencyCycleExceptionCommentsPopupUpdate = PcfButton('#AgencyCycleExceptionCommentsPopup-Update');
	agencyCycleExceptionCommentsPopup_Paging = PcfButton('#AgencyCycleExceptionCommentsPopup-_Paging');
	agencyCycleExceptionCommentsPopup__crumb__ = PcfComponent('#AgencyCycleExceptionCommentsPopup-__crumb__');
	agencyCycleExceptionCommentsPopup_msgs = PcfButton('#AgencyCycleExceptionCommentsPopup-_msgs');
	agencyCycleExceptionCommentsPopupexceptionComments = PcfTextInput('#AgencyCycleExceptionCommentsPopup-exceptionComments');
}

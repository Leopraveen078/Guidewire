import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class ListBillPaymentPlansPopup {
	listBillPaymentPlansPopupListBillPaymentPlansPopup_UpLink = PcfButton('#ListBillPaymentPlansPopup-ListBillPaymentPlansPopup_UpLink');
	listBillPaymentPlansPopupPaymentPlansLV = PcfListView('#ListBillPaymentPlansPopup-PaymentPlansLV');
	listBillPaymentPlansPopup_Paging = PcfButton('#ListBillPaymentPlansPopup-_Paging');
	listBillPaymentPlansPopup__crumb__ = PcfComponent('#ListBillPaymentPlansPopup-__crumb__');
	listBillPaymentPlansPopup_msgs = PcfButton('#ListBillPaymentPlansPopup-_msgs');
}

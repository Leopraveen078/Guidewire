import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class MessageHistoryPayloadPopup {
	messageHistoryPayloadPopupMessageHistoryPayloadPopup_UpLink = PcfButton('#MessageHistoryPayloadPopup-MessageHistoryPayloadPopup_UpLink');
	historyPayLoadDVErrorCategory = PcfSelectInput('#MessageHistoryPayloadPopup-MessageHistoryPayloadScreen-HistoryPayLoadDV-ErrorCategory');
	historyPayLoadDVErrorDescription = PcfTextInput('#MessageHistoryPayloadPopup-MessageHistoryPayloadScreen-HistoryPayLoadDV-ErrorDescription');
	historyPayLoadDVPayload = PcfTextInput('#MessageHistoryPayloadPopup-MessageHistoryPayloadScreen-HistoryPayLoadDV-Payload');
	historyPayLoadDVPublicId = PcfTextInput('#MessageHistoryPayloadPopup-MessageHistoryPayloadScreen-HistoryPayLoadDV-PublicId');
	messageHistoryPayloadScreenReprocessMessage = PcfButton('#MessageHistoryPayloadPopup-MessageHistoryPayloadScreen-ReprocessMessage');
	messageHistoryPayloadScreenReprocessMessageArchiveOnly = PcfButton('#MessageHistoryPayloadPopup-MessageHistoryPayloadScreen-ReprocessMessageArchiveOnly');
	messageHistoryPayloadScreenReprocessMessagePrintEmailOnly = PcfButton('#MessageHistoryPayloadPopup-MessageHistoryPayloadScreen-ReprocessMessagePrintEmailOnly');
	messageHistoryPayloadScreen_msgs = PcfButton('#MessageHistoryPayloadPopup-MessageHistoryPayloadScreen-_msgs');
	messageHistoryPayloadPopup_Paging = PcfButton('#MessageHistoryPayloadPopup-_Paging');
	messageHistoryPayloadPopup__crumb__ = PcfComponent('#MessageHistoryPayloadPopup-__crumb__');
}

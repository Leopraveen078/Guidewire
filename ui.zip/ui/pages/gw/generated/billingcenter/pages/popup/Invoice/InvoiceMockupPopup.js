import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class InvoiceMockupPopup {
	invoiceMockupPopupAccountBalanceAmount = PcfTextInput('#InvoiceMockupPopup-AccountBalanceAmount');
	invoiceMockupPopupAdjustments = PcfTextInput('#InvoiceMockupPopup-Adjustments');
	invoiceMockupPopupCreditApplied = PcfTextInput('#InvoiceMockupPopup-CreditApplied');
	invoiceMockupPopupDateMinDue = PcfDateValueInput('#InvoiceMockupPopup-DateMinDue');
	invoiceMockupPopupDatePayments = PcfDateValueInput('#InvoiceMockupPopup-DatePayments');
	invoiceMockupPopupInvoiceLineItemsLV = PcfListView('#InvoiceMockupPopup-InvoiceLineItemsLV');
	invoiceMockupPopupInvoiceMockupPopup_UpLink = PcfButton('#InvoiceMockupPopup-InvoiceMockupPopup_UpLink');
	invoiceMockupPopupMinAmountDue = PcfTextInput('#InvoiceMockupPopup-MinAmountDue');
	invoiceMockupPopupPaymentsReceived = PcfTextInput('#InvoiceMockupPopup-PaymentsReceived');
	invoiceMockupPopupPreviousAmountDue = PcfTextInput('#InvoiceMockupPopup-PreviousAmountDue');
	invoiceMockupPopupRowAmtHeader = PcfButton('#InvoiceMockupPopup-RowAmtHeader');
	invoiceMockupPopupRowDescHeader = PcfButton('#InvoiceMockupPopup-RowDescHeader');
	invoiceMockupPopupUnpaidAmounts = PcfTextInput('#InvoiceMockupPopup-UnpaidAmounts');
	invoiceMockupPopup_ListPaging = PcfButton('#InvoiceMockupPopup-_ListPaging');
	invoiceMockupPopup_Paging = PcfButton('#InvoiceMockupPopup-_Paging');
	invoiceMockupPopup__crumb__ = PcfComponent('#InvoiceMockupPopup-__crumb__');
	invoiceMockupPopup_msgs = PcfButton('#InvoiceMockupPopup-_msgs');
	invoiceMockupPopupdateHeader = PcfButton('#InvoiceMockupPopup-dateHeader');
}

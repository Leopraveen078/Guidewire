import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class ScratchPadPopup {
	scratchPadPopupCancel = PcfButton('#ScratchPadPopup-Cancel');
	scratchPadPopupEdit = PcfButton('#ScratchPadPopup-Edit');
	scratchPadPopupExternalReference = PcfTextInput('#ScratchPadPopup-ExternalReference');
	scratchPadPopupScratchPadPopup_UpLink = PcfButton('#ScratchPadPopup-ScratchPadPopup_UpLink');
	scratchPadPopupUpdate = PcfButton('#ScratchPadPopup-Update');
	scratchPadPopup_Paging = PcfButton('#ScratchPadPopup-_Paging');
	scratchPadPopup__crumb__ = PcfComponent('#ScratchPadPopup-__crumb__');
	scratchPadPopup_msgs = PcfButton('#ScratchPadPopup-_msgs');
	scratchPadPopupcode = PcfTextInput('#ScratchPadPopup-code');
	scratchPadPopupoutput = PcfTextInput('#ScratchPadPopup-output');
	scratchPadPopupvariable = PcfTextInput('#ScratchPadPopup-variable');
}

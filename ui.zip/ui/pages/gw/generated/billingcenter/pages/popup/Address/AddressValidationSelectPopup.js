import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class AddressValidationSelectPopup {
	addressValidationSelectPopupAddressValidationSelectPopup_UpLink = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectPopup_UpLink');
	addressValidationSelectScreenCancel = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectScreen-Cancel');
	addressValidationSelectScreenEdit = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectScreen-Edit');
	addressValidationSelectScreenUpdate = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectScreen-Update');
	addressValidationSelectScreen_msgs = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectScreen-_msgs');
	addressStandardizedInputSetAddress_AddressLine1 = PcfTextInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-corrected-AddressStandardizedInputSet-Address_AddressLine1');
	addressStandardizedInputSetAddress_AddressLine2 = PcfTextInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-corrected-AddressStandardizedInputSet-Address_AddressLine2');
	addressStandardizedInputSetAddress_City = PcfTextInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-corrected-AddressStandardizedInputSet-Address_City');
	addressStandardizedInputSetAddress_Country = PcfSelectInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-corrected-AddressStandardizedInputSet-Address_Country');
	addressStandardizedInputSetAddress_State = PcfTextInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-corrected-AddressStandardizedInputSet-Address_State');
	addressStandardizedInputSetAddress_ZIP = PcfTextInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-corrected-AddressStandardizedInputSet-Address_ZIP');
	addressBaseInputSetAddress_AddressLine1 = PcfTextInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-original-AddressBaseInputSet-Address_AddressLine1');
	addressBaseInputSetAddress_AddressLine2 = PcfTextInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-original-AddressBaseInputSet-Address_AddressLine2');
	addressBaseInputSetAddress_City = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectScreen-original-AddressBaseInputSet-Address_City');
	address_CityAutoFillIcon = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectScreen-original-AddressBaseInputSet-Address_City-AutoFillIcon');
	addressBaseInputSetAddress_Country = PcfSelectInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-original-AddressBaseInputSet-Address_Country');
	addressBaseInputSetAddress_County = PcfTextInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-original-AddressBaseInputSet-Address_County');
	addressBaseInputSetAddress_State = PcfSelectInput('#AddressValidationSelectPopup-AddressValidationSelectScreen-original-AddressBaseInputSet-Address_State');
	addressBaseInputSetAddress_ZIP = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectScreen-original-AddressBaseInputSet-Address_ZIP');
	address_ZIPAutoFillIcon = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectScreen-original-AddressBaseInputSet-Address_ZIP-AutoFillIcon');
	addressValidationSelectScreenoverrideStd = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectScreen-overrideStd');
	addressValidationSelectScreensaveStd = PcfButton('#AddressValidationSelectPopup-AddressValidationSelectScreen-saveStd');
	addressValidationSelectPopup_Paging = PcfButton('#AddressValidationSelectPopup-_Paging');
	addressValidationSelectPopup__crumb__ = PcfComponent('#AddressValidationSelectPopup-__crumb__');
}

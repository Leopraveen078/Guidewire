import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { Selector } from 'testcafe';

export class DBPaymentReversalConfirmationPopup {
	dBPaymentReversalConfirmationPopup_ttlBar = PcfComponent('#DBPaymentReversalConfirmationPopup-ttlBar');
	dBPaymentReversalConfirmationPopupCancel = PcfButton('#DBPaymentReversalConfirmationPopup-Cancel');
	dBPaymentReversalConfirmationPopupDBPaymentReversalConfirmationPopup_UpLink = PcfButton('#DBPaymentReversalConfirmationPopup-DBPaymentReversalConfirmationPopup_UpLink');
	dBPaymentReversalConfirmationPopupEdit = PcfButton('#DBPaymentReversalConfirmationPopup-Edit');
	dBPaymentReversalConfirmationPopupReason = Selector('#DBPaymentReversalConfirmationPopup-Reason');
	dBPaymentReversalConfirmationPopupUpdate = PcfButton('#DBPaymentReversalConfirmationPopup-Update');
	dBPaymentReversalConfirmationPopup_Paging = PcfButton('#DBPaymentReversalConfirmationPopup-_Paging');
	dBPaymentReversalConfirmationPopup__crumb__ = PcfComponent('#DBPaymentReversalConfirmationPopup-__crumb__');
	dBPaymentReversalConfirmationPopup_msgs = PcfButton('#DBPaymentReversalConfirmationPopup-_msgs');
	dBPaymentReversalConfirmationPopupnegativeWarning = PcfButton('#DBPaymentReversalConfirmationPopup-negativeWarning');
	dBPaymentReversalConfirmationPopupnegativeWarningCloseBtn = PcfButton('#DBPaymentReversalConfirmationPopup-negativeWarning-CloseBtn');
}

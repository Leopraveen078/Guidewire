import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class UserSelectPopup {
	userSelectPopupScreen_msgs = PcfButton('#UserSelectPopup-UserSelectPopupScreen-_msgs');
	userSelectPopupUserSelectPopup_UpLink = PcfButton('#UserSelectPopup-UserSelectPopup_UpLink');
	userSelectPopup_Paging = PcfButton('#UserSelectPopup-_Paging');
	userSelectPopup__crumb__ = PcfComponent('#UserSelectPopup-__crumb__');
}

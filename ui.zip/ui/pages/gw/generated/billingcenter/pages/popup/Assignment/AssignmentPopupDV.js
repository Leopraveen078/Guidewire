import { PcfComponent } from '@gtui/gt-ui-framework';

export class AssignmentPopupDV {
}

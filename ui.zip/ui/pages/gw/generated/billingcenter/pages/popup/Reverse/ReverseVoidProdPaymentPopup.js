import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class ReverseVoidProdPaymentPopup {
	reverseVoidProdPaymentPopupCancel = PcfButton('#ReverseVoidProdPaymentPopup-Cancel');
	reverseVoidProdPaymentPopupEdit = PcfButton('#ReverseVoidProdPaymentPopup-Edit');
	reverseVoidProdPaymentPopupReverseVoidProdPaymentPopup_UpLink = PcfButton('#ReverseVoidProdPaymentPopup-ReverseVoidProdPaymentPopup_UpLink');
	reverseVoidProdPaymentPopupUpdate = PcfButton('#ReverseVoidProdPaymentPopup-Update');
	reverseVoidProdPaymentPopup_Paging = PcfButton('#ReverseVoidProdPaymentPopup-_Paging');
	reverseVoidProdPaymentPopup__crumb__ = PcfComponent('#ReverseVoidProdPaymentPopup-__crumb__');
	reverseVoidProdPaymentPopup_msgs = PcfButton('#ReverseVoidProdPaymentPopup-_msgs');
	reverseVoidProdPaymentPopupalertbar = PcfButton('#ReverseVoidProdPaymentPopup-alertbar');
	alertbarCloseBtn = PcfButton('#ReverseVoidProdPaymentPopup-alertbar-CloseBtn');
	reverseVoidProdPaymentPopupamount = PcfTextInput('#ReverseVoidProdPaymentPopup-amount');
	reverseVoidProdPaymentPopupreason = PcfSelectInput('#ReverseVoidProdPaymentPopup-reason');
}

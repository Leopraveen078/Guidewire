import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class SP_S3ExportPopup {
	sP_S3ExportPopupEntityName_SPHeader = PcfButton('#SP_S3ExportPopup-EntityName_SPHeader');
	sP_S3ExportPopupSP_S3ExportPopup_UpLink = PcfButton('#SP_S3ExportPopup-SP_S3ExportPopup_UpLink');
	sP_S3ExportPopup_ListPaging = PcfButton('#SP_S3ExportPopup-_ListPaging');
	sP_S3ExportPopup_Paging = PcfButton('#SP_S3ExportPopup-_Paging');
	sP_S3ExportPopup__crumb__ = PcfComponent('#SP_S3ExportPopup-__crumb__');
	sP_S3ExportPopup_msgs = PcfButton('#SP_S3ExportPopup-_msgs');
}

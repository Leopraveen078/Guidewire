import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class NewActivityPopup {
	newActivityPopupNewActivityPopup_UpLink = PcfButton('#NewActivityPopup-NewActivityPopup_UpLink');
	activityDetailDV_AssignActivityActivityDetailDV_AssignActivity_PickerButton = PcfButton('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-ActivityDetailDV_AssignActivity-ActivityDetailDV_AssignActivity_PickerButton');
	activityDetailDVActivityDetailDV_Description = PcfTextInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-ActivityDetailDV_Description');
	activityDetailDVActivityDetailDV_EscalationDate = PcfDateValueInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-ActivityDetailDV_EscalationDate');
	activityDetailDVActivityDetailDV_Priority = PcfSelectInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-ActivityDetailDV_Priority');
	activityDetailDVActivityDetailDV_RejectReason = PcfSelectInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-ActivityDetailDV_RejectReason');
	activityDetailDVActivityDetailDV_Status = PcfSelectInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-ActivityDetailDV_Status');
	activityDetailDVActivityDetailDV_Subject = PcfTextInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-ActivityDetailDV_Subject');
	activityDetailDVActivityDetailDV_TargetDate = PcfDateValueInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-ActivityDetailDV_TargetDate');
	accountacctPicker = PcfButton('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-EdgeEntitiesInputSet-account-acctPicker');
	edgeEntitiesInputSetpolicyPeriodSet = PcfSelectInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-EdgeEntitiesInputSet-policyPeriodSet');
	producerproducer = PcfButton('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-EdgeEntitiesInputSet-producer-producer');
	activityDetailInputSetActivityDetailDV_Description = PcfTextInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-activityInputSet-ActivityDetailInputSet-ActivityDetailDV_Description');
	activityDetailInputSetdisbursementnbr = PcfButton('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-activityInputSet-ActivityDetailInputSet-disbursementnbr');
	activityDetailInputSetfirstapproval = PcfSelectInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-activityInputSet-ActivityDetailInputSet-firstapproval');
	activityDetailInputSetsecondapproval = PcfSelectInput('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-activityInputSet-ActivityDetailInputSet-secondapproval');
	activityDetailDVActivityDetailDV_Disbursement = PcfButton('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-ActivityDetailDV_Disbursement');
	documentTemplateSelectDocumentTemplate = PcfButton('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-DocumentTemplate-SelectDocumentTemplate');
	emailTemplateSelectEmailTemplate = PcfButton('#NewActivityPopup-NewActivityScreen-ActivityDetailDV-EmailTemplate-SelectEmailTemplate');
	newActivityScreenCancel = PcfButton('#NewActivityPopup-NewActivityScreen-Cancel');
	newActivityScreenEdit = PcfButton('#NewActivityPopup-NewActivityScreen-Edit');
	newActivityScreenUpdate = PcfButton('#NewActivityPopup-NewActivityScreen-Update');
	newActivityScreen_msgs = PcfButton('#NewActivityPopup-NewActivityScreen-_msgs');
	newActivityPopup_Paging = PcfButton('#NewActivityPopup-_Paging');
	newActivityPopup__crumb__ = PcfComponent('#NewActivityPopup-__crumb__');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class BulkWriteOffPopup {
	bulkWriteOffPopupBulkWriteOffPopup_UpLink = PcfButton('#BulkWriteOffPopup-BulkWriteOffPopup_UpLink');
	bulkWriteOffPopupCancel = PcfButton('#BulkWriteOffPopup-Cancel');
	bulkWriteOffPopupEdit = PcfButton('#BulkWriteOffPopup-Edit');
	bulkWriteOffPopupUnder500Tab = PcfButton('#BulkWriteOffPopup-Under500Tab');
	bulkWriteOffPopupUpdate = PcfButton('#BulkWriteOffPopup-Update');
	bulkWriteOffPopup_Paging = PcfButton('#BulkWriteOffPopup-_Paging');
	bulkWriteOffPopup__crumb__ = PcfComponent('#BulkWriteOffPopup-__crumb__');
	bulkWriteOffPopup_msgs = PcfButton('#BulkWriteOffPopup-_msgs');
	bulkWriteOffPopupasofdate = PcfDateValueInput('#BulkWriteOffPopup-asofdate');
	bulkWriteOffPopupover500LV = PcfListView('#BulkWriteOffPopup-over500LV');
	over500LV_tbAdd = PcfButton('#BulkWriteOffPopup-over500LV_tb-Add');
	over500LV_tbPrintToolbarButton = PcfButton('#BulkWriteOffPopup-over500LV_tb-PrintToolbarButton');
	over500LV_tbRemove = PcfButton('#BulkWriteOffPopup-over500LV_tb-Remove');
	bulkWriteOffPopupover500Tab = PcfButton('#BulkWriteOffPopup-over500Tab');
	bulkWriteOffPopupprocessbtn = PcfButton('#BulkWriteOffPopup-processbtn');
	bulkWriteOffPopupprocessedLV = PcfListView('#BulkWriteOffPopup-processedLV');
	processedLV_tbPrintToolbarButton = PcfButton('#BulkWriteOffPopup-processedLV_tb-PrintToolbarButton');
	bulkWriteOffPopupprocesspending = PcfButton('#BulkWriteOffPopup-processpending');
	processpendingCloseBtn = PcfButton('#BulkWriteOffPopup-processpending-CloseBtn');
	bulkWriteOffPopupunder500LV = PcfListView('#BulkWriteOffPopup-under500LV');
	under500LV_tbAdd = PcfButton('#BulkWriteOffPopup-under500LV_tb-Add');
	under500LV_tbPrintToolbarButton = PcfButton('#BulkWriteOffPopup-under500LV_tb-PrintToolbarButton');
	under500LV_tbRemove = PcfButton('#BulkWriteOffPopup-under500LV_tb-Remove');
	bulkWriteOffPopupwrittenOffTab = PcfButton('#BulkWriteOffPopup-writtenOffTab');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class CatastropheDetailPopup {
	catastropheDetailPopupAdd = PcfButton('#CatastropheDetailPopup-Add');
	catastropheDetailPopupCancel = PcfButton('#CatastropheDetailPopup-Cancel');
	catastropheDetailPopupCatastropheDetailPopup_UpLink = PcfButton('#CatastropheDetailPopup-CatastropheDetailPopup_UpLink');
	catastropheDetailPopupEdit = PcfButton('#CatastropheDetailPopup-Edit');
	catastropheDetailPopupRemove = PcfButton('#CatastropheDetailPopup-Remove');
	catastropheDetailPopupUpdate = PcfButton('#CatastropheDetailPopup-Update');
	catastropheDetailPopup_ListPaging = PcfButton('#CatastropheDetailPopup-_ListPaging');
	catastropheDetailPopup_Paging = PcfButton('#CatastropheDetailPopup-_Paging');
	catastropheDetailPopup__crumb__ = PcfComponent('#CatastropheDetailPopup-__crumb__');
	catastropheDetailPopup_msgs = PcfButton('#CatastropheDetailPopup-_msgs');
	catastropheDetailPopupdetails = PcfTextInput('#CatastropheDetailPopup-details');
	catastropheDetailPopupholdDel = PcfSelectInput('#CatastropheDetailPopup-holdDel');
	catastropheDetailPopupreleasedt = PcfDateValueInput('#CatastropheDetailPopup-releasedt');
	catastropheDetailPopupsetInvHold = PcfSelectInput('#CatastropheDetailPopup-setInvHold');
	catastropheDetailPopupstatus = PcfSelectInput('#CatastropheDetailPopup-status');
	catastropheDetailPopupsubject = PcfTextInput('#CatastropheDetailPopup-subject');
	catastropheDetailPopupzoneHeader = PcfButton('#CatastropheDetailPopup-zoneHeader');
}

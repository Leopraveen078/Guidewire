import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class Multicurrency_SourceOfFundsPopup {
	multicurrency_SourceOfFundsPopupMulticurrency_FundsAllotmentLV = PcfListView('#Multicurrency_SourceOfFundsPopup-Multicurrency_FundsAllotmentLV');
	multicurrency_SourceOfFundsPopupMulticurrency_SourceOfFundsPopup_UpLink = PcfButton('#Multicurrency_SourceOfFundsPopup-Multicurrency_SourceOfFundsPopup_UpLink');
	multicurrency_SourceOfFundsPopup_Paging = PcfButton('#Multicurrency_SourceOfFundsPopup-_Paging');
	multicurrency_SourceOfFundsPopup__crumb__ = PcfComponent('#Multicurrency_SourceOfFundsPopup-__crumb__');
	multicurrency_SourceOfFundsPopup_msgs = PcfButton('#Multicurrency_SourceOfFundsPopup-_msgs');
	multicurrency_SourceOfFundsPopupsource = PcfButton('#Multicurrency_SourceOfFundsPopup-source');
}

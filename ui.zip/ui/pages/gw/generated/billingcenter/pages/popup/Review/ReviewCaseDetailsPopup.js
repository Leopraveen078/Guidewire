import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class ReviewCaseDetailsPopup {
	reviewCaseDetailsPopupDocumentDetailsScreenCancel = PcfButton('#ReviewCaseDetailsPopup-DocumentDetailsScreen-Cancel');
	authorUserBrowseMenuItem = PcfComponent('#ReviewCaseDetailsPopup-DocumentDetailsScreen-DocumentMetadataInputSet-Author-UserBrowseMenuItem');
	documentMetadataInputSetDocumentName = PcfTextInput('#ReviewCaseDetailsPopup-DocumentDetailsScreen-DocumentMetadataInputSet-DocumentName');
	documentMetadataInputSetMimeType = PcfSelectInput('#ReviewCaseDetailsPopup-DocumentDetailsScreen-DocumentMetadataInputSet-MimeType');
	documentMetadataInputSetSecurityType = PcfSelectInput('#ReviewCaseDetailsPopup-DocumentDetailsScreen-DocumentMetadataInputSet-SecurityType');
	documentMetadataInputSetStatus = PcfSelectInput('#ReviewCaseDetailsPopup-DocumentDetailsScreen-DocumentMetadataInputSet-Status');
	documentMetadataInputSetType = PcfSelectInput('#ReviewCaseDetailsPopup-DocumentDetailsScreen-DocumentMetadataInputSet-Type');
	reviewCaseDetailsPopupDocumentDetailsScreenEdit = PcfButton('#ReviewCaseDetailsPopup-DocumentDetailsScreen-Edit');
	reviewCaseDetailsPopupDocumentDetailsScreenUpdate = PcfButton('#ReviewCaseDetailsPopup-DocumentDetailsScreen-Update');
	reviewCaseDetailsPopupDocumentDetailsScreen_msgs = PcfButton('#ReviewCaseDetailsPopup-DocumentDetailsScreen-_msgs');
	reviewCaseDetailsPopupReviewCaseDetailsPopup_UpLink = PcfButton('#ReviewCaseDetailsPopup-ReviewCaseDetailsPopup_UpLink');
	reviewCaseDetailsPopup_Paging = PcfButton('#ReviewCaseDetailsPopup-_Paging');
	reviewCaseDetailsPopup__crumb__ = PcfComponent('#ReviewCaseDetailsPopup-__crumb__');
}

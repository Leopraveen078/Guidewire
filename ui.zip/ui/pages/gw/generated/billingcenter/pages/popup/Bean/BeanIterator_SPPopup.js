import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class BeanIterator_SPPopup {
	beanIterator_SPPopupBeanIterator_SPPopup_UpLink = PcfButton('#BeanIterator_SPPopup-BeanIterator_SPPopup_UpLink');
	beanIterator_SPPopupDisplayNameHeader = PcfButton('#BeanIterator_SPPopup-DisplayNameHeader');
	beanIterator_SPPopupPublicIDHeader = PcfButton('#BeanIterator_SPPopup-PublicIDHeader');
	beanIterator_SPPopupSelectChosenBeans = PcfButton('#BeanIterator_SPPopup-SelectChosenBeans');
	beanIterator_SPPopupSelectedHeader = PcfButton('#BeanIterator_SPPopup-SelectedHeader');
	beanIterator_SPPopupUnselectChosenBeans = PcfButton('#BeanIterator_SPPopup-UnselectChosenBeans');
	beanIterator_SPPopupUpdateAndReturnToExport = PcfButton('#BeanIterator_SPPopup-UpdateAndReturnToExport');
	beanIterator_SPPopup_ListPaging = PcfButton('#BeanIterator_SPPopup-_ListPaging');
	beanIterator_SPPopup_Paging = PcfButton('#BeanIterator_SPPopup-_Paging');
	beanIterator_SPPopup__crumb__ = PcfComponent('#BeanIterator_SPPopup-__crumb__');
	beanIterator_SPPopup_msgs = PcfButton('#BeanIterator_SPPopup-_msgs');
}

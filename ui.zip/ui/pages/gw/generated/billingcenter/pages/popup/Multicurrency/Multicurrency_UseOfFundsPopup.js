import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class Multicurrency_UseOfFundsPopup {
	multicurrency_UseOfFundsPopupMulticurrency_FundsAllotmentLV = PcfListView('#Multicurrency_UseOfFundsPopup-Multicurrency_FundsAllotmentLV');
	multicurrency_UseOfFundsPopupMulticurrency_UseOfFundsPopup_UpLink = PcfButton('#Multicurrency_UseOfFundsPopup-Multicurrency_UseOfFundsPopup_UpLink');
	multicurrency_UseOfFundsPopup_Paging = PcfButton('#Multicurrency_UseOfFundsPopup-_Paging');
	multicurrency_UseOfFundsPopup__crumb__ = PcfComponent('#Multicurrency_UseOfFundsPopup-__crumb__');
	multicurrency_UseOfFundsPopup_msgs = PcfButton('#Multicurrency_UseOfFundsPopup-_msgs');
	multicurrency_UseOfFundsPopupsource = PcfButton('#Multicurrency_UseOfFundsPopup-source');
}

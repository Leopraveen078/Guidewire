import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class ReversePaymentBatchPopup {
	reversePaymentBatchPopupReversePaymentBatchPopup_UpLink = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchPopup_UpLink');
	reversePaymentBatchScreenBatchCategoryLOBHeader = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-BatchCategoryLOBHeader');
	reversePaymentBatchScreenBatchIDHeader = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-BatchIDHeader');
	reversePaymentBatchScreenBatchStatusHeader = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-BatchStatusHeader');
	reversePaymentBatchScreenBatchValueHeader = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-BatchValueHeader');
	reversePaymentBatchScreenCancel = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-Cancel');
	reversePaymentBatchScreenDepositIDHeader = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-DepositIDHeader');
	reversePaymentBatchScreenEdit = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-Edit');
	reversePaymentBatchScreenPaymentCountHeader = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-PaymentCountHeader');
	reversePaymentBatchScreenUpdate = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-Update');
	reversePaymentBatchScreen_ListPaging = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-_ListPaging');
	reversePaymentBatchScreen_msgs = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-_msgs');
	reversePaymentBatchScreenpaymentsourceHeader = PcfButton('#ReversePaymentBatchPopup-ReversePaymentBatchScreen-paymentsourceHeader');
	reversePaymentBatchPopup_Paging = PcfButton('#ReversePaymentBatchPopup-_Paging');
	reversePaymentBatchPopup__crumb__ = PcfComponent('#ReversePaymentBatchPopup-__crumb__');
}

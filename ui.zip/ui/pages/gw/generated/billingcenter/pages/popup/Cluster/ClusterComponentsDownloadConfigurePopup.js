import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class ClusterComponentsDownloadConfigurePopup {
	clusterComponentsDownloadConfigurePopupClusterComponentsDownloadConfigurePopup_UpLink = PcfButton('#ClusterComponentsDownloadConfigurePopup-ClusterComponentsDownloadConfigurePopup_UpLink');
	clusterComponentsDownloadConfigurePopup_Paging = PcfButton('#ClusterComponentsDownloadConfigurePopup-_Paging');
	clusterComponentsDownloadConfigurePopup__crumb__ = PcfComponent('#ClusterComponentsDownloadConfigurePopup-__crumb__');
	clusterComponentsDownloadConfigurePopup_msgs = PcfButton('#ClusterComponentsDownloadConfigurePopup-_msgs');
	clusterComponentsDownloadConfigurePopupdownload = PcfButton('#ClusterComponentsDownloadConfigurePopup-download');
	clusterComponentsDownloadConfigurePopupmaxDays = PcfTextInput('#ClusterComponentsDownloadConfigurePopup-maxDays');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class PolicyLocationAdder {
	policyLocationAdderAdd = PcfButton('#PolicyLocationAdder-Add');
	policyLocationAdderCancel = PcfButton('#PolicyLocationAdder-Cancel');
	policyLocationAdderEdit = PcfButton('#PolicyLocationAdder-Edit');
	policyLocationAdderPolicyLocationAdder_UpLink = PcfButton('#PolicyLocationAdder-PolicyLocationAdder_UpLink');
	policyLocationAdderRemove = PcfButton('#PolicyLocationAdder-Remove');
	policyLocationAdderUpdate = PcfButton('#PolicyLocationAdder-Update');
	policyLocationAdder_ListPaging = PcfButton('#PolicyLocationAdder-_ListPaging');
	policyLocationAdder_Paging = PcfButton('#PolicyLocationAdder-_Paging');
	policyLocationAdder__crumb__ = PcfComponent('#PolicyLocationAdder-__crumb__');
	policyLocationAdder_msgs = PcfButton('#PolicyLocationAdder-_msgs');
	policyLocationAddernameHeader = PcfButton('#PolicyLocationAdder-nameHeader');
	policyLocationAdderzipHeader = PcfButton('#PolicyLocationAdder-zipHeader');
}

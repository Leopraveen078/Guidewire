import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class PolicyDetailPayments {
	policyDetailPaymentsScreenAccountDBA = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-AccountDBA');
	policyDetailPaymentsScreenAccountName = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-AccountName');
	policyDetailPaymentsScreenAccountNumber = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-AccountNumber');
	policyDetailPaymentsScreenActualPaymentsCardTab = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-ActualPaymentsCardTab');
	policyDetailPaymentsScreenAlreadyChangedPlanAlert = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-AlreadyChangedPlanAlert');
	alreadyChangedPlanAlertCloseBtn = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-AlreadyChangedPlanAlert-CloseBtn');
	policyDetailPaymentsScreenAmountReceived = PcfTextInput('#PolicyDetailPayments-PolicyDetailPaymentsScreen-AmountReceived');
	policyDetailPaymentsScreenAverageInstallmentAmount = PcfTextInput('#PolicyDetailPayments-PolicyDetailPaymentsScreen-AverageInstallmentAmount');
	policyDetailPaymentsScreenBalance = PcfTextInput('#PolicyDetailPayments-PolicyDetailPaymentsScreen-Balance');
	policyDetailPaymentsScreenCancelButton = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-CancelButton');
	policyDetailPaymentsScreenChangePaymentPlan = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-ChangePaymentPlan');
	policyDetailPaymentsScreenDeposit = PcfTextInput('#PolicyDetailPayments-PolicyDetailPaymentsScreen-Deposit');
	policyDetailPaymentsScreenDepositPercent = PcfTextInput('#PolicyDetailPayments-PolicyDetailPaymentsScreen-DepositPercent');
	policyDetailPaymentsScreenDistItemsDetailLV = PcfListView('#PolicyDetailPayments-PolicyDetailPaymentsScreen-DistItemsDetailLV');
	policyDetailPaymentsScreenInvoiceItemsLV = PcfListView('#PolicyDetailPayments-PolicyDetailPaymentsScreen-InvoiceItemsLV');
	policyDetailPaymentsScreenLatestLastInvoiceSent = PcfTextInput('#PolicyDetailPayments-PolicyDetailPaymentsScreen-LatestLastInvoiceSent');
	policyDetailPaymentsScreenListBillOrPFC = PcfComponent('#PolicyDetailPayments-PolicyDetailPaymentsScreen-ListBillOrPFC');
	policyDetailPaymentsScreenNumPayments = PcfTextInput('#PolicyDetailPayments-PolicyDetailPaymentsScreen-NumPayments');
	policyDetailPaymentsScreenPaymentPlan = PcfTextInput('#PolicyDetailPayments-PolicyDetailPaymentsScreen-PaymentPlan');
	policyDetailPaymentsScreenPaymentPlanChangeOption = PcfComponent('#PolicyDetailPayments-PolicyDetailPaymentsScreen-PaymentPlanChangeOption');
	policyDetailPaymentsScreenRedistribute = PcfComponent('#PolicyDetailPayments-PolicyDetailPaymentsScreen-Redistribute');
	policyDetailPaymentsScreenRefactor_Button = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-Refactor_Button');
	policyDetailPaymentsScreenScheduledPaymentsCardTab = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-ScheduledPaymentsCardTab');
	policyDetailPaymentsScreenTotalScheduledPayments = PcfTextInput('#PolicyDetailPayments-PolicyDetailPaymentsScreen-TotalScheduledPayments');
	policyDetailPaymentsScreenUnbilledBalance = PcfTextInput('#PolicyDetailPayments-PolicyDetailPaymentsScreen-UnbilledBalance');
	policyDetailPaymentsScreenUpdateButton = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-UpdateButton');
	policyDetailPaymentsScreen_msgs = PcfButton('#PolicyDetailPayments-PolicyDetailPaymentsScreen-_msgs');
	policyDetailPaymentsPolicyDetailPayments_UpLink = PcfButton('#PolicyDetailPayments-PolicyDetailPayments_UpLink');
	policyDetailPayments_Paging = PcfButton('#PolicyDetailPayments-_Paging');
	policyDetailPayments__crumb__ = PcfComponent('#PolicyDetailPayments-__crumb__');
}

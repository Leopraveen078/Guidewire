import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class PolicyPeriodActivitiesPage {
	policyPeriodActivitiesPageActivityFilter = PcfSelectInput('#PolicyPeriodActivitiesPage-ActivityFilter');
	policyPeriodActivitiesPageActivityPattern = PcfSelectInput('#PolicyPeriodActivitiesPage-ActivityPattern');
	policyPeriodActivitiesPageCreateDateHeader = PcfButton('#PolicyPeriodActivitiesPage-CreateDateHeader');
	policyPeriodActivitiesPageEscalatedHeader = PcfButton('#PolicyPeriodActivitiesPage-EscalatedHeader');
	policyPeriodActivitiesPagePolicyActivitySubtypesFilter = PcfSelectInput('#PolicyPeriodActivitiesPage-PolicyActivitySubtypesFilter');
	policyPeriodActivitiesPagePolicyPeriodActivitiesPage_UpLink = PcfButton('#PolicyPeriodActivitiesPage-PolicyPeriodActivitiesPage_UpLink');
	policyPeriodActivitiesPage_ListPaging = PcfButton('#PolicyPeriodActivitiesPage-_ListPaging');
	policyPeriodActivitiesPage_Paging = PcfButton('#PolicyPeriodActivitiesPage-_Paging');
	policyPeriodActivitiesPage__crumb__ = PcfComponent('#PolicyPeriodActivitiesPage-__crumb__');
	policyPeriodActivitiesPage_msgs = PcfButton('#PolicyPeriodActivitiesPage-_msgs');
	policyPeriodActivitiesPageassignedToHeader = PcfButton('#PolicyPeriodActivitiesPage-assignedToHeader');
	policyPeriodActivitiesPageduedateHeader = PcfButton('#PolicyPeriodActivitiesPage-duedateHeader');
	policyPeriodActivitiesPagepriorityHeader = PcfButton('#PolicyPeriodActivitiesPage-priorityHeader');
	policyPeriodActivitiesPagestatusHeader = PcfButton('#PolicyPeriodActivitiesPage-statusHeader');
	policyPeriodActivitiesPagesubjectHeader = PcfButton('#PolicyPeriodActivitiesPage-subjectHeader');
}

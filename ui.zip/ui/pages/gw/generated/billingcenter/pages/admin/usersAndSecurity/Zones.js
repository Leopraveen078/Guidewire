import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class Zones {
	zonesPageZonesPage_UpLink = PcfButton('#ZonesPage-ZonesPage_UpLink');
	zonesScreenRemoveButton_SP = PcfButton('#ZonesPage-ZonesScreen-RemoveButton_SP');
	zonesScreenSP_AddZone = PcfButton('#ZonesPage-ZonesScreen-SP_AddZone');
	zonesScreenZonesLV = PcfListView('#ZonesPage-ZonesScreen-ZonesLV');
	zonesScreen_msgs = PcfButton('#ZonesPage-ZonesScreen-_msgs');
	zonesPage_Paging = PcfButton('#ZonesPage-_Paging');
	zonesPage__crumb__ = PcfComponent('#ZonesPage-__crumb__');
	zonesZones_UpLink = PcfButton('#Zones-Zones_UpLink');
	zones_Paging = PcfButton('#Zones-_Paging');
	zones__crumb__ = PcfComponent('#Zones-__crumb__');
	zones_msgs = PcfButton('#Zones-_msgs');
	zonesactWizard = PcfButton('#Zones-actWizard');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class MessageHistorySearch {
	messageHistorySearchMessageHistorySearch_UpLink = PcfButton('#MessageHistorySearch-MessageHistorySearch_UpLink');
	messageSearchScreenMessageHistoryResultsLV = PcfListView('#MessageHistorySearch-MessageSearchScreen-MessageHistoryResultsLV');
	messageHistoryResultsLV_tbReprocessMessages = PcfButton('#MessageHistorySearch-MessageSearchScreen-MessageHistoryResultsLV_tb-ReprocessMessages');
	messageHistoryResultsLV_tbReprocessMessagesArchiveOnly = PcfButton('#MessageHistorySearch-MessageSearchScreen-MessageHistoryResultsLV_tb-ReprocessMessagesArchiveOnly');
	messageHistoryResultsLV_tbReprocessMessagesPrintEmailOnly = PcfButton('#MessageHistorySearch-MessageSearchScreen-MessageHistoryResultsLV_tb-ReprocessMessagesPrintEmailOnly');
	messageSearchDVDestination = PcfSelectInput('#MessageHistorySearch-MessageSearchScreen-MessageSearchDV-Destination');
	messageSearchDVEventName = PcfTextInput('#MessageHistorySearch-MessageSearchScreen-MessageSearchDV-EventName');
	messageSearchDVFromDate = PcfDateValueInput('#MessageHistorySearch-MessageSearchScreen-MessageSearchDV-FromDate');
	messageSearchDVInvoiceNumber = PcfTextInput('#MessageHistorySearch-MessageSearchScreen-MessageSearchDV-InvoiceNumber');
	messageSearchDVPolicyNumber = PcfTextInput('#MessageHistorySearch-MessageSearchScreen-MessageSearchDV-PolicyNumber');
	messageSearchDVPolicyTermNumber = PcfTextInput('#MessageHistorySearch-MessageSearchScreen-MessageSearchDV-PolicyTermNumber');
	messageHistorySearchMessageSearchScreenMessageSearchDVSearchAndResetInputSetSearchLinksInputSetReset = PcfButton('#MessageHistorySearch-MessageSearchScreen-MessageSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Reset');
	messageHistorySearchMessageSearchScreenMessageSearchDVSearchAndResetInputSetSearchLinksInputSetSearch = PcfButton('#MessageHistorySearch-MessageSearchScreen-MessageSearchDV-SearchAndResetInputSet-SearchLinksInputSet-Search');
	messageSearchDVSenderRefId = PcfTextInput('#MessageHistorySearch-MessageSearchScreen-MessageSearchDV-SenderRefId');
	messageSearchDVToDate = PcfDateValueInput('#MessageHistorySearch-MessageSearchScreen-MessageSearchDV-ToDate');
	messageSearchScreen_msgs = PcfButton('#MessageHistorySearch-MessageSearchScreen-_msgs');
	messageHistorySearch_Paging = PcfButton('#MessageHistorySearch-_Paging');
	messageHistorySearch__crumb__ = PcfComponent('#MessageHistorySearch-__crumb__');
}

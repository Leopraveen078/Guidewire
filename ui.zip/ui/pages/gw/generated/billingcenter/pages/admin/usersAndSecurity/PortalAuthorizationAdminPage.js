import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfTextInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class PortalAuthorizationAdminPage {
	portalAuthAdminScreenPortalAuthUsersLV = PcfListView('#PortalAuthorizationAdminPage-PortalAuthAdminScreen-PortalAuthUsersLV');
	portalAuthUsersLV_tbToolbarButton = PcfButton('#PortalAuthorizationAdminPage-PortalAuthAdminScreen-PortalAuthUsersLV_tb-ToolbarButton');
	portalAuthUsersLV_tbToolbarButtonCreate = PcfButton('#PortalAuthorizationAdminPage-PortalAuthAdminScreen-PortalAuthUsersLV_tb-ToolbarButtonCreate');
	portalAuthUsersLV_tbUserDeleteButton = PcfButton('#PortalAuthorizationAdminPage-PortalAuthAdminScreen-PortalAuthUsersLV_tb-UserDeleteButton');
	portalUserSearchFieldsDVSearchUsersFirstNameInput = PcfTextInput('#PortalAuthorizationAdminPage-PortalAuthAdminScreen-PortalUserSearchFieldsDV-SearchUsersFirstNameInput');
	portalUserSearchFieldsDVSearchUsersSurameInput = PcfTextInput('#PortalAuthorizationAdminPage-PortalAuthAdminScreen-PortalUserSearchFieldsDV-SearchUsersSurameInput');
	portalUserSearchFieldsDVSearchUsersUserNameInput = PcfTextInput('#PortalAuthorizationAdminPage-PortalAuthAdminScreen-PortalUserSearchFieldsDV-SearchUsersUserNameInput');
	portalAuthAdminScreen_msgs = PcfButton('#PortalAuthorizationAdminPage-PortalAuthAdminScreen-_msgs');
	portalAuthorizationAdminPagePortalAuthorizationAdminPage_UpLink = PcfButton('#PortalAuthorizationAdminPage-PortalAuthorizationAdminPage_UpLink');
	portalAuthorizationAdminPage_Paging = PcfButton('#PortalAuthorizationAdminPage-_Paging');
	portalAuthorizationAdminPage__crumb__ = PcfComponent('#PortalAuthorizationAdminPage-__crumb__');
}

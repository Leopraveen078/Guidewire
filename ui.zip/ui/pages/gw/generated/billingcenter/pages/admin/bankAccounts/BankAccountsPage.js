import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class BankAccountsPage {
	bankAccountsPageBankAccount_addNewBankAccount = PcfButton('#BankAccountsPage-BankAccount_addNewBankAccount');
	bankAccountsPageBankAccountsLV = PcfListView('#BankAccountsPage-BankAccountsLV');
	bankAccountsPageBankAccountsPage_UpLink = PcfButton('#BankAccountsPage-BankAccountsPage_UpLink');
	bankAccountsPage_Paging = PcfButton('#BankAccountsPage-_Paging');
	bankAccountsPage__crumb__ = PcfComponent('#BankAccountsPage-__crumb__');
	bankAccountsPage_msgs = PcfButton('#BankAccountsPage-_msgs');
	bankAccountsPageremoveBankAccount = PcfButton('#BankAccountsPage-removeBankAccount');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class AdminBatchProcessInfo {
	adminBatchProcessInfoAdminBatchProcessInfo_UpLink = PcfButton('#AdminBatchProcessInfo-AdminBatchProcessInfo_UpLink');
	batchProcessScreenBatchProcessesLV = PcfListView('#AdminBatchProcessInfo-BatchProcessScreen-BatchProcessesLV');
	batchProcessesLV_tbdownload = PcfButton('#AdminBatchProcessInfo-BatchProcessScreen-BatchProcessesLV_tb-download');
	batchProcessesLV_tbrefresh = PcfButton('#AdminBatchProcessInfo-BatchProcessScreen-BatchProcessesLV_tb-refresh');
	batchProcessesLV_tbresumeScheduler = PcfButton('#AdminBatchProcessInfo-BatchProcessScreen-BatchProcessesLV_tb-resumeScheduler');
	batchProcessesLV_tbsuspendScheduler = PcfButton('#AdminBatchProcessInfo-BatchProcessScreen-BatchProcessesLV_tb-suspendScheduler');
	procuessHistoryCVBatchProcessInfo_ProcessHistoryLV = PcfListView('#AdminBatchProcessInfo-BatchProcessScreen-ProcuessHistoryCV-BatchProcessInfo_ProcessHistoryLV');
	procuessHistoryCVProcessHistoryChartTabTab = PcfButton('#AdminBatchProcessInfo-BatchProcessScreen-ProcuessHistoryCV-ProcessHistoryChartTabTab');
	procuessHistoryCVProcessHistoryTabTab = PcfButton('#AdminBatchProcessInfo-BatchProcessScreen-ProcuessHistoryCV-ProcessHistoryTabTab');
	batchProcessScreenSchedulerSuspendedAlert = PcfButton('#AdminBatchProcessInfo-BatchProcessScreen-SchedulerSuspendedAlert');
	schedulerSuspendedAlertCloseBtn = PcfButton('#AdminBatchProcessInfo-BatchProcessScreen-SchedulerSuspendedAlert-CloseBtn');
	batchProcessScreen_msgs = PcfButton('#AdminBatchProcessInfo-BatchProcessScreen-_msgs');
	adminBatchProcessInfo_Paging = PcfButton('#AdminBatchProcessInfo-_Paging');
	adminBatchProcessInfo__crumb__ = PcfComponent('#AdminBatchProcessInfo-__crumb__');
}

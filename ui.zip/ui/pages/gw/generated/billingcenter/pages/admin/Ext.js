import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class Ext {
	feeOverridesScreenBackupWithhold_ExtLV = PcfListView('#FeeOverrides_Ext-FeeOverridesScreen-BackupWithhold_ExtLV');
	backupWithhold_ExtLV_tbBackupWithholding_addNew = PcfButton('#FeeOverrides_Ext-FeeOverridesScreen-BackupWithhold_ExtLV_tb-BackupWithholding_addNew');
	backupWithhold_ExtLV_tbBackupWithholding_remove = PcfButton('#FeeOverrides_Ext-FeeOverridesScreen-BackupWithhold_ExtLV_tb-BackupWithholding_remove');
	feeOverridesScreenBackupWithholdingRatesCVTab = PcfButton('#FeeOverrides_Ext-FeeOverridesScreen-BackupWithholdingRatesCVTab');
	feeOverridesScreenInstallmentFeesCVTab = PcfButton('#FeeOverrides_Ext-FeeOverridesScreen-InstallmentFeesCVTab');
	feeOverridesScreenInstallmentFees_ExtLV = PcfListView('#FeeOverrides_Ext-FeeOverridesScreen-InstallmentFees_ExtLV');
	installmentFees_ExtLV_tbAdd = PcfButton('#FeeOverrides_Ext-FeeOverridesScreen-InstallmentFees_ExtLV_tb-Add');
	installmentFees_ExtLV_tbCancel = PcfButton('#FeeOverrides_Ext-FeeOverridesScreen-InstallmentFees_ExtLV_tb-Cancel');
	installmentFees_ExtLV_tbEdit = PcfButton('#FeeOverrides_Ext-FeeOverridesScreen-InstallmentFees_ExtLV_tb-Edit');
	installmentFees_ExtLV_tbRemove = PcfButton('#FeeOverrides_Ext-FeeOverridesScreen-InstallmentFees_ExtLV_tb-Remove');
	installmentFees_ExtLV_tbUpdate = PcfButton('#FeeOverrides_Ext-FeeOverridesScreen-InstallmentFees_ExtLV_tb-Update');
	feeOverridesScreen_msgs = PcfButton('#FeeOverrides_Ext-FeeOverridesScreen-_msgs');
	feeOverrides_ExtFeeOverrides_Ext_UpLink = PcfButton('#FeeOverrides_Ext-FeeOverrides_Ext_UpLink');
	feeOverrides_Ext_Paging = PcfButton('#FeeOverrides_Ext-_Paging');
	feeOverrides_Ext__crumb__ = PcfComponent('#FeeOverrides_Ext-__crumb__');
}

import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';

export class GLIntegration {
	gLIntegrationAdd = PcfButton('#GLIntegration-Add');
	gLIntegrationCancel = PcfButton('#GLIntegration-Cancel');
	gLIntegrationEdit = PcfButton('#GLIntegration-Edit');
	gLIntegrationGLIntegration_UpLink = PcfButton('#GLIntegration-GLIntegration_UpLink');
	gLIntegrationRemove = PcfButton('#GLIntegration-Remove');
	gLIntegrationUpdate = PcfButton('#GLIntegration-Update');
	gLIntegration_Paging = PcfButton('#GLIntegration-_Paging');
	gLIntegration__crumb__ = PcfComponent('#GLIntegration-__crumb__');
	gLIntegration_msgs = PcfButton('#GLIntegration-_msgs');
	accountRowIteratorId_ListPaging = PcfButton('#GLIntegration-accountRowIteratorId-_ListPaging');
	accountRowIteratorIdbankCodeHeader = PcfButton('#GLIntegration-accountRowIteratorId-bankCodeHeader');
	accountRowIteratorIdcombAcntIndHeader = PcfButton('#GLIntegration-accountRowIteratorId-combAcntIndHeader');
	accountRowIteratorIdcompany1Header = PcfButton('#GLIntegration-accountRowIteratorId-company1Header');
	accountRowIteratorIdglCodeIdHeader = PcfButton('#GLIntegration-accountRowIteratorId-glCodeIdHeader');
	accountRowIteratorIdglNameIdHeader = PcfButton('#GLIntegration-accountRowIteratorId-glNameIdHeader');
	accountRowIteratorIdglPolicyType1Header = PcfButton('#GLIntegration-accountRowIteratorId-glPolicyType1Header');
	filtersRowIteratorId_ListPaging = PcfButton('#GLIntegration-filtersRowIteratorId-_ListPaging');
	filtersRowIteratorIdtransactionTypeIdHeader = PcfButton('#GLIntegration-filtersRowIteratorId-transactionTypeIdHeader');
	gLIntegrationglAccountIdTab = PcfButton('#GLIntegration-glAccountIdTab');
	mappingsRowIteratorId_ListPaging = PcfButton('#GLIntegration-mappingsRowIteratorId-_ListPaging');
	mappingsRowIteratorIdbankCodeHeader = PcfButton('#GLIntegration-mappingsRowIteratorId-bankCodeHeader');
	mappingsRowIteratorIdcombAcntIndHeader = PcfButton('#GLIntegration-mappingsRowIteratorId-combAcntIndHeader');
	mappingsRowIteratorIdcompanyHeader = PcfButton('#GLIntegration-mappingsRowIteratorId-companyHeader');
	mappingsRowIteratorIdglMappingCodeIdHeader = PcfButton('#GLIntegration-mappingsRowIteratorId-glMappingCodeIdHeader');
	mappingsRowIteratorIdglPolicyTypeHeader = PcfButton('#GLIntegration-mappingsRowIteratorId-glPolicyTypeHeader');
	mappingsRowIteratorIdglTransactionSourceHeader = PcfButton('#GLIntegration-mappingsRowIteratorId-glTransactionSourceHeader');
	mappingsRowIteratorIdtAccountPatternIdHeader = PcfButton('#GLIntegration-mappingsRowIteratorId-tAccountPatternIdHeader');
	mappingsRowIteratorIdtransactionTypeIdHeader = PcfButton('#GLIntegration-mappingsRowIteratorId-transactionTypeIdHeader');
	gLIntegrationtransactionFilterIdTab = PcfButton('#GLIntegration-transactionFilterIdTab');
	gLIntegrationtransactionMappingIdTab = PcfButton('#GLIntegration-transactionMappingIdTab');
}

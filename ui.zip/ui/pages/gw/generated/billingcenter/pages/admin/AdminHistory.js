import { PcfComponent } from '@gtui/gt-ui-framework';
import { PcfDateValueInput } from '@gtui/gt-ui-framework';
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfButton } from '@gtui/gt-ui-framework';
import { PcfListView } from '@gtui/gt-ui-framework';

export class AdminHistory {
	adminHistorySearchDVModifiedAdmin = PcfButton('#AdminHistory-AdminHistorySearchDV-ModifiedAdmin');
	adminHistorySearchDVModifiedBy = PcfButton('#AdminHistory-AdminHistorySearchDV-ModifiedBy');
	modifiedBySelectUsers = PcfButton('#AdminHistory-AdminHistorySearchDV-ModifiedBy-SelectUsers');
	modifiedByUserBrowseMenuItem = PcfComponent('#AdminHistory-AdminHistorySearchDV-ModifiedBy-UserBrowseMenuItem');
	adminHistorySearchDVModifiedGroup = PcfSelectInput('#AdminHistory-AdminHistorySearchDV-ModifiedGroup');
	adminHistorySearchDVModifiedRole = PcfSelectInput('#AdminHistory-AdminHistorySearchDV-ModifiedRole');
	adminHistorySearchDVModifiedUser = PcfButton('#AdminHistory-AdminHistorySearchDV-ModifiedUser');
	modifiedUserSelectUsers = PcfButton('#AdminHistory-AdminHistorySearchDV-ModifiedUser-SelectUsers');
	modifiedUserUserBrowseMenuItem = PcfComponent('#AdminHistory-AdminHistorySearchDV-ModifiedUser-UserBrowseMenuItem');
	adminHistorySearchDVSearchEndDate = PcfDateValueInput('#AdminHistory-AdminHistorySearchDV-SearchEndDate');
	adminHistorySearchDVStartDate = PcfDateValueInput('#AdminHistory-AdminHistorySearchDV-StartDate');
	adminHistoryAdminHistorySearchResultsLV = PcfListView('#AdminHistory-AdminHistorySearchResultsLV');
	adminHistorySearchResultsLV_tbPrintMe = PcfButton('#AdminHistory-AdminHistorySearchResultsLV_tb-PrintMe');
	adminHistoryAdminHistory_UpLink = PcfButton('#AdminHistory-AdminHistory_UpLink');
	adminHistoryClearButton = PcfButton('#AdminHistory-ClearButton');
	adminHistorySearchButton = PcfButton('#AdminHistory-SearchButton');
	adminHistory_Paging = PcfButton('#AdminHistory-_Paging');
	adminHistory__crumb__ = PcfComponent('#AdminHistory-__crumb__');
	adminHistory_msgs = PcfButton('#AdminHistory-_msgs');
}

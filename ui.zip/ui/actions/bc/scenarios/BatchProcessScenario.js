import { t } from "testcafe";
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfComponent } from '@gtui/gt-ui-framework';
import { captureScreenshot } from "../../../util/common/helper.js";
import { BatchProcessScreen_Ext } from "../../../pages/gw/ScenarioPages/Other/BatchProcessScreen_Ext";
import { setStepDescription } from "../../../util/common/setStepDescription.js";
import { BatchProcessInfo } from "../../../pages/gw/generated/billingcenter/pages/serverTools/BatchProcessInfo.js";
import { ServerToolsMenuLinks } from "../../../pages/gw/generated/billingcenter/pages/navigation/menuLinks/ServerToolsMenuLinks.js";

const stepDescription = new setStepDescription();
const otherConstants = require("../../../util/common/otherConstantsFile.js");
const batchProcessScreen_ext = new BatchProcessScreen_Ext();
const batchProcessInfo = new BatchProcessInfo();
const serverToolsMenuLinks = new ServerToolsMenuLinks();

export class BatchProcessScenarios {
    constructor() {
        this.pageName = ""
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await batchProcessScreen_ext.serverToolsInternalToolsMenuActions.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async runBatchProcess(fileObj, batchName) {
        try {
            // Action 'alt+shift+t'
            this.pageName = "Work Queue Info"
            this.stepAction = "Navigate to Server Tool > Batch Process Page<br>";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            console.log("Navigating to Batch Process..");
            this.stepAction += "Pressing 'alt+shift+t' keys...<br>";
            await t.pressKey("alt+shift+t");

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            await this.confirmPageNavigation(fileObj);

            // To Batch process
            await serverToolsMenuLinks.menuLinksServerTools_BatchProcessInfo.click();
            this.pageName = "Batch Process Info"
            await this.confirmPageNavigation(fileObj);

            this.stepAction = "Running the Batch - " + batchName;
            this.stepER = "Action Step, Verification N/A"

            console.log("Running the Batch Process - " + batchName)
            let invoiceNameCell = batchProcessInfo.batchProcessInfoBatchProcessScreenBatchProcessesLV.component.find('td[id$=-BatchProcess_Cell]').withExactText(batchName);
            let selectButton = invoiceNameCell.sibling('td[id$=-RunBatchWithoutNotifyContent]').find('div.gw-LinkWidget[id$=-RunBatchWithoutNotify]');
            await t.click(selectButton).wait(10000);

            this.stepAR = "Successfully ran '" + batchName + "' batch";
            this.verdict = "Passed"
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            console.log("Return to Policy Center")
            this.stepAction = "Return to Policy Center";
            this.stepER = "Action Step, Verification N/A";
            this.stepAR = "";
            this.verdict = ""
            await batchProcessScreen_ext.serverToolsInternalToolsMenuActions.click();
            await batchProcessScreen_ext.internalToolsMenuActionsReturnToApp.click();
            await t.wait(5000);
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on Running Batch Process"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }

    }

}
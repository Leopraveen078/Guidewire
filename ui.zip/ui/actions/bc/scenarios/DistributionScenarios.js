import { AccountGroupMenuActions } from "../../../pages/gw/generated/billingcenter/pages//navigation/menuActions/AccountGroupMenuActions"
import { AccountGroupMenuLinks } from "../../../pages/gw/generated/billingcenter/pages//navigation/menuLinks/AccountGroupMenuLinks"
import { AccountSummary } from "../../../pages/gw/generated/billingcenter/pages//accountGroup/accountOverview/AccountSummary"
import { NewDirectBillPayment } from "../../../pages/gw/generated/billingcenter/pages//other/NewDirectBillPayment"
import { AccountScenarios } from "./AccountScenarios"
import { AdminScenarios } from "./AdminScenarios"
//Imports to support Accessibility Scanning
import { AxeScanWrapper } from "@gtui/gt-ui-framework"

import { t } from "testcafe";

const accountGroupMenuLinks = new AccountGroupMenuLinks();
const accountGroupMenuActions = new AccountGroupMenuActions();
const newDirectBillPayment = new NewDirectBillPayment();
const accountScenarios = new AccountScenarios();
const adminScenarios = new AdminScenarios();


export class DistributionScenarios {

    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async makeCreditDistributionForAccount(accountNumber) {
        await accountScenarios.openAccount(accountNumber);
        await accountGroupMenuActions.selectAccountGroupAccountDetailMenuActionsAccountDetailMenuActions_PaymentsAccountDetailMenuActions_NewDirectBillPaymentMenuItem();
        await newDirectBillPayment.setValueNewDirectBillPaymentEditDBPaymentScreenPaymentDetailsDVAmountTextInput("0.01");
        await newDirectBillPayment.clickNewDirectBillPaymentEditDBPaymentScreenPaymentDetailsExecuteWithoutDistribution()
    }

    async makePaymentDistribution(amtDistributed) {
        await accountGroupMenuActions.accountGroupAccountDetailMenuActions.click();
        await accountGroupMenuActions.accountDetailMenuActionsAccountDetailMenuActions_Payments.click();
        await accountGroupMenuActions.accountDetailMenuActionsAccountDetailMenuActions_Payments.click();
        await accountGroupMenuActions.accountDetailMenuActions_PaymentsAccountDetailMenuActions_NewDirectBillPayment.click();
        if(amtDistributed == "full amount")
            amtDistributed = data.invoiceAmount;
        await newDirectBillPayment.newDirectBillPaymentEditDBPaymentScreenPaymentDetailsDVAmount.setValue(amtDistributed);
        await newDirectBillPayment.newDirectBillPaymentEditDBPaymentScreenExecuteWithoutDistribution.click();
    }

    async distributeUnappliedAmount(messagePathSelector){
        await adminScenarios.runBatchProcessInvoice(messagePathSelector);
        await adminScenarios.runBatchProcessNewPayment(messagePathSelector);
    }

    async getUnappliedAmount(t){
        await accountGroupMenuLinks.accountGroup_AccountOverviewAccountOverview_AccountSummary.click();

        //Accessibility Scanning 
        let accountSummary = AxeScanWrapper(AccountSummary,t);    

        let response = await accountSummary.accountSummaryScreenAccountUnappliedAmount.getValue();
        return response;
    }
}
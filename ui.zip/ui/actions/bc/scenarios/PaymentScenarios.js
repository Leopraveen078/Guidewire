import { AccountDetailSummary } from "../../../pages/gw/generated/billingcenter/pages/accountGroup/accountOverview/AccountDetailSummary"
// import { AccountDetailSummaryCustom } from "../scenarios/ScenarioPages/accountGroup/accountOverview/AccountDetailSummary"
// import { AccountDetailSummaryCustom } from "./ScenarioPages/accountGroup/accountOverview/AccountDetailSummary"
import { AccountGroupMenuLinks } from "../../../pages/gw/generated/billingcenter/pages//navigation/menuLinks/AccountGroupMenuLinks"
import { AccountPaymentRequests } from "../../../pages/gw/generated/billingcenter/pages//accountGroup/accountDetailPayments/AccountPaymentRequests"
import { AccountSummary } from "../../../pages/gw/generated/billingcenter/pages//accountGroup/accountOverview/AccountSummary"
import { NewPaymentInstrumentPopup } from "../../../pages/gw/generated/billingcenter/pages//popup/New/NewPaymentInstrumentPopup"
import { AdminScenarios } from "./AdminScenarios";
import { Selector, t } from "testcafe";
import { Accounts } from "../../../pages/gw/generated/billingcenter/pages/accountsGroup/Accounts"
import { InvoicePage } from "./InvoicePage" 
import { AccountGroupMenuActions } from "../../../pages/gw/generated/billingcenter/pages/navigation/menuActions/AccountGroupMenuActions";
import { NewDirectBillPayment } from "../../../pages/gw/generated/billingcenter/pages/other/NewDirectBillPayment"
// import { amount } from "../../../util/testData/TC_022_PL_HO6"
import { selectDropdown, captureScreenshot} from "../../../util/common/helper"


const accountDetailSummary = new AccountDetailSummary();
// const accountDetailSummaryCustom = new AccountDetailSummaryCustom();
const accountGroupMenuLinks = new AccountGroupMenuLinks();
const accountPaymentRequests = new AccountPaymentRequests();
const accountSummary = new AccountSummary();
const newPaymentInstrumentPopup = new NewPaymentInstrumentPopup();
const adminScenarios = new AdminScenarios();
const accounts = new Accounts();
const invoicePage = new InvoicePage();
const accountGroupMenuActions = new AccountGroupMenuActions();
const newDirectBillPayment = new NewDirectBillPayment();

export class PaymentScenarios {

    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async checkPaymentInstrument() {
        await accountGroupMenuLinks.accountGroup_AccountOverviewAccountOverview_AccountSummary.click();

        let paymentMethod = await accountSummary.accountSummaryScreenPaymentMethod.getValue();
        let paymentInstrument;
        if (paymentMethod.includes('ACH/EFT')) {
            paymentInstrument = "EFT/ACH";
        } else if (paymentMethod.includes('Credit Card')) {
            paymentInstrument = "CC";
        } else {
            paymentInstrument = "Responsive";
        }
        return paymentInstrument;
    }

    async addNonResponsiveEFT_ACH() {
        let response = await this.checkPaymentInstrument();
        if (!(response.includes("EFT/ACH"))) {
            await accountDetailSummary.accountDetailSummaryScreenEdit.click();
            await accountDetailSummary.defaultPaymentInstrumentCreateNewPaymentInstrument.click();
            let randomNumber = Math.floor(Math.random() * 999 + 1);
            await newPaymentInstrumentPopup.newPaymentInstrumentPopupPaymentMethod.selectOptionByLabel('ACH/EFT');
            await newPaymentInstrumentPopup.newPaymentInstrumentPopupToken.setValue(randomNumber + 'ACH-EFT');
            await newPaymentInstrumentPopup.newPaymentInstrumentPopupUpdate.click();
            await accountDetailSummary.accountDetailSummaryScreenUpdate.click();
        }
    }

    async addResponsive() {
        let response = await this.checkPaymentInstrument();
        if (!(response.includes("Responsive"))) {
            await accountGroupMenuLinks.accountGroup_AccountOverviewAccountOverview_AccountDetailSummary.click();
            await accountDetailSummary.accountDetailSummaryScreenEdit.click();
            await accountDetailSummaryCustom.accountDetailSummaryAccountDetailSummaryScreenAccountDetailDVDefaultPaymentInstrument.selectOptionByLabel('Responsive');
            await accountDetailSummary.accountDetailSummaryScreenUpdate.click();
        }
    }

    async getPaymentRequestStatus() {
        const messageSelectorPath = "#AccountDetailInvoices-AccountDetailInvoicesScreen-_msgs-0-0 > div.gw-message-and-suffix > div"
        await adminScenarios.runBatchProcessInvoice(messageSelectorPath);
        await accountGroupMenuLinks.menuLinksAccountGroup_AccountDetailPayments.click();
        await accountGroupMenuLinks.accountGroup_AccountDetailPaymentsAccountDetailPayments_AccountPaymentRequests.click();
        let rowCount = await accountPaymentRequests.accountDetailPaymentsScreenRequestsListLV.rowCount();
        let status = '';
        if (rowCount > 0) {
            status = await accountPaymentRequests.accountDetailPaymentsScreenRequestsListLV.getTextFromCell(0, 1);
        }
        return status;
    }

    async validatePaymentRequestStatus() {
        await accountGroupMenuLinks.accountGroup_AccountDetailPaymentsAccountDetailPayments_AccountPaymentRequests.click();
        const messageSelectorPath = "#AccountPaymentRequests-AccountDetailPaymentsScreen-_msgs-0-0 > div.gw-message-and-suffix > div";

        await adminScenarios.runBatchProcessPaymentRequest(messageSelectorPath);
        let status = await accountPaymentRequests.accountDetailPaymentsScreenRequestsListLV.getTextFromCell(0, 1);
        return status;
    }

    async verifyDownPaymentStatus(fileObj, accountNumber, status) {
        try {
            this.stepAction = "Verification Step, Action N/A";
            this.stepER = "Verify the Down payment invoice status -" + status;

            await accounts.accountsAccountSearchScreenAccountSearchDVAccountNumberCriterion.setValue(accountNumber);
            await accounts.accountsAccountSearchScreenAccountSearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
            await accounts.accountsAccountSearchScreenAccountSearchResultsLV.clickOnCellByColumnName(0, "Account #");
            await accountGroupMenuLinks.menuLinksAccountGroup_AccountDetailInvoices.click();
            await invoicePage.getStatus(0, 'Billed');

            this.stepAR = "Successfully verified the status as " + status
            this.verdict = "Passed"

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in downpayment status verification"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }

    }

    async makePayment(fileObj, amount) {
        try {
            amount = amount.replace("$", "");
            this.stepAction = "Make payment of Amount $" + amount;
            this.stepER = "Action Step, Verification N/A"
            console.log('Amount to be paid: ' + amount);

            await accountGroupMenuActions.accountGroupAccountDetailMenuActions.click();
            await t.hover(accountGroupMenuActions.accountDetailMenuActionsAccountDetailMenuActions_Payments.component)
            await accountGroupMenuActions.accountDetailMenuActions_PaymentsAccountDetailMenuActions_NewDirectBillPayment.click();
            await newDirectBillPayment.newDirectBillPaymentEditDBPaymentScreenPaymentDetailsDVPolicyPeriod.selectNthOption(1);
            await selectDropdown(newDirectBillPayment.newDirectBillPaymentEditDBPaymentScreenPaymentDetailsDVbankacct_Selector, "Citizens")
            await t.pressKey('tab');
            await t.wait(3000);

            await t.pressKey('delete');
            await t.pressKey('tab');
            await t.pressKey('tab');
            await t.wait(5000);
            await newDirectBillPayment.newDirectBillPaymentEditDBPaymentScreenPaymentDetailsDVAmount.setValue(amount);
            await t.pressKey('tab');
            await t.wait(3000);

            await selectDropdown(newDirectBillPayment.newDirectBillPaymentEditDBPaymentScreenPaymentDetailsDVPaymentInstrument_Selector, "Cash")

            await captureScreenshot();
            await newDirectBillPayment.newDirectBillPaymentEditDBPaymentScreenUpdate.click();
            await t.wait(5000);

            this.stepAR = "Successfully made payment of amount $" + amount

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in making payment"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }

    }

    async verifyPaidAmountOnAccountSummary(fileObj, amount) {
        try {
            this.stepAction = "Verification Step, Action N/A";
            this.stepER = "Verify the paid down payment invoice under BC";
            await accountGroupMenuLinks.accountGroup_AccountOverviewAccountOverview_AccountDetailSummary.click();
            const totalBilledAmountText = await accountDetailSummary.accountDetailDVPoliciesPaidAmount.component.innerText;
            const totalBilledAmount = parseFloat(totalBilledAmountText.replace('$', '').replace(/\s+/g, '').replace(/,/g, ''));

            const totalPaidAmount = parseFloat(amount.replace(/,/g, ''));

            console.log(`Total Billed Amount (Parsed): ${totalBilledAmount}`);
            console.log(`Total Paid Amount (Parsed): ${totalPaidAmount}`);

            await t.expect(totalPaidAmount).eql(totalBilledAmount, 'Total paid amount should be equal to total billed amount');
            this.stepAR = "Successfully verified the paid down payment invoice under BC - " + totalBilledAmountText;
            this.verdict = "Passed";

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in BC Account summary - payment details"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }



}

import { AccountDetailCharges } from "../../../pages/gw/generated/billingcenter/pages/accountGroup/AccountDetailCharges.js"
import { AccountDetailInvoices } from "../../../pages/gw/generated/billingcenter/pages/accountGroup/AccountDetailInvoices.js"
import { AccountGroupMenuLinks } from "../../../pages/gw/generated/billingcenter/pages/navigation/menuLinks/AccountGroupMenuLinks.js"
import { AccountDetailSummary } from "../../../pages/gw/generated/billingcenter/pages/accountGroup/accountOverview/AccountDetailSummary.js"
//import { AccountSummaryCustom } from "./ScenarioPages/accountGroup/accountOverview/AccountSummary"
import { InvoiceItemDetailPopup } from "../../../pages/gw/generated/billingcenter/pages/popup/Invoice/InvoiceItemDetailPopup.js"
import { TransactionDetailPopup } from "../../../pages/gw/generated/billingcenter/pages/popup/Transaction/TransactionDetailPopup.js"
import { ChargeScenarios } from "./ChargeScenarios.js"
import { captureScreenshot } from "../../../util/common/helper.js";

import { t } from "testcafe"
const accountDetailCharges = new AccountDetailCharges();
const accountDetailInvoices = new AccountDetailInvoices();
const accountGroupMenuLinks = new AccountGroupMenuLinks();
//const accountSummaryCustom = new AccountSummaryCustom();
const invoiceItemDetailPopup = new InvoiceItemDetailPopup();
const transactionDetailPopup = new TransactionDetailPopup();
const accountDetailSummary = new AccountDetailSummary();
const chargeScenarios = new ChargeScenarios();

export class InvoicePage {

    constructor() {
        this.pageName = "Invoices"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    // To confirm page navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await accountDetailInvoices.accountDetailInvoices_AccountDetailInvoicesScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async reloadInvoicesPage() {
    }

    async getInvoiceBillDate(row) {
        const billDateColumnIndex = 1;
        let billDate = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(row, billDateColumnIndex);
        return billDate;
    }

    async getInvoiceDueDate(row) {
        const dueDateColumnIndex = 2;
        let dueDate = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(row, dueDateColumnIndex);
        return dueDate;
    }

    async getInvoiceStatus(row) {
        const statusColumnIndex = 5;
        let status = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(row, statusColumnIndex);
        return status;
    }

    async getStatus(row, expectedStatus) {
        const statusColumnIndex = 8;
        let status = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(row, statusColumnIndex);

        // Check if status matches the expected status
        if (status !== expectedStatus) {
            throw new Error(`Expected status to be "${expectedStatus}", but got "${status}".`);
        }

        return status;
    }

    async getInvoiceAmount(row, data) {
        const amountColumnIndex = 9;
        let amountWithDollarSign = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(row, amountColumnIndex);

        // Remove the $ sign and any spaces from the amount
        data.amount = amountWithDollarSign.replace('$', '').replace(/\s+/g, '');
        console.log("Store Amount:", data.amount);
        t.ctx.amount = data.amount
        console.log(`Invoice amount for row ${row}: ${data.amount}`);
        return data.amount;
    }



    async getNextInvoiceWithStatus(status, numInvoiceItems = 1) {
        let invoiceRow = 0;
        let invoiceStatus = "";
        let found = false;
        let rowCount = await accountDetailInvoices.detailPanelAccountInvoicesLV.rowCount();
        if (numInvoiceItems == "an")
            numInvoiceItems = 1;

        while (invoiceRow < rowCount - 1 && !found) {
            invoiceStatus = await this.getInvoiceStatus(invoiceRow);

            if (invoiceStatus == status) {
                await accountDetailInvoices.detailPanelAccountInvoicesLV.clickOnCell(invoiceRow, 1);
                if (await accountDetailInvoices.detailPanelAccountInvoicesLV.rowCount() >= numInvoiceItems)
                    found = true;
                else
                    invoiceRow++;
            }
            else
                invoiceRow++;
        }

        data.rowNumber = found ? invoiceRow : -1;
        data.invoiceAmount = await this.getInvoiceAmount(invoiceRow);
    }

    async openInvoices(fileObj) {
        try {
            this.stepAction = "Click on Invoices tab";
            this.stepER = "Action Step, Verification N/A";
            this.stepAR = "";
            this.verdict = "";

            await accountGroupMenuLinks.menuLinksAccountGroup_AccountDetailInvoices.click();
            await t.wait(3000);
            
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            await this.confirmPageNavigation(fileObj);

        } catch (err) {

            this.stepAction = "Open Invoices section failed";
            this.stepER = "Navigation or clicking on Invoices failed";
            this.stepAR = `Error in ${this.pageName}: ${err.message}`;
            this.verdict = "Failed";
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }


    async openInvoiceItem() {
        let invoiceRow = 0;
        let chargeType = "";
        let found = false;
        let rowCount = await accountDetailCharges.accountDetailChargesListDetailPanelChargesLV.rowCount();

        while (invoiceRow < rowCount && !found) {
            chargeType = await accountDetailCharges.accountDetailChargesListDetailPanelChargesLV.getTextFromCell(invoiceRow, 4);
            if (chargeType == "Premium") {
                await accountDetailCharges.accountDetailChargesListDetailPanelChargesLV.clickOnCell(invoiceRow, 2);
                found = true;
            }
            else
                invoiceRow++;
        }

        await accountDetailCharges.accountDetailChargesListDetailPanelInvoiceItemsLV.clickOnCell(0, 2);
    }

    async openTransaction(event) {
        let invoiceRow = 0;
        let eventType = "";
        let found = false;
        let rowCount = await invoiceItemDetailPopup.itemEventPanelSetItemEventsLV.rowCount();

        while (invoiceRow < rowCount && !found) {
            eventType = await invoiceItemDetailPopup.itemEventPanelSetItemEventsLV.getTextFromCell(invoiceRow, 1);
            if (eventType == event) {
                await invoiceItemDetailPopup.itemEventPanelSetItemEventsLV.clickOnCell(invoiceRow, 2);
                found = true;
            }
            else
                invoiceRow++;
        }
    }

    async getTransactionDetails() {
        let invoiceRow = 0;
        let lineItemType = "";
        let response = { credit: "", debit: "" };
        let rowCount = await transactionDetailPopup.transactionDetailDVTransactionLineItemsLV.rowCount();

        while (invoiceRow < rowCount) {
            lineItemType = await transactionDetailPopup.transactionDetailDVTransactionLineItemsLV.getTextFromCell(invoiceRow, 1);
            if (lineItemType == "Credit")
                response.credit = await transactionDetailPopup.transactionDetailDVTransactionLineItemsLV.getTextFromCell(invoiceRow, 2);
            else if (lineItemType == "Debit")
                response.debit = await transactionDetailPopup.transactionDetailDVTransactionLineItemsLV.getTextFromCell(invoiceRow, 2);
            invoiceRow++;
        }

        return response;
    }

    async checkInvoiceItemPushed() {
        await accountDetailCharges.accountDetailChargesListDetailPanelChargesLV.clickOnCell(0, 2);
        let newbillDate = await accountDetailCharges.accountDetailChargesListDetailPanelInvoiceItemsLV.getTextFromCell(0, 3);
        t.expect(newbillDate == data.nextPlannedBillDate);
    }

    async checkDelinquencyStatus() {
        await accountGroupMenuLinks.accountGroup_AccountOverviewAccountOverview_AccountSummary.click();
        let response = await accountSummaryCustom.accountSummaryAccountSummaryScreenAccountDetailSummary_DelinquencyAlertAlertBar.component.innerText;
        console.log("response: " + response)
        return response;
    }

    async checkTransaction(event) {
        await chargeScenarios.openCharges();
        await this.openInvoiceItem();
        await this.openTransaction(event);
        return await this.getTransactionDetails();
    }

    async checkDownPaymentInvoiceStatusAndAmount(fileObj, status) {
        try {
            this.stepAction = "Checking Invoice Status and Amount"
            this.stepER = "Action Step, Verification N/A"
            console.log(`Entering Invoices Page...`)
            await this.openInvoices(fileObj);
            await this.getInvoiceAmount(0, t.ctx.testData);
            await this.getStatus(0, status);

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async checkStatusAndDueColumnIndex(row, expectedStatus, expectedDue, fileObj) {
        try {
            this.stepAction = "Verification Step, Action N/A";
            this.stepER = "Verify that Status and Due in Invoice Page";
            const statusColumnIndex = 8;
            const dueColumnIndex = 10;

            let status = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(row, statusColumnIndex);
            let due = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(row, dueColumnIndex);

            if (status !== expectedStatus) {
                throw new Error(`Expected status to be "${expectedStatus}", but got "${status}".`);
            }

            if (due !== expectedDue) {
                throw new Error(`Expected Due amount to be "${expectedDue}", but got "${due}".`);
            }

            this.stepAR = "Successfully verified Status and Due in Invoice Page";
            this.verdict = "Passed";

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            return { status, due };
        } catch (err) {
            this.stepAction = "Verification Failed";
            this.stepER = `Expected Status: "${expectedStatus}", Expected Due: "${expectedDue}"`;
            this.stepAR = `Error in verification: ${err.message}`;
            this.verdict = "Failed";

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }




    async checkStatusAndDueAndAmount(row, expectedStatus, fileObj) {
        try {
            this.stepAction = "Verification Step, Action N/A";
            this.stepER = "Verify that Status, Due, and Amount in Invoice Page";
            const statusColumnIndex = 8;
            const dueColumnIndex = 10;
            const amountColumnIndex = 9;

            // Get the text from the Status, Due, and Amount columns
            let status = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(row, statusColumnIndex);
            let due = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(row, dueColumnIndex);
            let amount = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(row, amountColumnIndex);

            // Check if status matches the expected status
            if (status !== expectedStatus) {
                throw new Error(`Expected status to be "${expectedStatus}", but got "${status}".`);
            }

            // Check if Amount equals Due
            if (amount !== due) {
                throw new Error(`Expected Amount to be equal to Due, but got Amount: "${amount}" and Due: "${due}".`);
            }

            this.stepAR = "Successfully verified Status, Due, and Amount reflecting on PC";
            this.verdict = "Passed";

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            return { status, due, amount };
        } catch (err) {
            this.stepAction = "Verification Failed";
            this.stepER = `Expected Status: "${expectedStatus}", Due should match Amount`;
            this.stepAR = `Error in verification: ${err.message}`;
            this.verdict = "Failed";

            await captureScreenshot();  // Capture a screenshot to log the state during failure
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }

    async checkFullPayPolicyCancelledInvoice(fileObj, cancellationType) {
        try {
            const amountColumnIndex = 9;
            const downpaymentInvoiceRowIndex = 0;
            const cancelledInvoiceRowIndex = 1;
            let cancelledInvoiceAmount = 0;

            this.stepAction = "Verification Step, Action N/A";
            this.stepER = "Verify invoice created for cancellation with relavant amount under Invoices";

            // sort the invoice by inv_num
            await accountDetailInvoices.accountDetailInvoicesScreenAccountDetailInvoices_InvoiceNumberSortUpIcon.click();
            await t.wait(3000);

            let downpaymentInvoiceAmount = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(downpaymentInvoiceRowIndex, amountColumnIndex);
            console.log("DownpaymentInvoiceAmount: " + downpaymentInvoiceAmount)
            downpaymentInvoiceAmount = parseInt(downpaymentInvoiceAmount.replace('$', '').replace(/[^0-9./,-]+/g, "").replace(",", ""));
            cancelledInvoiceAmount = await accountDetailInvoices.detailPanelAccountInvoicesLV.getTextFromCell(cancelledInvoiceRowIndex, amountColumnIndex);
            console.log("CancelledInvoiceAmount: " + cancelledInvoiceAmount)
            cancelledInvoiceAmount = parseInt(cancelledInvoiceAmount.replace('$', '').replace(/[^0-9./,-]+/g, "").replace(",", ""));
            if (cancellationType.includes("flat")) {
                if (downpaymentInvoiceAmount === cancelledInvoiceAmount) {
                    throw new Error(`Expected Cancelled invoice amount to be equal to Downpayment invoice amount, but got Cancelled invoice amount: "${cancelledInvoiceAmount}" and Downpayment invoice amount: "${downpaymentInvoiceAmount}".`);
                } else {
                    this.stepAR = "Successfully verified Cancelled invoice amount[" + cancelledInvoiceAmount + "] to be as Downpayment invoice amount[" + downpaymentInvoiceAmount + "] since Flat cancellation";
                    this.verdict = "Passed";
                }
            } else if (cancellationType.includes("prorata")) {
                if (downpaymentInvoiceAmount > cancelledInvoiceAmount) {
                    this.stepAR = "Successfully verified Cancelled invoice amount[" + cancelledInvoiceAmount + "] less than Downpayment invoice amount[" + downpaymentInvoiceAmount + "] since Prorata cancellation";
                    this.verdict = "Passed";
                } else {
                    throw new Error(`Expected Cancelled invoice amount to be less than Downpayment invoice amount, but got Cancelled invoice amount: "${cancelledInvoiceAmount}" and Downpayment invoice amount: "${downpaymentInvoiceAmount}".`);
                }
            }
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            this.stepAction = "Verification Step, Action N/A";
            this.stepER = "Verify total invoice amount for cancellation";
            let totalInvoiceAmount = await accountDetailInvoices.accountDetailInvoicesScreenAccountDetailInvoices_InvoiceTotalAmount.component.innerText;
            console.log("TotalInvoiceAmount: " + totalInvoiceAmount)
            totalInvoiceAmount = parseInt(totalInvoiceAmount.replace('$', '').replace(/[^0-9./,-]+/g, "").replace(",", ""));
            if (cancellationType.includes("flat")) {
                if (totalInvoiceAmount === 0) {
                    throw new Error(`Expected total invoice amount after cancellation to be 0, but got ${totalInvoiceAmount}`);
                } else {
                    this.stepAR = "Successfully verified total invoice amount to be '$0' since Flat cancellation";
                    this.verdict = "Passed";
                }
            } else if (cancellationType.includes("prorata")) {
                if (totalInvoiceAmount > 0) {
                    this.stepAR = "Successfully verified total invoice amount[" + totalInvoiceAmount + "] to be greater than '0' since Prorata cancellation";
                    this.verdict = "Passed";
                } else {
                    throw new Error(`Expected total invoice amount after cancellation to be greater than 0, but got ${totalInvoiceAmount}`);
                }
            }
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            this.stepAction = "Verification Step, Action N/A";
            this.stepER = "Verify cancellation amount being moved to suspense amount";
            await accountGroupMenuLinks.accountGroup_AccountOverviewAccountOverview_AccountDetailSummary.click();
            let suspenseAmount = await accountDetailSummary.accountDetailDVSuspenseAmount.component.innerText;
            console.log("SuspenseAmount: " + suspenseAmount)
            suspenseAmount = parseInt(suspenseAmount.replace('$', '').replace(/[^0-9./,-]+/g, "").replace(",", ""));
            if (cancelledInvoiceAmount === suspenseAmount) {
                this.stepAR = "Successfully verified Cancelled invoice amount moved to Suspense amount - " + suspenseAmount;
                this.verdict = "Passed";
            } else {
                throw new Error(`Expected cancelled invoice amount to be moved to suspense amount, but got suspense amount: ${suspenseAmount} though cancelled amount: ${cancelledInvoiceAmount}`);
            }

            this.stepAction = "Verification Step, Action N/A";
            this.stepER = "Verify cancellation date to be same on both PC and BC ";
            await accountGroupMenuLinks.accountGroup_AccountOverviewAccountOverview_AccountSummary.click();
            let cancellationDate = await accountGroupMenuLinks.accountGroup_AccountOverviewAccountOverview_AccountSummary_CancellationDate.component.innerText;
            console.log("CancellationDate under BC: " + cancellationDate)
            if (t.ctx.cancellationEffectiveDate === cancellationDate) {
                this.stepAR = "Successfully verified Cancellation Date on BC - " + cancellationDate;
                this.verdict = "Passed";
            } else {
                throw new Error(`Expected cancellation date to be same on PC and BC, but got cancellation date on BC: ${cancellationDate} and on PC: ${t.ctx.cancellationEffectiveDate}`);
            }
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

        } catch (err) {
            this.stepAction = "Verification Failed";
            this.stepER = "";
            this.stepAR = `Error in verification: ${err.message}`;
            this.verdict = "Failed";

            await captureScreenshot();  // Capture a screenshot to log the state during failure
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }

}
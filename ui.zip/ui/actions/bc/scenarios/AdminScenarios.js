//import { AccountDetailInvoicesCustom } from "./ScenarioPages/accountGroup/AccountDetailInvoices"
import { InvoicePage } from "./InvoicePage";
import { ClientFunction, Selector, t } from "testcafe"
import {retryActionUntil} from "@gtui/gt-ui-framework";
import { BatchProcessInfo } from "../../../pages/gw/generated/billingcenter/pages/serverTools/BatchProcessInfo";
import { ServerToolsMenuLinks } from "../../../pages/gw/generated/billingcenter/pages/navigation/menuLinks/ServerToolsMenuLinks";
import { PcfSelectInput } from '@gtui/gt-ui-framework';
import { PcfComponent } from '@gtui/gt-ui-framework';

//const accountDetailInvoicesCustom = new AccountDetailInvoicesCustom();
const invoicePage = new InvoicePage();
const batchProcessInfo = new BatchProcessInfo();
const serverToolsMenuLinks = new ServerToolsMenuLinks();

const simulateAltShiftTKeyPress = ClientFunction((selector) => {
    const element = document.querySelector(selector);
    if (!element) return;

    const eventOptions = {
        key: 'T',
        code: 'KeyT',
        keyCode: 84, // The keycode for 'T'
        altKey: true,
        shiftKey: true,
        bubbles: true,
        cancelable: true
    };

    const downEvent = new KeyboardEvent('keydown', eventOptions);
    const upEvent = new KeyboardEvent('keyup', eventOptions);

    element.dispatchEvent(downEvent);
    element.dispatchEvent(upEvent);
});

export class AdminScenarios {

    constructor() {}

    async keyALTSHIFTTNavigation() {
        const inputField = Selector('#QuickJump');
        await t.click(inputField);  // Ensure the input field is focused
        await t.typeText(inputField, 'setValue');

        // Press Ctrl + A to select all text
        await t.pressKey('ctrl+a');

        console.log("Selected all text");

        // Wait for 15 seconds (15000 milliseconds)
        await t.wait(15000);

        // Use the ClientFunction to simulate pressing Alt + Shift + T
        await simulateAltShiftTKeyPress('#QuickJump');
        await t.wait(15000);

        console.log("Pressed Alt + Shift + T");

    }

    
    async batchRunforInvoice(){
        //click batchProcessInfo
        await serverToolsMenuLinks.menuLinksServerTools_BatchProcessInfo.click();

        //search for Invoic batch
        let invoiceNameCell = batchProcessInfo.batchProcessInfoBatchProcessScreenBatchProcessesLV.component.find('td[id$=-BatchProcess_Cell]').withExactText("Invoice");
        let selectButton = invoiceNameCell.sibling('td[id$=-RunBatchWithoutNotifyContent]').find('div.gw-LinkWidget[id$=-RunBatchWithoutNotify]');
        await t.click(selectButton);
        // Click setting icon click Return to BillingCenter
        let tabBarWidget = PcfSelectInput('#gw-TabBarWidget--settings');
        await tabBarWidget.click();
        let returnTabBarLink = PcfComponent('#InternalToolsTabBar-ReturnTabBarLink');
        await returnTabBarLink.click();

        
    }

    async executeQuickJumpCommand(command) {
        if (await Selector('div#QuickJump').exists && await Selector('div#QuickJump').visible)
            await t.typeText(Selector('div#QuickJump'), command, {replace: true, paste: true }).pressKey('enter');
        else
            await t.typeText(Selector('#QuickJump'), command, {replace: true, paste: true }).pressKey('enter');
    }

    async getCurrentDate() {
        await this.executeQuickJumpCommand("Run Clock");
        return await accountDetailInvoicesCustom.accountDetailInvoicesAccountDetailInvoicesScreen_msgsSelector.component.innerText;
    }

    async moveDate(dateToMoveTo) {
        invoicePage.openInvoices();
        let currentDate = await this.getCurrentDate();
        currentDate = new Date(currentDate);
        let invoiceStatus = dateToMoveTo.toLowerCase().includes("invoice bill date") ? "Planned" : "Billed";

        let invoiceDate = invoiceStatus == ("Planned") ? 
            await invoicePage.getInvoiceBillDate(data.rowNumber) :
            await invoicePage.getInvoiceDueDate(data.rowNumber);
        invoiceDate = new Date(invoiceDate);
        console.log("CurentDate : " + currentDate)
        console.log("Invoice Date : " + invoiceDate)

        let elapsedDays = Math.ceil((invoiceDate - currentDate) / (1000 * 60 * 60 * 24));

        if(dateToMoveTo.includes("- 1"))
            elapsedDays = elapsedDays - 1;
        else if(dateToMoveTo.includes("+ 1"))
            elapsedDays = elapsedDays + 1;

        if(elapsedDays > 0) {
            await this.executeQuickJumpCommand("Run Clock addDays " + (elapsedDays + data.dayOffset));
            data.dayOffset = 0;
            async function actionFunction(){
                //do nothing
            }
            async function comparisonFunction(object){
                let divDate = await object.getCurrentDate();
                divDate = await new Date(divDate);
                return !( divDate.getTime() == currentDate.getTime() );
            }
            await retryActionUntil(actionFunction, comparisonFunction, "Could not find updated date",
                {maxRetry:5, interval:20000, initialDelay: 5000}, [], [this]);
        }

        const messageSelectorPath = "#AccountDetailInvoices-AccountDetailInvoicesScreen-_msgs-0-0 > div.gw-message-and-suffix > div"
        await this.runInvoiceBatchProcesses(messageSelectorPath);
    }

    async runBatchProcessInvoice(messageSelectorPath) {
        await console.log("runBatchProcess Invoice")
        await this.executeQuickJumpCommand("RunBatchProcess Invoice");
        await this.checkCompletedBatchProcess("\"Invoice\"", messageSelectorPath);
    }

    async runBatchProcessInvoiceDue(messageSelectorPath) {
        await console.log("runBatchProcess InvoiceDue")
        await this.executeQuickJumpCommand("RunBatchProcess InvoiceDue");
        await this.checkCompletedBatchProcess("\"InvoiceDue\"", messageSelectorPath);
    }


    async runInvoiceBatchProcesses(messageSelectorPath) {
        await this.runBatchProcessInvoice(messageSelectorPath);
        await this.runBatchProcessInvoiceDue(messageSelectorPath);
    }

    async runBatchProcessPaymentRequest(messageSelectorPath) {
        await console.log("runBatchProcess PaymentRequest")
        await this.executeQuickJumpCommand("RunBatchProcess PaymentRequest");
        await this.checkCompletedBatchProcess("\"PaymentRequest\"", messageSelectorPath);
    }

    async runBatchProcessNewPayment(messageSelectorPath) {
        await console.log("runBatchProcess NewPayment")
        await this.executeQuickJumpCommand("RunBatchProcess NewPayment");
        await this.checkCompletedBatchProcess("\"NewPayment\"", messageSelectorPath);
    }

    async checkCompletedBatchProcess(commandName, messageSelectorPath) {
        await console.log("Check completed batch process: ", commandName);
        async function actionFunction() {
            // do nothing placeholder
        }

        async function comparisonFunction(messageSelectorPath) {
            //let messageSelector = await Selector("#AccountDetailInvoices-AccountDetailInvoicesScreen-_msgs-0-0 > div.gw-message-and-suffix > div");
            let messageSelector = await Selector(messageSelectorPath);
            let messageText = await messageSelector.innerText;
            await console.log(messageText, commandName);
            return messageText.includes(commandName);
        }

        await retryActionUntil(actionFunction, comparisonFunction, `Command: ${commandName} message not there`,
            {maxRetry: 5, interval:10000, initialDelay:1000}, [], [messageSelectorPath]);
    }
}
import { AccountDetailSummary } from "../../../pages/gw/generated/billingcenter/pages/accountGroup/accountOverview/AccountDetailSummary";
import { AccountGroupMenuLinks } from "../../../pages/gw/generated/billingcenter/pages/navigation/menuLinks/AccountGroupMenuLinks"
import { DBPaymentReversalConfirmationPopup } from "../../../pages/gw/generated/billingcenter/pages/popup/DBPayment/DBPaymentReversalConfirmationPopup.js";
import { selectDropdown, captureScreenshot } from "../../../util/common/helper.js";
import { t } from "testcafe";

const accountGroupMenuLink = new AccountGroupMenuLinks();
const accountDetailSummary = new AccountDetailSummary();
const dBPaymentReversalConfirmationPopup = new DBPaymentReversalConfirmationPopup();

export class DetailsPage {
    constructor() {
        this.pageName = "Account Details";  
        this.stepAction = "";
        this.stepER = "";
        this.stepAR = "";
        this.verdict = "";
    }

    // To confirm page navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A";
        this.stepER = `Verify that you are taken to either the ${this.pageName}`;

        if (await accountDetailSummary.accountDetailSummary_AccountDetailSummaryScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`;
            this.verdict = "Passed";

        } else {
            this.stepAR = "NOT able to navigate to the expected page";
            this.verdict = "Failed";
            captureScreenshot();
        }

        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    
    // Open account details
    async openDetails(fileObj) {
        try {
    
            this.stepAction = "Attempting to navigate and open Details section.";
            this.stepER = "Navigation to Details section should be successful.";    
            this.stepAction = "Click on Details.";
            await accountGroupMenuLink.accountGroup_AccountOverviewAccountOverview_AccountDetailSummary.click();
            
            await this.confirmPageNavigation(fileObj);
            this.stepAR = "Successfully opened the Details section.";
            this.verdict = "Passed";
            
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
          
            this.stepAction = "Open Details section failed";
            this.stepER = "Navigation or clicking on Details failed";
            this.stepAR = `Error in ${this.pageName}: ${err.message}`;
            this.verdict = "Failed";
    
            await captureScreenshot();  
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }
    
    
    async reversePaymentAction(fileObj, data) {
        try {
            this.stepAction = "Initiating Reverse Payment Action:<br>";
            this.stepER = "Action Step, Verification N/A";
            
            await this.openDetails(fileObj);  
    
            this.stepAction += `'Click on Action button', <br>`;
            await accountDetailSummary.accountDetailSummary_AccountDetailSummaryScreen_ActionButton.click();
    
            this.stepAction += `'Click on Reverse Option', <br>`;
            await accountDetailSummary.accountDetailSummary_ActionButton_ReversePayment.click();
            await t.wait(3000);  
    
            console.log(`Select the Reason: ${data.Reason_Reverse}`);
            this.stepAction += `'Select the Reason: ${data.Reason_Reverse}', <br>`;
            await selectDropdown(dBPaymentReversalConfirmationPopup.dBPaymentReversalConfirmationPopupReason, data.Reason_Reverse);
    
            this.stepAction += "Click on Ok button.";
            await dBPaymentReversalConfirmationPopup.dBPaymentReversalConfirmationPopupUpdate.click();
    
            this.stepAR = "Successfully performed the Reverse Payment Action.";
            this.verdict = "Passed";
    
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = "Reverse Payment Action Failed";
            this.stepER = "Action Failed";
            this.stepAR = `Error in ${this.pageName}: ${err.message}`;
            this.verdict = "Failed";
    
            await captureScreenshot();  // Capture a screenshot for failure context
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }
    
}

import { AccountTabBar_Ext } from "../../../../../pages/gw/ScenarioPages/Navigation/AccountTabBar_Ext.js";
import { t } from "testcafe";

const accountTabBar_Ext = new AccountTabBar_Ext();

export class MyActivitiesPage {
    constructor() {
        this.pageName = "My Activities page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }
}
import { t } from 'testcafe';
import { PolicyMenuActions } from '../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions.js';
import { setStepDescription } from '../../../../../util/common/setStepDescription.js';

const policyMenuActions = new PolicyMenuActions();
const pageNameStaticContent = require('../../../../../util/common/pageNameStaticContent.js');
const otherConstants = require('../../../../../util/common/otherConstantsFile.js')
const stepDescription = new setStepDescription();

export class PolicyActionsMenu {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    //To Click Renew Policy from Actions Menu
    async clickRenewPolicy(fileObj) {
        try {
            this.stepAction = `${otherConstants.CLICK_RENEW_POLICY} on ${pageNameStaticContent.ACTIONS_MENU}`
            this.stepER = stepDescription.setActionStep(otherConstants.ACTION_STEP);
            this.stepAR = stepDescription.resetExpResultStep();
            this.verdict = stepDescription.resetVerdictStep();
            console.log(`Click Actions > Renew Policy ...`)
            await t.wait(5000);
            await policyMenuActions.policyFilePolicyFileMenuActions.click()
            await policyMenuActions.policyFileMenuActions_NewWorkOrderPolicyFileMenuActions_RenewPolicy.click()
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep();
            this.stepER = stepDescription.resetExpResultStep();
            this.stepAR = `${otherConstants.ERROR_IN} ${pageNameStaticContent.ACTIONS_MENU}`
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    //To Click Cancel Policy from Actions Menu
    async clickCancelPolicy(fileObj) {
        try {
            this.stepAction = `${otherConstants.CLICK_CANCEL_POLICY} on ${pageNameStaticContent.ACTIONS_MENU}`
            this.stepER = stepDescription.setActionStep(otherConstants.ACTION_STEP);
            this.stepAR = stepDescription.resetExpResultStep();
            this.verdict = stepDescription.resetVerdictStep();
            console.log(`Click Actions > Cancel Policy ...`)
            await policyMenuActions.policyFilePolicyFileMenuActions.click()
            await policyMenuActions.policyFileMenuActions_NewWorkOrderPolicyFileMenuActions_CancelPolicy.click()
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep();
            this.stepER = stepDescription.resetExpResultStep();
            this.stepAR = `${otherConstants.ERROR_IN} ${pageNameStaticContent.ACTIONS_MENU}`
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    //To select Reinstate
    async clickReinstatePolicy(fileObj) {
        try {
            this.stepAction = `${otherConstants.CLICK_REINSTATE_POLICY} on ${pageNameStaticContent.ACTIONS_MENU}`
            this.stepER = stepDescription.setActionStep(otherConstants.ACTION_STEP);
            this.stepAR = stepDescription.resetExpResultStep();
            this.verdict = stepDescription.resetVerdictStep();
            console.log(`Click Actions > Reinstate Policy ...`)
            await policyMenuActions.policyFilePolicyFileMenuActions.click()
            await policyMenuActions.policyFileMenuActions_NewWorkOrderPolicyFileMenuActions_ReinstatePolicy.click()
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep();
            this.stepER = stepDescription.resetExpResultStep();
            this.stepAR = `${otherConstants.ERROR_IN} ${pageNameStaticContent.ACTIONS_MENU}`
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    //To select Policy Change
    async clickChangePolicy(fileObj) {
        try {
            this.stepAction = `${otherConstants.CLICK_POLICY_CHANGE} on ${pageNameStaticContent.ACTIONS_MENU}`
            this.stepER = stepDescription.setActionStep(otherConstants.ACTION_STEP);
            this.stepAR = stepDescription.resetExpResultStep();
            this.verdict = stepDescription.resetVerdictStep();
            console.log(`Click Actions > Change Policy ...`)
            await policyMenuActions.policyFilePolicyFileMenuActions.click()
            await policyMenuActions.policyFileMenuActions_NewWorkOrderPolicyFileMenuActions_ChangePolicy.click()
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep();
            this.stepER = stepDescription.resetExpResultStep();
            this.stepAR = `${otherConstants.ERROR_IN} ${pageNameStaticContent.ACTIONS_MENU}`
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}
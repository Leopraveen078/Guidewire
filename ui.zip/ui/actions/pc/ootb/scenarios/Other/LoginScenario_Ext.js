import { onApp } from "../../../../../pages/gw/registry/onApp.js";
import { DesktopTabBar } from "../../../../../pages/gw/generated/policycenter/pages/navigation/tabBar/DesktopTabBar.js"
import { captureScreenshot } from "../../../../../util/common/helper.js";

const onPCApp = new onApp("PC");
const desktopTabBar = new DesktopTabBar();

export class LoginScenario_Ext {
    constructor() {
        this.pageName = "PC Login Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async loginWithDefaultUser_ext(fileObj, data) {
        try {
            this.stepAction = `Login to PC as 'Super User'`
            this.stepER = "Verify that you are taken to landing screen My Activities page"
            await onPCApp.loginWithDefaultUser();
            if (await desktopTabBar.tabBarDesktopTab.component.visible) {
                this.stepAR = "Successfully Logged in to PC and taken to My Activities page"
                this.verdict = "Passed"
            } else {
                this.stepAR = "Could not successfully login to PC"
                this.verdict = "Failed"
                captureScreenshot();
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async loginWithUser_ext(fileObj, data) {
        try {
            this.stepAction = `Login to PC with the User: '${data.agentUsername}'`
            this.stepER = "Verify that you are taken to landing screen My Activities page"
            await onPCApp.loginWithUser(data.agentUsername, 'gw');
            if (await desktopTabBar.tabBarDesktopTab.component.visible) {
                this.stepAR = "Successfully Logged in to PC and taken to My Activities page"
                this.verdict = "Passed"
            } else {
                this.stepAR = "Could not successfully login to PC"
                this.verdict = "Failed"
                captureScreenshot();
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async loginWithRole_ext(fileObj, roleName) {
        try {
            this.stepAction = `Login to PC with the '${roleName}' Role`
            this.stepER = "Verify that you are taken to landing screen My Activities page"
            await onPCApp.loginWithRole(roleName);
            if (await desktopTabBar.tabBarDesktopTab.component.visible) {
                this.stepAR = "Successfully Logged in to PC and taken to My Activities page"
                this.verdict = "Passed"
            } else {
                this.stepAR = "Could not successfully login to PC"
                this.verdict = "Failed"
                captureScreenshot();
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
import { NewAccountNoteScreen_Ext } from "../../../../../pages/gw/ScenarioPages/Other/NewAccountNoteScreen_Ext.js";
import { NewPolicyNoteScreen_Ext } from "../../../../../pages/gw/ScenarioPages/Other/NewPolicyNoteScreen_Ext.js";
import { t } from "testcafe";
import { captureScreenshot } from "../../../../../util/common/helper.js";

const stepDescription = require("../../../../../util/common/setStepDescription.js");
const otherConstants = require("../../../../../util/common/otherConstantsFile.js");
const newAccountNoteScreen_Ext = new NewAccountNoteScreen_Ext();
const newPolicyNoteScreen_Ext = new NewPolicyNoteScreen_Ext();

export class NewNotePage {
    constructor() {
        this.pageName = "New Note page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }
        
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the New Note Page"
        if (await newAccountNoteScreen_Ext.newNotePageTitleBar.exists) {
            this.stepAR = "Successfully navigated to the New Note Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the New Note Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async addNote(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            this.stepAction = `Enter the following details:`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            this.stepAction = `${this.stepAction}: Select New Note Topic as ${data.newNoteTopic}`
            console.log(`Select New Note Topic as ${data.newNoteTopic}`)
            await newAccountNoteScreen_Ext.newNoteDVTopic.selectOptionByLabel(data.newNoteTopic);

            this.stepAction = `${this.stepAction}, Enter New Note Text as ${data.newNoteText}`
            console.log(`Enter New Note Text as ${data.newNoteText}`)
            await t.click(newAccountNoteScreen_Ext.newNoteDVText_Ext);
            await t.typeText(newAccountNoteScreen_Ext.newNoteDVText_Ext, data.newNoteText);
            await t.pressKey('tab');

            this.stepAction = `${this.stepAction} and Select Update Button`
            console.log(`Select Update Button`)
            await newAccountNoteScreen_Ext.newNoteScreenNewNoteScreen_UpdateButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            
        } catch(err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} New Note Page`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async addNoteToPolicy(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            this.stepAction = `Enter the following details:`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            this.stepAction = `${this.stepAction}: Select New Note Topic as ${data.newNoteTopic}`
            console.log(`Select New Note Topic as ${data.newNoteTopic}`)
            await newPolicyNoteScreen_Ext.newNoteWorksheetNewNoteScreenNewNoteDVTopic.selectOptionByLabel(data.newNoteTopic);

            this.stepAction = `${this.stepAction}, Enter New Note Text as ${data.newNoteText}`
            console.log(`Enter New Note Text as ${data.newNoteText}`)
            await t.click(newPolicyNoteScreen_Ext.newNoteWorksheetNewNoteScreenNewNoteDVText_Ext);
            await t.typeText(newPolicyNoteScreen_Ext.newNoteWorksheetNewNoteScreenNewNoteDVText_Ext, data.newNoteText);
            await t.pressKey('tab');

            this.stepAction = `${this.stepAction} and Select Update Button`
            console.log(`Select Update Button`)
            await newPolicyNoteScreen_Ext.newNoteWorksheetNewNoteScreenNewNoteScreen_UpdateButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch(err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} New Note Page`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
        
    }
}
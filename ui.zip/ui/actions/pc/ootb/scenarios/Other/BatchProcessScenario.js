import { t } from "testcafe";
import { BatchProcessScreen_Ext } from "../../../../../pages/gw/ScenarioPages/Other/BatchProcessScreen_Ext";
import { setStepDescription } from "../../../../../util/common/setStepDescription.js";

const stepDescription = new setStepDescription();
const otherConstants = require("../../../../../util/common/otherConstantsFile.js");
const batchProcessScreen_ext = new BatchProcessScreen_Ext();

export class BatchProcessScenarios {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async runBatchProcess(fileObj, batchName){
        try {
            this.stepAction = "Navigate to Server Tool > Run Renewal Batch Process. ";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log("Navigating to Server Tool")
            await t.pressKey("alt+shift+t");
            console.log("Running the Batch Process")
            await t.click(batchProcessScreen_ext.policyRenewalBatchProcessRunBtn).wait(8000);
            console.log("Returning to Policy Center")
            this.stepAction = this.stepAction + "Return to Policy Center.";
            await batchProcessScreen_ext.serverToolsInternalToolsMenuActions.click();
            await batchProcessScreen_ext.internalToolsMenuActionsReturnToApp.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch(err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} Server Tool`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
        
    }
}
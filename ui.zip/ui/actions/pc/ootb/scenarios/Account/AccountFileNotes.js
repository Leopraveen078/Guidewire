import { AccountFileNotesScreen } from "../../../../../pages/gw/ScenarioPages/Account/AccountFileNotesScreen.js";
import { t } from "testcafe";
import { captureScreenshot } from "../../../../../util/common/helper.js";

const accountFileNotesScreen = new AccountFileNotesScreen();

export class AccountFileNotesPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the Account File Notes Page"
        if (await accountFileNotesScreen.accountFileNotesTitleBar.visible) {
            this.stepAR = "Successfully navigated to the Account File Notes Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the Account File Notes Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async searchAndVerifyAddedNotes(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            //Search the Added Notes
            this.stepAction = `Enter 'Text Search' as ${data.newNoteText} and click Search button`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            await accountFileNotesScreen.noteSearchDVTextSearch.setValue(data.newNoteText);
            await accountFileNotesScreen.accountFile_NotesNotesScreenNoteSearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            //Verify the Notes Listed
            this.stepAction = "Verification Step, Action N/A"
            this.stepER = "Verify the added Notes are listed in Account File Notes Page"
            if (await accountFileNotesScreen.notesScreenNotesLV.rowCount() > 0) {
                this.stepAR = "As Expected, The Added Notes are listed"
                this.verdict = "Passed"
            } else {
                this.stepAR = "Not As Expected, The Added Notes are not listed"
                this.verdict = "Failed"
                captureScreenshot();
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}
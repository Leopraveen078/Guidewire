import { NewPersonAccountScreen } from "../../../../../pages/gw/ScenarioPages/Account/NewPersonAccountScreen.js";
import { NewAccountScreen_Ext } from "../../../../../pages/gw/ScenarioPages/Account/NewAccountScreen_Ext.js";
import { captureScreenshot, randomNameGenerator, selectDropdown } from "../../../../../util/common/helper.js";
import { ClientFunction, t } from "testcafe";
import { Summary } from "../../../../../pages/gw/generated/policycenter/pages/account/Summary.js";
import { AddressValidationSelectPopup } from "../../../../../pages/gw/generated/billingcenter/pages/popup/Address/AddressValidationSelectPopup.js";

const newPersonAccountScreen = new NewPersonAccountScreen();
const newAccountScreen_Ext = new NewAccountScreen_Ext();
const summary = new Summary();
const pcAddressValidationSelectPopup = new AddressValidationSelectPopup();

export class CreateAccountPage {
    constructor() {
        this.pageName = "Create Account Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the Enter Account Information Page"
        if (newAccountScreen_Ext.newAccountNewAccountScreenNewAccountSearchTitleBar.visible) {
            this.stepAR = "Successfully navigated to the Enter Account Information Page"
            this.verdict = "Passed"

        } else {
            this.stepAR = "NOT able to navigate to the Enter Account Information Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    async newAccountCreation(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            this.stepAction = "Enter Account details as follows: ";
            this.stepER = "Action Step, Verification N/A";
            this.stepAR = "";
            this.verdict = "";

            console.log(`Enter first name: ${data.P_FirstName}`);
            this.stepAction += "'First Name: " + data.P_FirstName + "', <br>";
            await newAccountScreen_Ext.newAccountNewAccountScreenNewAccountSearchDVGlobalPersonNameInputSetFirstName.setValue(data.P_FirstName);

            const randomLastName = await randomNameGenerator();

            if (data.hasOwnProperty('P_LastName') && data.P_LastName !== "") {
                data.P_LastName = `${data.P_LastName}${randomLastName}`;
            } else {
                data.P_LastName = randomLastName;
            }

            console.log(`Enter Last name: ${data.P_LastName}`);
            this.stepAction += "'Last Name: " + data.P_LastName + "', <br>";
            await newAccountScreen_Ext.newAccountNewAccountScreenNewAccountSearchDVGlobalPersonNameInputSetLastName.setValue(data.P_LastName);

            console.log(`Clicking on Search button...`);
            this.stepAction += " and Click Search button";
            await newAccountScreen_Ext.newAccountNewAccountScreenNewAccountSearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            this.stepAction = "Click the Create New Account > Person and Enter following details: ";
            this.stepER = "Action Step, Verification N/A";
            this.stepAR = "";
            this.verdict = "";

            console.log(`Clicking on Create New Account > Person`);
            await newAccountScreen_Ext.newAccountScreenNewAccountButton.click();
            await newAccountScreen_Ext.newAccountButtonNewAccount_Person.click();

            await newPersonAccountScreen.CreateAccount_PrimaryPhone.selectNthOption(2);

            console.log(`Enter Home Phone: ${data.P_HomePhone}`);
            this.stepAction += "'Home Phone: " + data.P_HomePhone + "', <br>";
            await newPersonAccountScreen.CreateAccount_HomePhone.setValue(data.P_HomePhone);
            await t.pressKey('tab');

            console.log(`Enter Work Phone: ${data.P_WorkPhone}`);
            this.stepAction += "'Work Phone: " + data.P_WorkPhone + "', <br>";
            await newPersonAccountScreen.CreateAccount_WorkPhone.setValue(data.P_WorkPhone);
            await t.pressKey('tab');

            console.log(`Enter Mobile Phone: ${data.P_MobilePhone}`);
            this.stepAction += "'Mobile Phone: " + data.P_MobilePhone + "', <br>";
            await newPersonAccountScreen.CreateAccount_MobilePhone.setValue(data.P_MobilePhone);
            await t.pressKey('tab');

            console.log(`Enter Primary Email: ${data.PrimaryEmail}`);
            this.stepAction += "'Primary Email: " + data.PrimaryEmail + "', <br>";
            await newPersonAccountScreen.CreateAccount_EmailAddress1.setValue(data.PrimaryEmail);

            console.log(`Enter AddressLine1: ${data.AddressLine1}`);
            this.stepAction += "'AddressLine1: " + data.AddressLine1 + "', <br>";
            await newPersonAccountScreen.addressLine1.setValue(data.AddressLine1);

            console.log(`Enter City: ${data.City}`);
            this.stepAction += "'City: " + data.City + "', <br>";
            await newPersonAccountScreen.city.setValue(data.City);

            console.log(`Enter ZipCode: ${data.ZipCode}`);
            this.stepAction += "'ZipCode: " + data.ZipCode + "', <br>";
            await newPersonAccountScreen.CreateAccount_PostalCode.setValue(data.ZipCode);
            await t.pressKey('tab');
            await t.wait(2000);

            await selectDropdown(newPersonAccountScreen.CreateAccount_CreateAccountScreen_AddressInputSet_Selector, data.Address);

            await pcAddressValidationSelectPopup.addressValidationSelectScreensaveStd.click();
            await newPersonAccountScreen.CreateAccount_CreateAccountScreen_PersonType.selectNthOption(2);

            // select organization based on env, due to its availability
            const getPageUrlFn = ClientFunction(() => window.location.href);
            const pageUrl = await getPageUrlFn();
            const env = pageUrl.split("-")[1];
            let organization = "";
            if (env === 'uat') {
                organization = "A. L. SALAND INSURANCE SOLUTIONS, INC";
            } else {
                organization = "HURST INS. SERVICES,INC.";
            }

            console.log(`Enter Organization: ${organization}`);
            this.stepAction += "'Organization: " + organization + "', <br>";
            await newPersonAccountScreen.CreateAccount_ProducerSelectionInputSet_Producer.setValue(organization);
            await t.pressKey('tab');
            await t.wait(2000);

            this.stepAction += " and Click Update button.";
            await newPersonAccountScreen.forceDupCheckUpdateButton.click();
            await t.wait(5000);

            t.ctx.accountNumber = await summary.accountFile_Summary_BasicInfoDVAccountNumber.component.innerText;

            // Verify the account number is not null or undefined
            await t.expect(t.ctx.accountNumber).notEql(null, 'Account number should not be null');
            await t.expect(t.ctx.accountNumber).notEql(undefined, 'Account number should not be undefined');

            // saving

            console.log("Account number successfully stored and verified - " + t.ctx.accountNumber);
            this.stepAR = "Account created successfully - " + t.ctx.accountNumber;

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = "";
            this.stepER = "";
            this.stepAR = "Error in " + this.pageName;
            this.verdict = "Failed";
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }



}
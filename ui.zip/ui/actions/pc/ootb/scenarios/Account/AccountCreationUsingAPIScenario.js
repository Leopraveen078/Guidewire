import { t } from "testcafe";
import { AppApiBridgeObj } from "../../../../../util/AppApiBridge.js";
import { setStepDescription } from "../../../../../util/common/setStepDescription.js"

const otherConstants = require('../../../../../util/common/otherConstantsFile.js')
const stepDescription = new setStepDescription();
const java = require("java");

export class AccountCreationUsingAPIScenario {
  constructor() {
    this.stepAction = ""
    this.stepER = ""
    this.stepAR = ""
    this.verdict = ""
  }

  async createAccountUsingAPI(fileObj, data) {
    try {
      this.stepAction = `Create an account using GT-API Bridge`
      this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
      this.stepAR = stepDescription.resetActualResultStep()
      this.verdict = stepDescription.resetVerdictStep()

      let HashMap = java.import('java.util.HashMap');
      let map = new HashMap();
      map.putSync('pcUsername', data.agentUsername);
      map.putSync('pcPassword', data.passWord);

      let resultMap = await AppApiBridgeObj.runGtApiScenario(
        "classpath:pc/AccountSteps.feature",
        "CreateAccount", map);
      t.ctx.accountNumber = resultMap.getSync("accountNumber");
      console.log("Account Number: " + t.ctx.accountNumber);

      this.stepAR = `Created Account Number : ${t.ctx.accountNumber}`
      await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
      await t.wait(1000);
      return t.ctx.accountNumber
    } catch (err) {
      this.stepAction = ""
      this.stepER = ""
      this.stepAR = "Error in GT-API Bridge"
      this.verdict = "Failed"
      await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
      throw (err)
    }
  }

}
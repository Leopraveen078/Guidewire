import { AccountMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/AccountMenuActions";
import { AccountMenuLinks } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuLinks/AccountMenuLinks.js";
import { NewActivityWorksheet } from "../../../../../pages/gw/generated/policycenter/pages/other/NewActivityWorksheet.js"
import { AccountSummary } from "../../../../../pages/gw/ScenarioPages/Account/AccountSummary.js";
import { t } from "testcafe";
import { captureScreenshot } from "../../../../../util/common/helper.js";

const accountMenuActions = new AccountMenuActions();
const accountMenuLinks = new AccountMenuLinks();
const newActivityWorksheet = new NewActivityWorksheet();
const accountSummary = new AccountSummary();

export class AccountSummaryPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }
    
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the Account File Summary Page"
        if (await accountSummary.accountFileSummaryTitleBar.visible) {
            this.stepAR = "Successfully navigated to the Account File Summary Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the Account File Summary Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async clickNewSubmission(fileObj) {
        try {
            // Ensure navigation to the correct page
            await this.confirmPageNavigation(fileObj);
    
            // Perform actions to create a new submission
            console.log('Clicking the Actions > New Submission');
            this.stepAction = "Click 'Actions' and select 'New Submission' option";
            this.stepER = "Action Step, Verification N/A";
            this.stepAR = "";
            this.verdict = "";
    
            // Click through the actions menu to create a new submission
            await accountMenuActions.accountFileAccountFileMenuActions.click();
            await accountMenuActions.accountFileMenuActions_CreateAccountFileMenuActions_NewSubmission.click();
            
            // Log the actions performed
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            // Log the error details
            this.stepAction = "";
            this.stepER = "";
            this.stepAR = "Error in Account Summary Page";
            this.verdict = "Failed";
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            
            // Rethrow the error to ensure it’s properly handled upstream
            throw err;
        }
    }
    

    async captureAccountNumber(fileObj) {
        console.log(`Capturing Account Number...`)
        t.ctx.data.accountNumber = await accountSummary.accountFile_Summary_BasicInfoDVAccountNumber.getValue();
        this.stepAction = "Capture Account Number"
        this.stepER = "Action Step, verification N/A"
        this.stepAR = `Account Number: ${t.ctx.data.accountNumber}`
        this.verdict = ""
        console.log("Account Created: " + t.ctx.data.accountNumber);
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        return t.ctx.data.accountNumber
    }

    async clickNewNote(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj)
            this.stepAction = "Click 'Actions' and select 'New Note' option"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log('Clicking the Actions > New Note')
            await accountMenuActions.accountFileAccountFileMenuActions.click();
            await accountMenuActions.accountFileMenuActions_CreateAccountFileMenuActions_NewNote.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Account Summary Page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async navigateToNotesPage(fileObj) {
        try {
            this.stepAction = "Click the New Note side menu link"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log('Clicking the New Note side menu link')
            await accountMenuLinks.menuLinksAccountFile_AccountFile_Notes.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Account Summary Page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async createNewActivity(fileObj, data) {
        try {
            this.stepAction = `Click 'Actions' > 'New Activity' > ${data.activityCategory} > ${data.activity}`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Click 'Actions' > 'New Activity' > ${data.activityCategory} > ${data.activity}`)
            await accountMenuActions.accountFileAccountFileMenuActions.click();
            await t.hover(accountMenuActions.accountFileMenuActions_CreateAccountFileMenuActions_NewActivity.component);
            await t.hover(accountSummary.accountFileMenuCategory.component.withExactText(data.activityCategory));
            await t.click(accountSummary.accountFileMenuCategory.component.withExactText(data.activity));
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            this.stepAction = "Click OK button"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            await newActivityWorksheet.newActivityScreenNewActivityScreen_UpdateButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Account Summary Page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async verifyAddedActivity(fileObj, data) {
        try {
            //Verify the Activity Listed
            this.stepAction = "Verification Step, Action N/A"
            this.stepER = "Verify the added Activity is listed in Account Summary Page"
            if (await accountSummary.accountFileSummaryCurrentActivitiesSubject.withExactText(data.activity).exists) {
                this.stepAR = "As Expected, The Added Activity is listed"
                this.verdict = "Passed"
            } else {
                this.stepAR = "Not As Expected, The Added Activity is not listed"
                this.verdict = "Failed"
                captureScreenshot();
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Account Summary Page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}
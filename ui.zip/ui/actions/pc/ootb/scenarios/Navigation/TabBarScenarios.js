import { t } from "testcafe";
import { captureScreenshot } from "../../../../../util/common/helper.js";
import { SearchTabBar } from "../../../../../pages/gw/generated/policycenter/pages/navigation/tabBar/SearchTabBar.js";
import { AccountTabBar } from "../../../../../pages/gw/generated/policycenter/pages/navigation/tabBar/AccountTabBar.js";
import { PolicyTabBar } from "../../../../../pages/gw/generated/policycenter/pages/navigation/tabBar/PolicyTabBar.js";
import { AccountSearch } from "../../../../../pages/gw/generated/policycenter/pages/search/AccountSearch.js";
const searchTabBar = new SearchTabBar();
const accountTabBar = new AccountTabBar();
const policyNumberPolicyTabBar = new PolicyTabBar();
const accountSearch = new AccountSearch();


export class TabBarScenarios {
    constructor() {
        this.pageName = "Tab Bar"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async clickNewAccount(fileObj) {
        try {
            this.stepAction = "Select Account drop down and click New Account to display the 'Enter Account Information Page' "
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Clicking on Account > New Account link...`)
            await accountTabBar.accountTabAccountTab_ExpandIcon.click();
            await accountTabBar.accountTabAccountTab_NewAccount.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.componentName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async searchByAccountNumber(fileObj, data) {
        try {
            this.stepAction = "Search by the Account number using Account Tab-bar"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Search by the Account number using Account Tab-bar"`)
            !await accountTabBar.tabBarAccountTab.component.hasClass('gw-hasOpenSubMenu');
            await t.click(accountTabBar.tabBarAccountTab.component.find('div.gw-action--expand-button'));
            await t.wait(1000);
            await accountTabBar.accountTabAccountTab_AccountNumberSearchItem.setValue(data.accountNumber);
            await accountTabBar.tabBarAccountTab_AccountNumberSearchItem_Button.click();
            console.log(`Search on Account Tap-bar successfully done`);
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
    


    


    async selectSearchAccounts(fileObj, data) {
        try {
            this.stepAction = `Select Search > Accounts`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Select Search > Accounts`)
            await t.click(searchTabBar.tabBarSearchTab.component.find("div.gw-action--expand-button"));
            await searchTabBar.searchTabSearch_AccountSearch.click();
            await t.wait(3000);
            
            await accountSearch.accountSearchDVAccountNumber.setValue(data.accountNumber);
            await accountSearch.accountSearchAccountSearchScreenAccountSearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.componentName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async searchByPolicyNumber(fileObj, data) {
        try {
            // Initialize step action and expected result
            this.stepAction = `Searching for Policy Number: ${data}<br>`;
            this.stepER = "Policy number should be searched successfully.";
    
            // Log the policy number and perform the search actions
            console.log(`Search the Policy number: ${data}`);
            this.stepAction += `'PolicyNumber: ${data}', <br>`;
            
            // Expand the policy tab and enter the policy number
            await policyNumberPolicyTabBar.tabBarPolicyTab_ExpandIcon.click();
            await policyNumberPolicyTabBar.policyTabPolicyTab_PolicyRetrievalItem.setValue(data);
            
            this.stepAction += "and search the Policy.";
            await policyNumberPolicyTabBar.policyTabPolicyTab_PolicyRetrievalItemButton.click();
    
            this.stepAR = "Successfully searched the Policy by number.";
            this.verdict = "Passed";
    
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
          
            this.stepAction = "Search by Policy Number failed";
            this.stepER = "Entering or searching the Policy Number failed";
            this.stepAR = `Error in Policy Search page`;
            this.verdict = "Failed";
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }
    

    async searchBySubmissionNumber(fileObj, submissionNumber) {
        try {
            this.stepAction = `Select Policy drop down and Search by Submission number - ${submissionNumber}`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Clicking on Policy drop down > Search Submission Number - ${submissionNumber}`)
            !await PolicyTabBar.tabBarPolicyTab.component.hasClass('gw-hasOpenSubMenu') && await t.click(PolicyTabBar.tabBarPolicyTab.component.find('div.gw-action--expand-button'));
            await PolicyTabBar.policyTabPolicyTab_SubmissionNumberText.setValue(submissionNumber);

            await PolicyTabBar.policyTabPolicyTab_SubmissionNumberSearchItemButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.componentName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}

import { t } from "testcafe";
import { MenuInfoBar } from "../../../../../pages/gw/ScenarioPages/Navigation/MenuInfoBar.js";
import { setStepDescription } from "../../../../../util/common/setStepDescription.js";

const otherConstants = require('../../../../../util/common/otherConstantsFile.js');
const menuInfoBar = new MenuInfoBar();
const stepDescription = new setStepDescription();

export class PolicyMenuInfoBarScenarios {
    constructor() {
        this.componentName = "Policy Menu Info Bar"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async clickAccountNumberLink(fileObj) {
        try {
            this.stepAction = "Clicking on Account Number link in Menu Info Bar and Navigate to Account File Summary page"
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log(`Clicking on Account Number link...`)
            await menuInfoBar.menuInfoBarAccountNumberLink.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${this.componentName}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}

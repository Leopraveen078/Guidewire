import { RiskAnalysisSubmissionWizard } from "../../../../../pages/gw/generated/policycenter/pages/navigation/submissionWizard/RiskAnalysisSubmissionWizard"

const riskAnalysisSubmissionWizard = new RiskAnalysisSubmissionWizard()

export class SubmissionWizard {
    constructor() {
        this.componentName = 'Submission Wizard Navigation Sidebar'
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async navigateToRiskAnalysisPage(fileObj) {
        try {
            this.stepAction = "Select Risk Analysis Link and Navigate to Risk Analysis Page"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log("Navigate to the Risk Analysis page");
            await riskAnalysisSubmissionWizard.submissionWizardRiskAnalysis.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in selecting Risk Analysis Link"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async navigateToPolicyReviewPage(fileObj) {
        try {
            this.stepAction = "Select Risk Analysis Link and Navigate to Risk Analysis Page"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log("Navigate to the Risk Analysis page");
            await riskAnalysisSubmissionWizard.submissionWizardRiskAnalysis.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in selecting Risk Analysis Link"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async getSubmissionNumber(fileObj) {
        this.stepAction = `Getting Submission Number from Side Menu`;
        this.stepER = "Action Step, Verification N/A"
        this.stepAR = ""
        this.verdict = ""
        let submissionNumber = await riskAnalysisSubmissionWizard.submissionWizardSideMenuTitle.component.innerText;
        submissionNumber = submissionNumber.split(' ')[1].trim();
        console.log(`Submission Number from UI : "${submissionNumber}"`);
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        return submissionNumber;
    }
}

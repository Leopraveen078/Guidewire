import { t, Selector } from 'testcafe';
import { PolicyTransactionScreen_Ext } from "../../../../../pages/gw/ScenarioPages/Policy/PolicyTransactionScreen_Ext";
import { captureScreenshot } from '../../../../../util/common/helper';

const policyTransactionScreen_ext = new PolicyTransactionScreen_Ext();

export class PolicyTransactionPage {

    constructor() {
        this.pageName = "Policy Transaction Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    //To confirm page navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        await policyTransactionScreen_ext.policyTransactionScreenTitleBar.visible
        if (await policyTransactionScreen_ext.policyTransactionScreenTitleBar.exists) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    //To verify if the Policy is Renewed
    async assertPolicyIsRenewed(fileObj) {
        try {
            this.confirmPageNavigation(fileObj)
            this.stepAction = "Verification Step, Action N/A";
            this.stepER = "Verify that the Policy is Renewed"
            let transactionRow = policyTransactionScreen_ext.policyTransactionScreenTransactionRow.component.find('td').withText('Renewal')
            if (await transactionRow.exists) {
                let transactionNumber = await transactionRow.parent().find('div[id$=-JobNumber]').innerText
                let transactionStatus = await transactionRow.parent().find('div[id$=-Status]').innerText
                this.stepAR = `Policy is Renewed successfully with Transaction Number '${transactionNumber}' and Transaction Status '${transactionStatus}'`
                this.verdict = "Passed"
            } else {
                this.stepAR = `Policy is not Renewed`
                this.verdict = "Failed"
                captureScreenshot();
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}
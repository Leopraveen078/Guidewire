'use strict';
import { t } from 'testcafe';
import { PolicyMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions";
import { JobWizardInfoBar } from '../LOBWizardStepGroup/Common/JobWizardInfoBar';
import { Summary } from '../../../../../pages/gw/generated/policycenter/pages/account/Summary';
import { BoundScreen } from '../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/BoundScreen';
import { captureScreenshot } from '../../../../../util/common/helper';


const policyMenuActions = new PolicyMenuActions();
const jobWizardInfoBar = new JobWizardInfoBar();
const summaryAccount = new Summary();
const cancelBoundScreen = new BoundScreen();
export class CancelBoundPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
        this.pageName = "Cancellation Bound Page"
    }

    //To Confirm Page Navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        await policyMenuActions.cancelBoundScreenTitleBar.visible
        if (await policyMenuActions.cancelBoundScreenTitleBar.exists) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the  ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    //To view policy details and capture in submission bound page
    async viewYourCancelledPolicy(fileObj, data) {
        try {
            await this.confirmPageNavigation(t.ctx.htmlReport);

            captureScreenshot();
            await jobWizardInfoBar.assertSubmissionState(t.ctx.htmlReport, data);

            console.log(`Clicking on View your policy ...`)
            this.stepAction = `Click View your policy link from ${this.pageName}`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            await policyMenuActions.submissionBoundScreenViewPolicy.click();
            await t.wait(5000);

            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async verifyPolicyCanceled(fileObj, expectedStatus) {
        try {
            //verify policy cancelled
            this.stepAction = "Verification Step, Action N/A"
            this.stepER = `Verify that the policy is at Canceled state`
            this.stepAR = ""
            this.verdict = ""
            await policyMenuActions.accountHyperLink.click();
            const statusColumnIndex = 6;
            let status = await summaryAccount.accountFile_SummaryScreenAccountFile_Summary_PolicyTermsLV.getTextFromCell(0, statusColumnIndex);

            // Check if status matches the expected status
            if (status !== "Canceled") {
                this.stepAR = `Invalid policy status as ${status} under Account summary page > Policy Terms > Policy Status`
                this.verdict = "Failed"
            } else {
                this.stepAR = `Successfully verified the policy status as ${expectedStatus}`
                this.verdict = "Passed"
            }

            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async assertcancelBoundScreen(fileObj) {
        try {
            this.stepAction = "Verification Step. Action N/A";
            this.stepER = "Verify the Policy Renewal is bound.";

            let cancelMessage = cancelBoundScreen.JobComplete_JobCompleteScreen_Message.component.withText(/^Your cancellation (.*) has been scheduled for (.+).$/).exists;

            if (await cancelMessage) {
                let policyText = await cancelBoundScreen.JobComplete_JobCompleteScreen_JobCompleteDV_ViewPolicy.component.innerText;
                let policyNumber = policyText.replace('View your policy (#', '').replace(")", "");

                let TransactionText = await cancelBoundScreen.JobComplete_JobCompleteScreen_Message.component.innerText;
                let cancelMatch = TransactionText.match(/Your cancellation (.*) has been scheduled for (.+)\./);

                if (cancelMatch) {
                    let TransactionNumber = cancelMatch[1];
                    let scheduledDateTime = cancelMatch[2];
                    console.log(`Capturing Policy Cancellation Transaction: ${TransactionNumber}, Policy Number: ${policyNumber}, Scheduled Date and Time: ${scheduledDateTime}`);

                    this.stepAR = `AS EXPECTED, Policy Cancellation is scheduled successfully. The Cancellation Transaction is "${TransactionNumber}" for Policy - "${policyNumber}", scheduled for "${scheduledDateTime}".`;
                    this.verdict = "Passed";
                }
            } else {
                this.stepAR = "NOT AS EXPECTED, Policy Cancellation message not found.";
                this.verdict = "Failed";
                captureScreenshot();
            }


        } catch (err) {
            this.stepAction = "";
            this.stepER = "";
            this.stepAR = "NOT AS EXPECTED, Policy Cancellation message not found. " + this.pageName;
            this.verdict = "Failed";
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }

    async assertcancelBoundScreen(fileObj) {
        this.stepAction = `Verification Step. Action N/A`;
        this.stepER = "Verify the Policy Cancellation is scheduled.";

        // Check if the cancellation message is visible
        let cancelMessage = cancelBoundScreen.JobComplete_JobCompleteScreen_Message.component.withText(/^Your cancellation \(#\d+\) has been scheduled for .+$/).visible;

        if (await cancelMessage) {
            // Extract the policy number
            let policyText = await cancelBoundScreen.JobComplete_JobCompleteScreen_JobCompleteDV_ViewPolicy.component.innerText;
            var policyNumber = policyText.replace('View your policy (#', '').replace(")", "");

            // Extract the transaction number and date from the cancellation message
            let TransactionText = await cancelBoundScreen.JobComplete_JobCompleteScreen_Message.component.innerText;
            let cancelMatch = TransactionText.match(/Your cancellation \(#(\d+)\) has been scheduled for (.+)\./);

            if (cancelMatch) {
                var TransactionNumber = cancelMatch[1];  // Captures the transaction number (e.g., 00001062)
                var scheduledDateTime = cancelMatch[2];  // Captures the date and time (e.g., Aug 14, 2024, 12:01:00 AM)

                // Log the captured information
                console.log(`Capturing Cancellation Transaction Number: ${TransactionNumber}, Policy Number: ${policyNumber}, Scheduled Date and Time: ${scheduledDateTime}`);

                // Set the step result and verdict
                this.stepAR = `AS EXPECTED, Policy Cancellation is scheduled successfully. The Cancellation Transaction number is "${TransactionNumber}" for Policy - "${policyNumber}", scheduled for "${scheduledDateTime}".`;
                this.verdict = "Passed";
            } else {
                // Handle unexpected message format
                console.log(`NOT AS EXPECTED, the cancellation message format is incorrect.`);
                this.stepAR = `NOT AS EXPECTED, the cancellation message format is incorrect.`;
                this.verdict = "Failed";
                captureScreenshot();
            }
        } else {
            console.log(`NOT AS EXPECTED, Policy Cancellation is NOT scheduled successfully.`);
            this.stepAR = `NOT AS EXPECTED, Policy Cancellation is NOT scheduled successfully.`;
            this.verdict = "Failed";
            captureScreenshot();
        }

        // Insert the result into the file
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }


}
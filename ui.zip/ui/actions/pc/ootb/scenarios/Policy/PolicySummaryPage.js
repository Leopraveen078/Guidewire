import { NewActivityWorksheet } from "../../../../../pages/gw/generated/policycenter/pages/other/NewActivityWorksheet.js"
import { PolicyMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions.js";
import { PolicyMenuLinks } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuLinks/PolicyMenuLinks.js";
import { PolicySummary } from "../../../../../pages/gw/ScenarioPages/Policy/PolicySummary.js"
import { t } from "testcafe";
import { setStepDescription } from "../../../../../util/common/setStepDescription";

const newActivityWorksheet = new NewActivityWorksheet();
const policyMenuActions = new PolicyMenuActions();
const policyMenuLinks = new PolicyMenuLinks();
const policySummary = new PolicySummary();
const pageNameStaticContent = require('../../../../../util/common/pageNameStaticContent.js');
const otherConstants = require('../../../../../util/common/otherConstantsFile.js')
const stepDescription = new setStepDescription();


export class PolicySummaryPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = stepDescription.setActionStep(otherConstants.VERIFICATION_STEP)
        this.stepER = stepDescription.setExpResultStep(`${otherConstants.VERIFY_PAGE_NAVIGATION} ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
        if (await policySummary.policyFileSummaryTitleBar.visible) {
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.PAGE_NAVIGATION_PASS} ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
        } else {
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.PAGE_NAVIGATION_FAIL} ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async verifyPageElements(fileObj, data) {
        await this.confirmPageNavigation(fileObj)
        if ((data.verifyPolicyNumberIsDisplayed !== "") && (data.hasOwnProperty('verifyPolicyNumberIsDisplayed'))) {
            console.log(`Verify that Policy Number ${t.ctx.policyNumber} is displayed`)
            this.stepAction = stepDescription.setActionStep(otherConstants.VERIFICATION_STEP)
            this.stepER = `Verify that Policy Number ${t.ctx.policyNumber} is displayed`
            const policyNumberFromUI = await policySummary.policyDetailsDetailViewTile_DVPolicyNumber.getValue()
            if (policyNumberFromUI === t.ctx.policyNumber) {
                this.stepAR = `AS EXPECTED, the Policy Number ${t.ctx.policyNumber} is displayed`
                this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
            }
            else {
                this.stepAR = `NOT AS EXPECTED, the Policy Number ${t.ctx.policyNumber} is NOT displayed`
                this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        }
        if ((data.verifyTotalPremiumValue != "") && (data.hasOwnProperty('verifyTotalPremiumValue'))) {
            console.log(`Verify that Total Premium : ${t.ctx.premiumValue} is displayed`)
            this.stepAction = stepDescription.setActionStep(otherConstants.VERIFICATION_STEP)
            this.stepER = `Verify that Total Premium : ${t.ctx.premiumValue} is displayed`
            const totalPremiumValueFromUI = await policySummary.policyFileSummaryTotalPremium.component.innerText
            if (totalPremiumValueFromUI.includes(t.ctx.premiumValue)) {
                this.stepAR = `AS EXPECTED, the Total Premium : ${t.ctx.premiumValue} is displayed`
                this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
            }
            else {
                this.stepAR = `NOT AS EXPECTED, the Total Premium : ${t.ctx.premiumValue} is NOT displayed, UI Shows : ${totalPremiumValueFromUI}`
                this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        }
    }


    async clickNewNoteInPolicySummary(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj)
            this.stepAction = "Click 'Actions' and select 'New Note' option"
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log('Clicking the Actions > New Note')
            await policyMenuActions.policyFilePolicyFileMenuActions.click();
            await policyMenuActions.policyFileMenuActions_CreatePolicyFileMenuActions_NewNote.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async navigateToNotesPageForPolicy(fileObj) {
        try {
            this.stepAction = "Clicking the New Note side menu link"
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetExpResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log('Clicking the New Note side menu link')
            await policyMenuLinks.menuLinksPolicyFile_PolicyFile_Notes.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async createNewActivityForPolicy(fileObj, data) {
        try {
            this.stepAction = `Click 'Actions' > 'New Activity' > ${data.newActivityCategory} > ${data.newActivitySubcategory}`
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepER = stepDescription.resetExpResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log(`Clicking 'Actions' > 'New Activity' > ${data.newActivityCategory} > ${data.newActivitySubcategory}`)
            await policyMenuActions.policyFilePolicyFileMenuActions.click();
            await t.hover(policyMenuActions.policyFileMenuActions_CreatePolicyFileMenuActions_NewActivity.component);
            await t.hover(policySummary.policyFileMenuCategory.component.withExactText(data.newActivityCategory));
            await t.click(policySummary.policyFileMenuCategory.component.withExactText(data.newActivitySubcategory));
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            this.stepAction = stepDescription.setExpResultStep(otherConstants.CLICK_OK_BUTTON)
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            await newActivityWorksheet.newActivityScreenNewActivityScreen_UpdateButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async verifyAddedActivityForPolicy(fileObj, data) {
        try {
            //Verify the Activity Listed
            this.stepAction = stepDescription.setActionStep(otherConstants.VERIFICATION_STEP)
            this.stepER = "Verify the added Activity is listed in Policy Summary Page"
            // noinspection DuplicatedCode
            if (await policySummary.policyFileSummaryCurrentActivitiesSubject.withExactText(data.newActivitySubcategory).exists) {
                this.stepAR = "As Expected, The Added Activity is listed"
                this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
            } else {
                this.stepAR = "Not As Expected, The Added Activity is not listed"
                this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    //Navigate to Policy Transaction Page
    async navigateToPolicyTransactions(fileObj) {
        try {
            this.confirmPageNavigation(fileObj)
            await t.wait(2000)
            this.stepAction = "Navigate to Policy transactions";
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log(`Navigating to Policy Transactions ...`)
            await policyMenuLinks.menuLinksPolicyFile_PolicyFile_Jobs.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = "Error in Navigating to Policy Transactions in " + pageNameStaticContent.POLICY_SUMMARY_PAGE
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    // To initiate Policy Cancel from the Policy Summary page
    async startPolicyCancel(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj)
            this.stepAction = "Click 'Actions' and Select 'Cancel Policy' option in " + pageNameStaticContent.POLICY_SUMMARY_PAGE
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log(`Click 'Actions' and Select Cancel Policy option in ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            await policyMenuActions.policyFilePolicyFileMenuActions.click();
            await policyMenuActions.policyFileMenuActions_NewWorkOrderPolicyFileMenuActions_CancelPolicy.click();
            await t.wait(5000)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    // To initiate Policy Rewrite Full Term from the Policy Summary page
    async selectPolicyRewriteFullTerm(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj)
            this.stepAction = "Click 'Actions' and Select 'Rewrite Full Term' option in " + pageNameStaticContent.POLICY_SUMMARY_PAGE
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log(`Click 'Actions' and Select 'Rewrite Full Term' option in ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            await policyMenuActions.policyFilePolicyFileMenuActions.click();
            await policyMenuActions.startRewriteMenuItemSetRewriteFullTerm.click();
            this.stepAR = "Policy Rewrite Full Term process Started";
            await t.wait(5000)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async startCopySubmission(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj)
            this.stepAction = "Click 'Actions' and Select 'Copy Submission' option in " + pageNameStaticContent.POLICY_SUMMARY_PAGE
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log(`Click 'Actions' and Select 'Copy Submission' option in ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            await policyMenuActions.policyFilePolicyFileMenuActions.click();
            await policyMenuActions.policyFileMenuActions_CreatePolicyFileMenuActions_CopySubmission.click();
            this.stepAR = "Policy Copy Submission process Started";
            await t.wait(5000)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_SUMMARY_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}

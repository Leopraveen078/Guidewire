import { t } from "testcafe";
import { PolicyMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions"
import { Summary } from "../../../../../pages/gw/generated/policycenter/pages/policy/Summary";
import { dateConversion, selectDropdown, captureScreenshot } from "../../../../../util/common/helper";
import { JobWizardInfoBar } from '../LOBWizardStepGroup/Common/JobWizardInfoBar';
import { RiskAnalysisPage } from "../LOBWizardStepGroup/Common/RiskAnalysisPage";

const policyMenuActions = new PolicyMenuActions();
const summary = new Summary();
const jobWizardInfoBar =new JobWizardInfoBar();
const riskAnalysisPage =new RiskAnalysisPage();


export class PolicyChangePage {

    constructor() {
        this.pageName = "Start Policy Change"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    // To confirm page navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await policyMenuActions.StartPolicyChange_StartPolicyChangeScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async navigateToPolicyChange(fileObj) {
        try {
            this.stepAction += " Click On Action.";
            await policyMenuActions.policyFilePolicyFileMenuActions.click();

            this.stepAction += "and Click on Cancel Policy.";
            await policyMenuActions.policyFileMenuActions_NewWorkOrderPolicyFileMenuActions_ChangePolicy.click();
            await this.confirmPageNavigation(fileObj); // Added 'this.' to call the instance method correctly
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async initiatePolicyChange(fileObj, data) {
        try {

            console.log(`EffectiveDate: ${data.Cha_POL_EffectiveDate}`);
            let generatedEffDate = await dateConversion(data.Cha_POL_EffectiveDate, '')
            console.log('generated effective date - ' + generatedEffDate)
            this.stepAction += "'EffectiveDate: " + generatedEffDate + "', <br>";
            await policyMenuActions.startPolicyChangeScreen_StartPolicyChangeDV_EffectiveDate.setValue(generatedEffDate);
           


            console.log(`Enter Descritption : ${data.Cha_change_Description}`);
            this.stepAction += "'Description: " + data.Cha_change_Description + "', <br>";
            await policyMenuActions.startPolicyChangeScreenStartPolicyChangeDV_Description.setValue(data.Cha_change_Description);

            this.stepAction += "'Click on Next', <br>";
            await policyMenuActions.startPolicyChangeScreen_NewPolicyChange_NextButton.click();

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }

    }
    async coverageIncreasePolicyChange(fileObj, data) {
        try {

            
            this.stepAction = "'Click on Coverages', <br>";
            await policyMenuActions.policyChangeWizard_LOBWizardStepGroup_HOCoverages.click();


            console.log(`Select Coverage B - Other Structures: ${data.Cha_Cov_PropCov_CovB_OtherStructure}`);
            this.stepAction += "'Coverage B - Other Structures: " + data.Cha_Cov_PropCov_CovB_OtherStructure + "', <br>";
            await selectDropdown(policyMenuActions.hOPropertyCovDVHODWCovBOtherStructures, data.Cha_Cov_PropCov_CovB_OtherStructure);
            await t.pressKey('tab');

            console.log(`Enter Coverage C - Personal Property: ${data.Cha_Cov_PropCov_CovC_PersProp}`);
            this.stepAction += "'Coverage C - Personal Property: " + data.Cha_Cov_PropCov_CovC_PersProp + "', <br>";
            await policyMenuActions.hODWCovCPersonalPropertyHOCovDirectTermInputSetDirectTermInput.setValue(data.Cha_Cov_PropCov_CovC_PersProp);
            await t.pressKey('tab');

            console.log(`Select Sinkhole Loss Coverage: ${data.Cha_Cov_OthrCov_SinkholLossCov}`);
            this.stepAction += "'Sinkhole Loss Coverage: " + data.Cha_Cov_OthrCov_SinkholLossCov + "', <br>";
            await selectDropdown(policyMenuActions.hOMainCoveragesHOEPanelSetotherDwellingCoveragesIterator0HOCoverageInputSetCovPatternInputGroup0HOCovTermInputSetOptionTermInput, data.Cha_Cov_OthrCov_SinkholLossCov);
            await t.pressKey('tab');

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }

    }

    async issueChangePolicy(fileObj) {
        try {
            this.stepAction = "'Click on Premium Estimate', <br>";
            await policyMenuActions.policyChangeWizardJobWizardToolbarButtonSetQuoteOrReview.click();

            this.stepAction += "'Verfied the Job Status Changed to Policy Change (Draft)', <br>";
            await jobWizardInfoBar.assertSubmissionState(t.ctx.htmlReport, 'Policy Change (Draft)');

            await policyMenuActions.policyChangeWizard_QuoteScreen_JobWizardToolbarButtonSet_BindPolicyChange.click();
            await t.setNativeDialogHandler(() => true);

            await riskAnalysisPage.clearUWIssues(fileObj);

            this.stepAction += "'Click on Issue Transaction', <br>";
            await policyMenuActions.policyChangeWizardJobRiskAnalysisScreenBindPolicyChange.click()
            await t.setNativeDialogHandler(() => true);

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)



        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

   

}
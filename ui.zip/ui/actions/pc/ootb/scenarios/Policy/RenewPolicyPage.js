import { PolicyMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions"
import { captureScreenshot } from "../../../../../util/common/helper";
import { JobWizardInfoBar } from '../LOBWizardStepGroup/Common/JobWizardInfoBar';
import { t } from "testcafe";
import { RenewalRenewingPage } from "./RenewalRenewingPage"

const policyMenuActions = new PolicyMenuActions();
const jobWizardInfoBar = new JobWizardInfoBar();
const renewalRenewingPage = new RenewalRenewingPage();

export class RenewPolicyPage {

    constructor() {
        this.pageName = "Premium Estimate"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    // To confirm page navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        await policyMenuActions.premiumEstimateTitleBar.visible
        if (await policyMenuActions.premiumEstimateTitleBar.exists) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async navigateToRenewalPolicy(fileObj) {
        try {

            this.stepAction = " Click On Action > Renewal Policy<br>";
            this.stepER = "Action Step, Verification N/A"
            await policyMenuActions.policyFilePolicyFileMenuActions.click();
            await policyMenuActions.policyFileMenuActions_NewWorkOrderPolicyFileMenuActions_RenewPolicy.click();
            await t.wait(10000);

            // Handle the confirmation pop-up by accepting it
            await t.setNativeDialogHandler(() => true);

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async initiaterenewalPolicy(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj);

            // Verify the submission state to ensure the renewal is successful
            await jobWizardInfoBar.assertSubmissionState(fileObj, 'Renewal (Renewing)');
            await captureScreenshot();

            this.stepAction = " Click on Edit Transaction > Premium Estimate";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            
            await policyMenuActions.renewalWizard_EditPolicyWorkflow.click();
            await t.wait(5000)
            // Handle confirmation popup
            await t.setNativeDialogHandler(() => true);

            await policyMenuActions.renewalWizard_EditPolicy.click();
            // Handle confirmation popup again
            await t.setNativeDialogHandler(() => true);

            await policyMenuActions.renewalWizard_RenewalQuote.click();

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            this.stepAction = "Click on Bind Option > Renew options";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            await policyMenuActions.renewalWizard_BindOptions.click();

            await policyMenuActions.renewalWizard_BindOptions_SendToRenewal.click();

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async viewAndVerifyPolicyRenewed(fileObj) {
        try {
            await renewalRenewingPage.viewYourRenewedPolicy(t.ctx.htmlReport, "Renewal (Renewing)");

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
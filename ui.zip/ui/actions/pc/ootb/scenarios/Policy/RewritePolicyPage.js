import { PolicyMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions"
import { JobWizardInfoBar } from '../LOBWizardStepGroup/Common/JobWizardInfoBar';
import { t } from "testcafe";
import { selectDropdown, captureScreenshot, dateConversion } from "../../../../../util/common/helper.js";
import { RenewalRenewingPage } from "./RenewalRenewingPage"
import { PrefillPopup } from "../../../../../pages/gw/generated/policycenter/pages/popup/Prefill/PrefillPopup.js";

const policyMenuActions = new PolicyMenuActions();
const jobWizardInfoBar = new JobWizardInfoBar();
const renewalRenewingPage = new RenewalRenewingPage();
const prefillPopup = new PrefillPopup();

export class RewritePolicyPage {

    constructor() {
        this.pageName = "Policy Type Questions"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    // To confirm page navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        await policyMenuActions.policyTypeQuestionsTitleBar.visible
        if (await policyMenuActions.policyTypeQuestionsTitleBar.exists) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async navigateToRewritePolicy(fileObj) {
        try {

            this.stepAction = " Click On Action <br>";
            this.stepER = "Action Step, Verification N/A"
            await policyMenuActions.policyFilePolicyFileMenuActions.click();

            this.stepAction += "and Click on Rewrite Policy.";
            await policyMenuActions.policyFileMenuActions_NewWorkOrderPolicyFileMenuActions_RewritePolicy.click();
            await t.wait(10000);

            // Handle the confirmation pop-up by accepting it
            await t.setNativeDialogHandler(() => true);
            await this.confirmPageNavigation(fileObj);

            // Verify the submission state to ensure the renewal is successful
            await jobWizardInfoBar.assertSubmissionState(fileObj, 'Rewrite Full Term (Draft)');
            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async handlePolicyRewriteAcrossScreens(fileObj, data) {
        try {


            this.stepAction = " Click on Policy Info to Rewrite";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            await policyMenuActions.rewriteWizardLOBWizardStepGroup_PolicyInfo.click();

            console.log(`DOB: ${data.RE_POL_Insured_DOB}`);
            this.stepAction += "'DOB: " + data.RE_POL_Insured_DOB + "', <br>";
            await policyMenuActions.rewriteWizardLOBWizardStepGroup_PolicyInfoDVAccountInfoInputSetDOB.setValue(data.RE_POL_Insured_DOB)
            await t.pressKey('tab');

            console.log(`PurchsdLeasedDate: ${data.RE_POL_PurchsdLeasedDate}`);
            let generatedPurcDate = await dateConversion(data.RE_POL_PurchsdLeasedDate, '')
            console.log('generated purchased date - ' + generatedPurcDate)
            this.stepAction += "'PurchsdLeasedDate: " + generatedPurcDate + "', <br>";
            await policyMenuActions.rewriteWizardpolicyInfoInputSetHOReasonPurchLeaseDateExt.setValue(generatedPurcDate);
            await t.pressKey('tab');

            console.log(`Assign new policy number?: Yes`);
            this.stepAction += "'Assign new policy number: Yes<br>";
            await policyMenuActions.rewriteWizardLOBWizardStepGroupolicyInfoDVChangePolicyNumber_YesButton.click();

            this.stepAR = "Successfully Rewrite done in Policy Info"
            this.verdict = "Passed"

            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            //click on next
            await policyMenuActions.rewriteWizardNext.click();

            this.stepAction = "Rewrite for Property Address Info ";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            console.log(`Enter AddressLine1: ${data.RE_AddressLine1}`);
            this.stepAction += "'AddressLine1: " + data.RE_AddressLine1 + "', <br>";
            await policyMenuActions.rewriteWizardaddressLine1.setValue(data.RE_AddressLine1);
            await t.pressKey('tab');

            console.log(`Enter AddressLine1: ${data.RE_AddressLine2}`);
            this.stepAction += "'AddressLine1: " + data.RE_AddressLine2 + "', <br>";
            await policyMenuActions.rewriteWizardaddressLine2.setValue(data.RE_AddressLine2);
            await t.pressKey('tab');

            console.log(`Enter City: ${data.RE_City}`);
            this.stepAction += "'City: " + data.RE_City + "', <br>";
            await policyMenuActions.rewriteWizardCity.setValue(data.RE_City);
            await t.pressKey('tab');

            console.log(`Enter ZipCode: ${data.RE_ZipCode}`);
            this.stepAction += "'ZipCode: " + data.RE_ZipCode + "', <br>";
            await policyMenuActions.rewriteWizardZipCode.setValue(data.RE_ZipCode);
            await t.pressKey('tab');
            await t.wait(2000);

            console.log(`Property Information: ${data.RE_PropertyInformation}`);
            this.stepAction += "'Property Information: " + data.RE_PropertyInformation + "', <br>";
            await selectDropdown(policyMenuActions.rewriteWizardGlobalAddressInputSet_PropertyInfoStatus, data.RE_PropertyInformation);
            await t.wait(5000);

            await prefillPopup.prefillPopupAcceptReturned.click();
            this.stepAR = "Successfully Rewrite done in Property Address Info"
            this.verdict = "Passed"

            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            //click on next
            await policyMenuActions.rewriteWizardNext.click();


            this.stepAction = "Rewrite for Coverages > Coverages";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""


            if ((data.RE_Cov_PropCov_CovA_Dwelling != "") && (data.hasOwnProperty('RE_Cov_PropCov_CovA_Dwelling'))) {
                console.log(`Enter Coverage A - Dwelling: ${data.RE_Cov_PropCov_CovA_Dwelling}`);
                this.stepAction += "'Coverage A - Dwelling: " + data.RE_Cov_PropCov_CovA_Dwelling + "', <br>";
                await policyMenuActions.rewriteWizardHOCovDirectTermInputSetDirectTermInput.setValue(data.RE_Cov_PropCov_CovA_Dwelling);
                await t.pressKey('tab');
            }

            if ((data.RE_Cov_OthrCov_PerProperRepCost != "") && (data.hasOwnProperty('RE_Cov_OthrCov_PerProperRepCost'))) {
                this.stepAction += "'Personal Property Replacement Cost: " + data.RE_Cov_OthrCov_PerProperRepCost + "', <br>";
                await selectDropdown(policyMenuActions.rewriteWizardHOCovTermInputSetOptionTermInput, data.RE_Cov_OthrCov_PerProperRepCost);
                await t.pressKey('tab');
            }

            this.stepAR = "Successfully Rewrite done in Coverages"
            this.verdict = "Passed"

            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            //click on next
            await policyMenuActions.rewriteWizardNext.click();


            this.stepAction = "Rewrite for Dwelling > Dwelling ";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            console.log(`Date occupied: ${data.RE_Dwell_DateOccupied}`);
            let generatedOccupiedDate = await dateConversion(data.RE_Dwell_DateOccupied, '')
            console.log('generated occupied date - ' + generatedOccupiedDate)
            this.stepAction += "'Date occupied: " + generatedOccupiedDate + "', <br>";
            await policyMenuActions.rewriteWizardHODwellingDetailsHOEDVDateOccupied.setValue(generatedOccupiedDate);

            this.stepAR = "Successfully Rewrite done in Dwelling"
            this.verdict = "Passed"

            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = "Failed to Rewrite for across all Screens"
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }


    async finalizePolicyRewrite(fileObj) {
        try {
            this.stepAction = "'Click on Premium Estimate', <br>";
            await policyMenuActions.rewriteWizardLOBWizardStepGroup_QuoteOrReview.click();
            await t.wait(10000);

            this.stepAction += "'Verfied the Job Status Changed to Rewrite Full Term (Premium Estimated)', <br>";
            await jobWizardInfoBar.assertSubmissionState(fileObj, 'Rewrite Full Term (Premium Estimated)');

            await captureScreenshot();
            
            this.stepAction += "'Click on Issue Transcation', <br>";
            await policyMenuActions.rewriteWizardRewriteWizard_QuoteScreenJobWizardToolbarButtonSetBindRewrite.click();

            await t.setNativeDialogHandler(() => true);
            await t.wait(10000);

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async viewAndVerifyRewritePolicy(fileObj) {
        try {
            await renewalRenewingPage.viewYourRenewedPolicy(t.ctx.htmlReport, "Renewal (Renewing)");

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
import { PolicyFileNotesScreen } from "../../../../../pages/gw/ScenarioPages/Policy/PolicyFileNotesScreen.js";
import { t } from "testcafe";
import { captureScreenshot } from "../../../../../util/common/helper.js";

const policyFileNotesScreen = new PolicyFileNotesScreen();

export class PolicyFileNotesPage {
    constructor() {
        this.pageName = "Notes"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the Policy File Notes Page"
        if (await policyFileNotesScreen.policyFileNotesTitleBar.visible) {
            this.stepAR = "Successfully navigated to the Policy File Notes Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the Policy File Notes Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async searchAndVerifyAddedNotesInPolicyFilePage(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            //Search the Added Notes
            this.stepAction = `Enter 'Text Search' as ${data.newNoteText} and click Search button`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            await policyFileNotesScreen.policyFile_NotesPolicy_NotesScreenNoteSearchDVTextSearch.setValue(data.newNoteText);
            await policyFileNotesScreen.policyFile_NotesPolicy_NotesScreenNoteSearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            //Verify the Notes Listed
            let policyNoteSearchResult = await policyFileNotesScreen.policy_NotesScreenNotesLV.rowCount();
            console.log("Search Result Count: " + policyNoteSearchResult);
            this.stepAction = "Verification Step, Action N/A"
            this.stepER = "Verify the added Notes are listed in Policy File Notes Page"
            if (policyNoteSearchResult > 0) {
                this.stepAR = "As Expected, The Added Notes are listed"
                this.verdict = "Passed"
            } else {
                this.stepAR = "Not As Expected, The Added Notes are not listed"
                this.verdict = "Failed"
                captureScreenshot();
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}
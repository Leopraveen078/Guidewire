import { PolicyMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions"
import { ReinstatementBoundPage } from "./ReinstatementBoundPage";
import { t } from "testcafe"

const policyMenuActions = new PolicyMenuActions();
const reinstatementBoundPage = new ReinstatementBoundPage();

export class ReinstatePolicyPage {

    constructor() {
        this.pageName = "Reinstatement Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    // To confirm page navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await policyMenuActions.reinstatementWizard_ReinstatePolicyScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async navigateToReinstatePolicy(fileObj) {
        try {

            this.stepAction = " Click On Action > Reinstate Policy<br>";
            this.stepER = "Action Step, Verification N/A"
            await policyMenuActions.policyFilePolicyFileMenuActions.click();
            await policyMenuActions.policyFileMenuActions_NewWorkOrderPolicyFileMenuActions_ReinstatePolicy.click();

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async reinstatePolicy(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            console.log(`Enter the Reason Description: ${data.ReinstatementDescription}`);
            this.stepAction = "'Enter below Reinstatement description details..<br>";
            this.stepAction += "'Reason Description: " + data.ReinstatementDescription + "', <br>";
            await t.typeText(policyMenuActions.reinstatementWizard_ReinstatePolicyDV_ReasonDescription_Selector, data.ReinstatementDescription);

            this.stepAction += " Click on Premium Estimate Button.";
            await policyMenuActions.reinstatementWizard_QuoteOrReview.click();

            this.stepAction += "Click on Reinstate Button.";
            await policyMenuActions.reinstatementWizard_Reinstate.click();

            //handle confirmation pop up
            await t.setNativeDialogHandler(() => true);

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async viewAndVerifyPolicyReinstated(fileObj) {
        try {
            await reinstatementBoundPage.viewYourReinstatedPolicy(t.ctx.htmlReport, "Reinstatement (Bound)");
            await reinstatementBoundPage.verifyPolicyReinstated(t.ctx.htmlReport, "In Force");

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
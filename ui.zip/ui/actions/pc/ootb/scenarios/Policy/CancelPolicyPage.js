import { t } from "testcafe";
import { PolicyMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions"
import { Summary } from "../../../../../pages/gw/generated/policycenter/pages/policy/Summary";
import { captureScreenshot, dateConversion, selectDropdown } from "../../../../../util/common/helper";
import { CancelBoundPage } from "./CancelBoundPage";


const policyMenuActions = new PolicyMenuActions();
const summary = new Summary();
const cancelBoundPage = new CancelBoundPage();

export class CancelPolicyPage {

    constructor() {
        this.pageName = "Start Cancellation For Policy"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    // To confirm page navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await policyMenuActions.startCancellationScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async navigateToCancelPolicy(fileObj) {
        try {
            this.stepAction = " Click On Action > Cancel Policy<br>";
            this.stepER = "Action Step, Verification N/A"
            await policyMenuActions.policyFilePolicyFileMenuActions.click();
            await policyMenuActions.policyFileMenuActions_NewWorkOrderPolicyFileMenuActions_CancelPolicy.click();

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async cancelPolicy(fileObj, data, cancellationType) {
        try {
            await this.confirmPageNavigation(fileObj);

            let cancellationSource = data.CancellationSource;
            let cancellationReasons = data.CancellationReasons;

            console.log(`Select Source from Dropdown: ${cancellationSource}`);
            this.stepAction = "'Enter below cancellation details..<br>";
            this.stepAction += "'Source: " + cancellationSource + "', <br>";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            await selectDropdown(policyMenuActions.startCancellationInputSet_HOSource_Selector, cancellationSource);

            if (cancellationSource.includes("Insured")) {
                console.log(`Select Reasons from Dropdown: ${cancellationReasons}`);
                this.stepAction += "'Reasons: " + cancellationReasons + "', <br>";
                await selectDropdown(policyMenuActions.startCancellationInputSet_HOInsuredReason_Selector, cancellationReasons);

            } else if (cancellationSource.includes("Carrier")) {
                console.log(`Non-Inspection Reasons from Dropdown: ${cancellationReasons}`);
                this.stepAction += "'Non-Inspection Reasons: " + cancellationReasons + "', <br>";
                switch (cancellationReasons) {
                    case "2 or more nonweather water-related losses within 36 months. (C187)":
                        await policyMenuActions.startCancellationInputSet_HOCarrierReason_nonWeather_36months.click();
                        break;
                }
            }

            if (cancellationType.includes('flat')) {
                t.ctx.cancellationEffectiveDate = t.ctx.policyEffectiveDate;
                console.log(`Cancellation Effective Date: ${t.ctx.cancellationEffectiveDate}`);
                this.stepAction += "'Cancellation Effective Date: " + t.ctx.cancellationEffectiveDate + "', <br>";
                await policyMenuActions.startCancellationInputSet_HOCancelDate_date.setValue(t.ctx.cancellationEffectiveDate);
                await t.pressKey('tab');
                await t.pressKey('tab');
                await t.wait(3000);
                await t.pressKey('tab');

            } else if (cancellationType.includes('prorata')) {

                // if CancellationEffectiveDate is 0, it cancels for today
                // if CancellationEffectiveDate is not 0(any +- integer), provided integer is used for calc with reference to Policy Effective Date

                console.log(`Cancellation Effective Date: ${data.CancellationEffectiveDate}`);
                let generatedCancelEffDate = await dateConversion(data.CancellationEffectiveDate, t.ctx.policyEffectiveDate)
                t.ctx.cancellationEffectiveDate = generatedCancelEffDate;

                console.log('Generated cancellation effective date - ' + t.ctx.cancellationEffectiveDate)
                this.stepAction += "'Cancellation Effective Date: " + t.ctx.cancellationEffectiveDate + "', <br>";
                await policyMenuActions.startCancellationInputSet_HOCancelDate_date.setValue(t.ctx.cancellationEffectiveDate);
                await t.pressKey('tab');
                await t.pressKey('tab');
                await t.wait(3000);
                await t.pressKey('tab');
            }

            console.log(`Cancellation Type: ${data.CancellationType}`);
            this.stepAction += "'Cancellation Type: " + data.CancellationType + "', <br>";
            await this.verifyCancellationType(data.CancellationType);

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            this.stepAction = "Click on Start Cancellation > Bind Option > Schedule Cancellation";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            await policyMenuActions.startCancellationScreen_NewCancellation.click();
            await policyMenuActions.CancellationWizard_BindOptions.click();
            await policyMenuActions.CancellationWizard_BindOptions_SubmitCancellation.click();
            //handle confirmation pop up 
            await t.setNativeDialogHandler(() => true);

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async viewAndVerifyPolicyCancelled(fileObj) {
        try {
            await cancelBoundPage.viewYourCancelledPolicy(t.ctx.htmlReport, "Cancellation (Bound)");
            await cancelBoundPage.verifyPolicyCanceled(t.ctx.htmlReport, "Canceled");

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async viewAndVerifyPolicyCancellationScheduled(fileObj) {
        try {
            
            // code needed to be revised for Scheduled Cancellation flow
            // await cancelBoundPage.viewYourCancelledPolicy(t.ctx.htmlReport, "Cancellation (Bound)");
            // await cancelBoundPage.verifyPolicyCanceled(t.ctx.htmlReport, "Canceled");

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async verifyCancellationType(expectedCancellationType) {
        let cancellationType = await policyMenuActions.startCancellationInputSet_HOCalcMethod.component.innerText;
        // Check if status matches the expected status
        if (cancellationType !== expectedCancellationType)
            throw new Error(`Expected status to be "${expectedCancellationType}", but got "${cancellationType}".`);
        return cancellationType;
    }

}

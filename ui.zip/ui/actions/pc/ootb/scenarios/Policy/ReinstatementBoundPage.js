'use strict';
import { t } from 'testcafe';
import { PolicyMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions";
import { JobWizardInfoBar } from '../LOBWizardStepGroup/Common/JobWizardInfoBar';
import { Summary } from '../../../../../pages/gw/generated/policycenter/pages/account/Summary';
import { captureScreenshot } from '../../../../../util/common/helper';


const policyMenuActions = new PolicyMenuActions();
const jobWizardInfoBar = new JobWizardInfoBar();
const summaryAccount = new Summary();
export class ReinstatementBoundPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
        this.pageName = "Reinstatement Bound"
    }

    //To Confirm Page Navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        await policyMenuActions.reinstatementBoundttlBar.visible
        if (await policyMenuActions.reinstatementBoundttlBar.exists) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the  ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    //To view policy details and capture in submission bound page
    async viewYourReinstatedPolicy(fileObj, data) {
        try {
            await this.confirmPageNavigation(t.ctx.htmlReport);

            captureScreenshot();
            await jobWizardInfoBar.assertSubmissionState(t.ctx.htmlReport, data);

            console.log(`Clicking on View your policy ...`)
            this.stepAction = `Click the View your policy link from ${this.pageName}`
            this.stepAR = ""
            this.verdict = ""
            await policyMenuActions.submissionBoundScreenViewPolicy.click();
            await t.wait(5000);

            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async verifyPolicyReinstated(fileObj, expectedStatus) {
        try {
            //verify policy cancelled
            this.stepAction = "Verification Step, Action N/A"
            this.stepER = `Verify that the policy is at In Force state`
            this.stepAR = ""
            this.verdict = ""
            await policyMenuActions.accountHyperLink.click();
            const statusColumnIndex = 6;
            let status = await summaryAccount.accountFile_SummaryScreenAccountFile_Summary_PolicyTermsLV.getTextFromCell(0, statusColumnIndex);

            // Check if status matches the expected status
            if (status !== "In Force") {
                this.stepAR = `Invalid policy status as ${status} under Account summary page > Policy Terms > Policy Status`
                this.verdict = "Failed"
            } else {
                this.stepAR = `Successfully verified the policy status as ${expectedStatus}`
                this.verdict = "Passed"
            }

            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
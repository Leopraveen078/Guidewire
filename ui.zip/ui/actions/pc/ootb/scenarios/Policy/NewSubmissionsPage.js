import { dateConversion, captureScreenshot } from '../../../../../util/common/helper';
import { t, Selector } from 'testcafe';
import { NewSubmissionScreen_Ext } from "../../../../../pages/gw/ScenarioPages/Policy/NewSubmissionScreen_Ext";

const newSubmissionScreen_Ext = new NewSubmissionScreen_Ext();

export class NewSubmissionsPage {

    constructor() {
        this.pageName = "New Submissions Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    //To confirm page navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await newSubmissionScreen_Ext.newSubmissionScreenTitleBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    // After entering the Effective Date, page needs to be reloaded
    async initiateNewSubmission(fileObj, data, policyType) {
        try {
            await this.confirmPageNavigation(fileObj);
            if (data.effectiveDate == "Today") {
                this.stepAction = `Select Effective Date as Today in ${this.pageName}`;
                this.stepER = "Action Step, Verification N/A"
                this.stepAR = ""
                this.verdict = ""
                console.log(`Click calender icon in Effective Date field ...`)
                await newSubmissionScreen_Ext.newSubmissionScreenEffectiveDatePicker.click();
                console.log(`Click Today button in Effective Date calender ...`)
                await newSubmissionScreen_Ext.newSubmissionScreenDatePickerTodayButton.click();
                await t.pressKey('tab')
                await newSubmissionScreen_Ext.newSubmissionScreenTitleBar.click();
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            } else if (data.effectiveDate != "" && data.hasOwnProperty('effectiveDate')) {
                var today = new Date();
                let effectiveDateString = await dateConversion(data.effectiveDate, '');
                console.log(`Enter '${effectiveDateString}' in Effective Date field ...`)
                await newSubmissionScreen_Ext.productSettingsDVDefaultPPEffDate.setValue(effectiveDateString)
                await t.pressKey('tab')
                await newSubmissionScreen_Ext.newSubmissionScreenTitleBar.click();
                this.stepAction = `Enter Effective Date as : ${effectiveDateString} in ${this.pageName}`
                this.stepER = "Action Step, Verification N/A"
                this.stepAR = ""
                this.verdict = ""
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            }

            this.stepAction = `Select Policy-Type as ${policyType} from ${this.pageName}`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            let productSelectButton = newSubmissionScreen_Ext.newSubmissionScreenProductOffersDVProductSelectionLV.component.find('td[id$=-Name_Cell]').withExactText(policyType).sibling('td[id$=-Select]').find('div.gw-LinkWidget[id$=-addSubmission]');
            await t.click(productSelectButton);
            
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async executeQuickJumpCommand(command) {
        if (await Selector('div#QuickJump').exists && await Selector('div#QuickJump').visible)
            await t.typeText(Selector('div#QuickJump'), command, { replace: true, paste: true }).pressKey('enter');
        else
            await t.typeText(Selector('#QuickJump'), command, { replace: true, paste: true }).pressKey('enter');
    }

    async getCurrentDate() {
        await this.executeQuickJumpCommand("Run Clock")
        let screenMsg = PcfComponent("#NewSubmission-NewSubmissionScreen-_msgs")
        let currentDate = await screenMsg.component.innerText
        return currentDate.slice(-10).trim()
    }

}
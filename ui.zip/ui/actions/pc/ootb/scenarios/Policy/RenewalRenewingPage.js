'use strict';
import { t } from 'testcafe';
import { PolicyMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions";
import { JobWizardInfoBar } from '../LOBWizardStepGroup/Common/JobWizardInfoBar';
import { Summary } from '../../../../../pages/gw/generated/policycenter/pages/policy/Summary';
import { BoundScreen } from '../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/BoundScreen';
import { captureScreenshot } from '../../../../../util/common/helper';

const renewalRenewingScreen = new BoundScreen();
const policyMenuActions = new PolicyMenuActions();
const jobWizardInfoBar = new JobWizardInfoBar();
const summary = new Summary();

export class RenewalRenewingPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
        this.pageName = "Renewal Renewing"
    }

    //To Confirm Page Navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        await policyMenuActions.renewalRenewing_ttlBar.visible
        if (await policyMenuActions.renewalRenewing_ttlBar.exists) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the  ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async assertRenewalRenewing(fileObj) {
        this.stepAction = `Verification Step. Action N/A`;
        this.stepER = "Verify the Policy Renewal is bound.";

        let actualText = await renewalRenewingScreen.JobComplete_JobCompleteScreen_Message.component.innerText;
        console.log(`Actual text found: ${actualText}`);

        let renewalMessage = actualText.match(/^Your renewal \(\#\d+\) is in the process of being renewed\.$/);

        if (renewalMessage) {
            let policyText = await renewalRenewingScreen.JobComplete_JobCompleteScreen_JobCompleteDV_ViewPolicy.component.innerText;
            var policyNumber = policyText.replace('View your policy (#', '').replace(")", "");
            t.ctx.policyNumber = policyNumber;  // Store the policy number in t.ctx.policyNumber
            console.log("Stored Policy number:", t.ctx.policyNumber);  // Log the stored policy number

            var TransactionNumber = actualText.replace('Your renewal (#', '').replace(") is in the process of being renewed.", "");

            console.log(`Capturing Policy Renewal Transaction Number: ${TransactionNumber} and Policy Number: ${policyNumber}`);
            this.stepAR = `AS EXPECTED, Policy Renewal is bound successfully.<br>The Policy Renewal Transaction number is "${TransactionNumber}" for Policy - "${policyNumber}".`;
            this.verdict = "Passed";
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } else {
            console.log(`NOT AS EXPECTED, Policy Renewal is NOT bound successfully.`);
            this.stepAR = `NOT AS EXPECTED, Policy Renewal is NOT bound successfully.`;
            this.verdict = "Failed";
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        }
    }

    async viewYourRenewedPolicy(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            captureScreenshot();
            await jobWizardInfoBar.assertSubmissionState(fileObj, data);
            await this.assertRenewalRenewing(fileObj);

            // Click the "View your policy" link
            this.stepAction = "Click the View your policy link.";
            this.stepER = "View your policy link should be clicked successfully.";
            this.stepAR = ""
            this.verdict = ""

            console.log("Clicking on View your policy...");
            await policyMenuActions.submissionBoundScreenViewPolicy.click();
            await t.wait(5000);


            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = "";
            this.stepER = "";
            this.stepAR = `Error in ${this.pageName}`;
            this.verdict = "Failed";
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }


    async getStatusOpenPolicyTranscation(row, expectedStatus, fileObj) {
        try {
            const statusColumnIndex = 3;
            this.stepAction = `Get status from row ${row}, column ${statusColumnIndex}.`;
            this.stepER = `Expected status: ${expectedStatus}`;

            // Get the status from the specified row and column
            let status = await summary.pendingPolicyTransactionsListViewTilePendingPolicyTransactionsListViewTile_LV.getTextFromCell(row, statusColumnIndex);

            // Check if status matches the expected status
            if (status !== expectedStatus) {
                throw new Error(`Expected status to be "${expectedStatus}", but got "${status}".`);
            }
            this.stepAR = `Successfully retrieved status: ${status}`;
            this.verdict = "Passed";

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            // Return the status if it matches the expected value
            return status;
        } catch (err) {
            this.stepAction = `Failed to retrieve or verify status from row ${row}.`;
            this.stepER = `Expected status: ${expectedStatus}`;
            this.stepAR = `Error encountered: ${err.message}`;
            this.verdict = "Failed";

            if (fileObj) {
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            }
            console.error(`Error in getStatusOpenPolicyTranscation: ${err.message}`);
            throw err;
        }
    }


}
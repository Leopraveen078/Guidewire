'use strict';
import { t } from 'testcafe';
import { PolicyMenuActions } from "../../../../../pages/gw/generated/policycenter/pages/navigation/menuActions/PolicyMenuActions";
import { JobWizardInfoBar } from '../LOBWizardStepGroup/Common/JobWizardInfoBar';
import { captureScreenshot } from '../../../../../util/common/helper';


const policyMenuActions = new PolicyMenuActions();
const jobWizardInfoBar = new JobWizardInfoBar();

export class RewriteBoundPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
        this.pageName = "Rewrite Full Term Bound"
    }

    //To Confirm Page Navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        await policyMenuActions.rewriteWizardJobCompleteJobCompleteScreenttlBar.visible
        if (await policyMenuActions.rewriteWizardJobCompleteJobCompleteScreenttlBar.exists) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the  ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    //To view policy details and capture in submission bound page
    async viewYourRewritePolicy(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj);

            captureScreenshot();
            await jobWizardInfoBar.assertSubmissionState(fileObj, 'Rewrite Full Term (Bound)');

            console.log(`Clicking on View your policy ...`)
            this.stepAction = `Click View your policy link from ${this.pageName}`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            await policyMenuActions.submissionBoundScreenViewPolicy.click();
            await t.wait(5000);
            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}
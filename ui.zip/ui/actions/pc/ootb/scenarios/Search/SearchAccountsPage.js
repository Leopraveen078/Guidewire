import { SearchAccountsScreen } from "../../../../../pages/gw/ScenarioPages/Search/SearchAccountsScreen.js";
import { t } from "testcafe";
import { captureScreenshot } from "../../../../../util/common/helper.js";
import { SearchTabBar } from "../../../../../pages/gw/generated/policycenter/pages/navigation/tabBar/SearchTabBar.js";
import { AccountTabBar } from "../../../../../pages/gw/generated/policycenter/pages/navigation/tabBar/AccountTabBar.js";
import { Summary } from "../../../../../pages/gw/generated/policycenter/pages/account/Summary.js";

const searchAccountsScreen = new SearchAccountsScreen();
const searchTabBar = new SearchTabBar();
const accountTabBar = new AccountTabBar();
const summary = new Summary();

export class SearchAccountsPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the Search Accounts Page"
        if (await searchAccountsScreen.searchAccountsScreenTitleBar.visible) {
            this.stepAR = "Successfully navigated to the Search Accounts Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the Search Accounts Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async searchAccounts(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj)

            console.log('Searching Accounts by First Name and Last Name')
            this.stepAction = `Search Accounts by First Name - ${data.firstName} and Last Name - ${t.ctx.lastName}`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            if ((data.companyName !== '') && (data.hasOwnProperty('companyName'))) {
                await searchAccountsScreen.accountSearchAccountSearchScreenAccountSearchDVGlobalContactNameInputSetName.setValue(t.ctx.companyName);
            }
            else {
                await searchAccountsScreen.accountSearchAccountSearchScreenAccountSearchDVGlobalPersonNameInputSetFirstName.setValue(data.firstName);
                await searchAccountsScreen.accountSearchAccountSearchScreenAccountSearchDVGlobalPersonNameInputSetLastName.setValue(t.ctx.lastName);
            }

            await searchAccountsScreen.accountSearchAccountSearchScreenAccountSearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Account Summary Page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async verifyAccountExists(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify if the Created Account is listed in Search Accounts Page"
        await t.wait(2000);
        await t.debug().setNativeDialogHandler(() => true);
        let accountResult = await searchAccountsScreen.accountSearchScreenAccountSearchResultsLV.rowCount();
        let accountNumber = await searchAccountsScreen.searchAccountAccountNumberFromResults.component.innerText;
        console.log("Search Result Count: " + accountResult);
        if (accountResult > 0) {
            this.stepAR = "As Expected, Created Account is listed - " + accountNumber
            this.verdict = "Passed"
        } else {
            this.stepAR = "Not As Expected, The Created Account is not listed"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    async enterSearchFields(fileobj, companyName, firstName, lastName, zipcode) {
        this.stepAction = "Enter below details and click on search button<br>";
        this.stepER = "Action Step, Verification N/A"
        this.stepAR = ""
        this.verdict = ""
        if (companyName !== '') {
            this.stepAction += "Company Name: " + companyName + ",<br>";
            console.log("Enter Company Name: " + companyName);
            await searchAccountsScreen.accountSearchAccountSearchScreenAccountSearchDVGlobalContactNameInputSetName.setValue(companyName);
        } else {
            this.stepAction += "First Name: " + firstName + ",<br>";
            console.log("Enter First Name: " + firstName);
            await searchAccountsScreen.searchAccountScreenFirstName.setValue(firstName);
            this.stepAction += "Last Name: " + lastName + ",<br>";
            console.log("Enter Last Name: " + lastName);
            await searchAccountsScreen.searchAccountScreenLastName.setValue(lastName);
            this.stepAction += "Zipcode: " + zipcode + "<br>";
            console.log("Enter Zipcode: " + zipcode);
            await searchAccountsScreen.searchAccountScreenZipCode.setValue(zipcode);
            await t.pressKey("tab");
            await t.wait(3000);

        }


        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async searchByAccountNumber(fileObj, accountNumber) {
        try {
            await this.confirmPageNavigation(fileObj)
            this.stepAction = `Enter Account Number : ${accountNumber} and Click 'Search' button`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            await searchAccountsScreen.accountSearchDVAccountNumber.setValue(accountNumber);
            await searchAccountsScreen.accountSearchAccountSearchScreenAccountSearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            await t.wait(2000);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Account Summary Page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async navigateToSearchAccountScreen(fileobj) {
        this.stepAction = `Navigate to Search > Accounts`
        this.stepER = "Action step, Verification N/A"
        this.stepAR = ""
        this.verdict = ""

        console.log(`Go to Search > Accounts`)
        await t.click(searchTabBar.tabBarSearchTab.component.find("div.gw-action--expand-button"));
        await searchTabBar.searchTabSearch_AccountSearch.click();
        await t.wait(1000);

        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async unCheckFilterCheckbox() {
        await searchAccountsScreen.searchAccountScreenFirstNameExact_checkbox.click();
        await searchAccountsScreen.searchAccountScreenLastNameExact_checkbox.click();
        await searchAccountsScreen.searchAccountScreenCompanyNameExact_checkbox.click();

    }

    async resetButtonForSearchFilter(fileobj) {
        this.stepAction = "Click reset button"
        this.stepER = "Action Step, Verification N/A"
        this.stepAR = ""
        this.verdict = ""
        await searchAccountsScreen.searchAccountSearchScreenReset.click();

        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async verifySearchAccountsPageAccountSearch(fileobj, data) {
        try {
            let plContactFirstName = data.P_FirstName;
            let plContactLastName = data.P_LastName;
            let zipCode = data.ZipCode;
            let clContactName = data.C_Name;

            // PL account search
            await this.navigateToSearchAccountScreen(fileobj);
            await this.resetButtonForSearchFilter(fileobj);
            await this.unCheckFilterCheckbox(fileobj);
            await this.enterSearchFields(fileobj, '', plContactFirstName, plContactLastName, zipCode);

            this.stepAction = "Click Search button";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
             
            await searchAccountsScreen.searchAccountScreenButton.click();
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            await this.verifyAccountExists(fileobj);
            t.ctx.plAccountNumber = await searchAccountsScreen.searchAccountAccountNumberFromResults.component.innerText;
            console.log("PL account number: " + t.ctx.plAccountNumber)

            // CL account search
            await this.navigateToSearchAccountScreen(fileobj);
            await this.resetButtonForSearchFilter(fileobj);
            await this.unCheckFilterCheckbox(fileobj);
            await this.enterSearchFields(fileobj, clContactName, '', '', zipCode);

            this.stepAction = "Click Search button";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            await searchAccountsScreen.searchAccountScreenButton.click();
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            await this.verifyAccountExists(fileobj);
            t.ctx.clAccountNumber = await searchAccountsScreen.searchAccountAccountNumberFromResults.component.innerText;
            console.log("CL account number: " + t.ctx.clAccountNumber)

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Search Account"
            this.verdict = "Failed"
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async verifyAccountMenuAccountSearch(fileobj) {
        // PL account search
        await this.searchAccountUnderAccountMenu(fileobj, t.ctx.plAccountNumber, "PL");
        await this.verifyAccountSummaryDisplayed(fileobj)
        console.log("Verified PL type account search")
        // CL account search
        await this.searchAccountUnderAccountMenu(fileobj, t.ctx.clAccountNumber, "CL");
        await this.verifyAccountSummaryDisplayed(fileobj)
        console.log("Verified CL type account search")
    }

    async verifyPolicyMenuSearch(fileobj) {
        // PL account search
        await this.searchAccountUnderAccountMenu(fileobj, t.ctx.plAccountNumber, "PL");
        await this.verifyAccountSummaryDisplayed(fileobj)
        console.log("Verified PL type account search")
        // CL account search
        await this.searchAccountUnderAccountMenu(fileobj, t.ctx.clAccountNumber, "CL");
        await this.verifyAccountSummaryDisplayed(fileobj)
        console.log("Verified CL type account search")
    }


    async searchAccountUnderAccountMenu(fileobj, accountNumber, accountType) {
        try {
            this.stepAction = "Go to Account > Search and provide " + accountType + " account number[" + accountNumber + "] and click on Search"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            await t.click(accountTabBar.tabBarAccountTab.component.find('div.gw-action--expand-button'));
            await accountTabBar.accountTabAccountTab_AccountNumberSearchItem.setValue(accountNumber);
            await accountTabBar.tabBarAccountTab_AccountNumberSearchItem_Button.click();
            await t.wait(5000)

            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Account Menu Search"
            this.verdict = "Failed"
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async verifyAccountSummaryDisplayed(fileobj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify if the account number searched displayed under Summary screen"

        if (await summary.accountFile_Summary_BasicInfoDVAccountNumber.component.visible) {
            this.stepAR = "Successfully verified the searched Account number [" + await summary.accountFile_Summary_BasicInfoDVAccountNumber.component.innerText + "] appears under the Summary screen"
            this.verdict = "Passed"
        } else {
            this.stepAR = `Searched Account number failed to retrieve and display on screen`
            this.verdict = "Failed"
        }
        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

    }

}
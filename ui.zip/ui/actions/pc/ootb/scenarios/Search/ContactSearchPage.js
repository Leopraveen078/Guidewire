import { ContactSearchScreen_Ext } from "../../../../../pages/gw/ScenarioPages/Search/ContactSearchScreen_Ext"
import { ContactTabBar } from "../../../../../pages/gw/generated/policycenter/pages/navigation/tabBar/ContactTabBar";
import { captureScreenshot } from "../../../../../util/common/helper"
import { t } from "testcafe";

const contactSearch = new ContactSearchScreen_Ext();
const contactTabBar = new ContactTabBar();

export class ContactSearchPage {
    constructor() {
        this.pageName = "Search Contact Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async searchForContact(fileobj, data) {
        try {

            if (data.searchContactBy != "") {
                for (let i = 0; i < data.searchContactBy.length; i++) {
                    this.stepAction = "Click Contact Tab from info bar and then Click Search"
                    this.stepER = "Action step, Verification N/A"
                    this.stepAR = ""
                    this.verdict = ""
                    await this.selectContactTabBarContactSearch();
                    await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

                    await this.confirmPageNavigation(fileobj);

                    this.stepAction = " Search '" + data.searchContactBy[i].type + "' contact : "
                    this.stepER = "Action step, Verification N/A"
                    this.stepAR = ""
                    this.verdict = ""
                    //select search contact type
                    await contactSearch.contactSearchScreenContactType.selectOptionByValue(data.searchContactBy[i].type);

                    //search person contact by first and last name
                    if (data.searchContactBy[i].hasOwnProperty('firstName')) {
                        if ((data.searchContactBy[i].firstName != "") && (data.searchContactBy[i].hasOwnProperty('firstName'))) {
                            console.log(", First Name: " + data.searchContactBy[i].firstName)
                            this.stepAction = this.stepAction + "Enter First Name as ' " + data.searchContactBy[i].firstName + "'"
                            await contactSearch.contactSearchContactSearchScreenBasicContactInfoInputSetGlobalPersonNameInputSetFirstName.setValue(data.searchContactBy[i].firstName);
                        }
                        if ((data.searchContactBy[i].lastName != "") && (data.searchContactBy[i].hasOwnProperty('lastName'))) {
                            console.log(", Last Name: " + data.searchContactBy[i].lastName)
                            this.stepAction = this.stepAction + ", Last Name as ' " + data.searchContactBy[i].lastName + "'"
                            await contactSearch.contactSearchContactSearchScreenBasicContactInfoInputSetGlobalPersonNameInputSetLastName.setValue(data.searchContactBy[i].lastName)
                        }
                        else {
                            console.log(", Last Name: " + t.ctx.lastName)
                            this.stepAction = this.stepAction + ", Last Name as ' " + t.ctx.lastName + "'"
                            await contactSearch.contactSearchContactSearchScreenBasicContactInfoInputSetGlobalPersonNameInputSetLastName.setValue(t.ctx.lastName)
                        }
                    }//search company contact by name
                    else if (data.searchContactBy[i].hasOwnProperty('name')) {
                        if ((data.searchContactBy[i].name != "") && (data.searchContactBy[i].hasOwnProperty('name'))) {
                            console.log(" Name: " + data.searchContactBy[i].name)
                            this.stepAction = this.stepAction + " Enter Name as ' " + data.searchContactBy[i].name + "'"
                            await contactSearch.contactSearchContactSearchScreenBasicContactInfoInputSetGlobalContactNameInputSetName.setValue(data.searchContactBy[i].name);
                        }
                    }//search contact by taxId
                    else if (data.searchContactBy[i].hasOwnProperty('taxId')) {
                        if ((data.searchContactBy[i].taxId != "") && (data.searchContactBy[i].hasOwnProperty('taxId'))) {
                            console.log(" Searching contact with Tax ID: " + data.searchContactBy[i].taxId)
                            await contactSearch.basicContactInfoInputSetTaxID.setValue(data.searchContactBy[i].taxId);
                            this.stepAction = this.stepAction + ", tax ID as ' " + data.searchContactBy[i].taxId + "'"
                        }
                    }
                    //click search button
                    await contactSearch.contactSearchContactSearchScreenSearchAndResetInputSetSearchLinksInputSetSearch.click();
                    this.stepAction = this.stepAction + " and Click Search Button"
                    await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
                }
            }
        }
        catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async checkContactSearchResult(fileobj) {
        try {
            await t.wait(5000);
            let count = await contactSearch.contactSearchScreenContactSearchResultsLV.rowCount();
            console.log("Contacts found: " + count);

            this.stepAction = "Verification step, Action N/A"
            this.stepER = "Verify the Contact search return results greater than zero"
            this.stepAR = ""
            this.verdict = ""

            if (count > 0) {
                this.stepAR = "As Expected, " + count + " contacts were found"
                this.verdict = "Passed"
            }
            else {
                this.stepAR = "Not as Expected, No Contacts were found"
                this.verdict = "Failed"
                captureScreenshot();
            }
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        }
        catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async openTabBarContactTabMenuItem() {
        !await contactTabBar.tabBarContactTab.component.hasClass('gw-hasOpenSubMenu') && await t.click(contactTabBar.tabBarContactTab.component.find('div.gw-action--expand-button'));
    }

    async selectContactTabBarContactSearch() {
        await this.openTabBarContactTabMenuItem();
        await contactTabBar.contactTabSearch.click();
    }

    async confirmPageNavigation(fileobj) {
        this.stepAction = "Verification step, Action N/A"
        this.stepER = "Verify that you are taken to Search Contacts Page"
        this.stepAR = ""
        this.verdict = ""
        if (await contactSearch.contactSearchScreenTitleBar.component.visible) {
            this.stepAR = "Successfully navigated to Search Contacts Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to Search Contacts Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }
}
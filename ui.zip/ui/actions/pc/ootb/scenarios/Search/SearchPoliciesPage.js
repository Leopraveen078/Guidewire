import { SearchTabBar_Ext } from "../../../../../pages/gw/ScenarioPages/Navigation/SearchTabBar_Ext"
import { SearchPoliciesScreen } from "../../../../../pages/gw/ScenarioPages/Search/SearchPoliciesScreen"
import { SearchTabBar } from "../../../../../pages/gw/generated/policycenter/pages/navigation/tabBar/SearchTabBar.js";
import { PolicyTabBar } from "../../../../../pages/gw/generated/policycenter/pages/navigation/tabBar/PolicyTabBar.js";
import { ClientFunction } from 'testcafe';
import { Summary } from "../../../../../pages/gw/generated/policycenter/pages/account/Summary.js";
import { t } from "testcafe";
import { Selector } from 'testcafe';
import { captureScreenshot } from "../../../../../util/common/helper";
import { WindowNavigation_Ext } from "../../../../../../ui/actions/gw/WindowNavigation_Ext.js"
import { error } from "winston";

const searchTabBar_Ext = new SearchTabBar_Ext();
const searchPoliciesScreen = new SearchPoliciesScreen();
const policyTabBar = new PolicyTabBar();
const searchTabBar = new SearchTabBar();
const windowNavigation_Ext = new WindowNavigation_Ext();
const summary =new Summary();

export class SearchPoliciesPage {
    constructor() {
        this.pageName = "Search Policies Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }
    async scrollToTop() {
        try {
            const target = Selector('#PolicySearch-PolicySearchScreen-DatabasePolicySearchPanelSet-PolicySearchDV-2');
            await t.wait(2000);
            const elementHeight = await target.clientHeight;
            const viewportHeight = await t.eval(() => window.innerHeight);
            const maxOffsetY = elementHeight - viewportHeight;
            await t
                .scrollIntoView(target, { offsetX: 0, offsetY: maxOffsetY })
                .expect(target.visible).ok();
            await t.wait(2000); 
        } catch (error) { }
        
    }
    async scrollToDown() {


        const target = Selector('l--9');
        await t.wait(2000);
        // const elementWidth = await target.clientWidth;
        // const viewportWidth = await t.eval(() => window.innerWidth);
        // const maxOffsetX = elementWidth - viewportWidth;
        await t
            .scrollIntoView(target, { offsetX: 0, offsetY: 0 })
            .expect(target.visible).ok();
        await t.wait(2000);
    }
    async ValidationOfPolicyNumOnSummeryScreen(fileobj, data, iteration) {
        this.stepAction = "Validate the Policy number on Policy summery screen"
        this.stepER = "Expected Policy number [" + data.searchPolicyBy[iteration].PolicyNumber + "] should be presence in the Summery screen"
        const confirmPolicyNum = await Selector('#PolicyFile-PolicyFileMenuInfoBar-PolicyNumber');


        const PolicyNum = await confirmPolicyNum.innerText;
        console.log("_______________" + PolicyNum);
        if (data.searchPolicyBy[iteration].PolicyNumber == PolicyNum) {
            this.stepAR = "Expected Policy number " + confirmPolicy + "presence in the Summery screen <br> ${this.pageName}"
            this.verdict = "Passed"
        } else {
            this.stepAR = `Expected Policy number not  presence in the Summery screen ${this.pageName}`
            this.verdict = "Failed"
        }
        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

    }

    async PolicysearchTab(fileobj, data, iteration) {

        switch (data.searchPolicyBy[iteration].identifier) {
            case "PL":
                await t.wait(2000);
                await this.scrollToTop();
                await this.searchPolicyFromPolicyTabScreen(fileobj, data, iteration);
                await this.ValidationOfPolicyNumOnSummeryScreen(fileobj, data, iteration)
                break;
            case "CL":
                await t.wait(2000);
                await this.scrollToTop();
                await this.searchPolicyFromPolicyTabScreen(fileobj, data, iteration);
                await this.ValidationOfPolicyNumOnSummeryScreen(fileobj, data, iteration)
                break;
        }
    }

    async unCheckFilterCheckbox() {
        await searchPoliciesScreen.searchPoliciesScreenFirstNameExact_checkbox.click();
        await t.wait(3000);
        await searchPoliciesScreen.searchPoliciesScreenLastNameExact_checkbox.click();
        await t.wait(3000);
        await searchPoliciesScreen.searchPoliciesScreenCompanyNameExact_checkbox.click();
        await t.wait(1000);
    }

    async resetButtonForSearchFilter(fileobj) {
        this.stepAction = "Click reset button"
        this.stepER = "Action Step, Verification N/A"
        this.stepAR = ""
        this.verdict = ""
        await searchPoliciesScreen.searchPoliciesScreenReset.click();
        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async searchPolicyFromPolicyTabScreen(fileobj, data, i) {
        this.stepAction = "Navigate into  Search policy tab "
        this.stepER = "Policy summery screen should display"
        await t.click(searchPoliciesScreen.searchPoliciestabbar.component.find('div.gw-action--expand-button'));
        await searchPoliciesScreen.searchPolicyRetrievalItem.setValue(data.searchPolicyBy[i].PolicyNumber);
        await policyTabBar.policyTabPolicyTab_PolicyRetrievalItemButton.click();
        this.verdict = "pass"
        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async navigateToSearchPolicyScreen(fileobj) {
        this.stepAction = `Navigate to Search > policy`
        this.stepER = "Action step, Verification N/A"
        this.stepAR = ""
        this.verdict = ""
        console.log(`Go to Search > Policy`)
        await t.click(searchTabBar.tabBarSearchTab.component.find("div.gw-action--expand-button"));
        await searchTabBar_Ext.searchTabSearch_PolicySearch.click();
        this.verdict = "Pass"
        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async enterSearchFields(fileobj, companyName, firstName, lastName, zipcode) {
        this.stepAction = "Enter below details and click on search button<br>";
        this.stepER = "Action Step, Verification N/A"
        this.stepAR = ""
        this.verdict = ""

        if (companyName !== '') {
            this.stepAction += "Company Name: " + companyName + ",<br>";
            console.log("Enter Company Name: " + companyName);
            await searchPoliciesScreen.accountSearchPolicySearchScreenPolicySearchDVGlobalContactNameInputSetName.setValue(companyName);
        } else {
            this.stepAction += "First Name: " + firstName + ",<br>";
            console.log("Enter First Name: " + firstName);
            await searchPoliciesScreen.searchPoliciesScreenFirstName.setValue(firstName);

            this.stepAction += "Last Name: " + lastName + ",<br>";
            console.log("Enter Last Name: " + lastName);
            await searchPoliciesScreen.searchPoliciesScreenLastName.setValue(lastName);
            this.stepAction += "Zipcode: " + zipcode + "<br>";
            console.log("Enter Zipcode: " + zipcode);
            await searchPoliciesScreen.searchPoliciesScreenZipCode.setValue(zipcode);
            await t.pressKey("tab");
            await t.wait(3000);
            await searchPoliciesScreen.searchPoliciesScreenSearchButton.click();
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        }
    }

    async verifyPolicyExists(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify if the Created policy is listed in Search policy Page"
        await t.wait(2000);
        let policyResult = await searchPoliciesScreen.searchPoliciesScreenpolicySearchResultsrow.rowCount();
        let policyNumber = await searchPoliciesScreen.searchPoliciesScreenPolicySearchResults.component.innerText;
        console.log("Search Result Count: " + policyResult);
        if (policyResult > 0) {
            this.stepAR = "As Expected, Created policy is listed - " + policyNumber
            this.verdict = "Passed"
        } else {
            this.stepAR = "Not As Expected, The Created policy is not listed"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }
    // async verifyAccountMenuAccountSearch(fileobj) {
    //     // PL account search
    //     await this.searchAccountUnderAccountMenu(fileobj, t.ctx.plAccountNumber, "PL");
    //     await this.verifyAccountSummaryDisplayed(fileobj)
    //     console.log("Verified PL type account search")
    //     // CL account search
    //     await this.searchAccountUnderAccountMenu(fileobj, t.ctx.clAccountNumber, "CL");
    //     await this.verifyAccountSummaryDisplayed(fileobj)
    //     console.log("Verified CL type account search")
    // }

    async searchPolicyUnderPolicyMenu(fileobj, policyNumber, policyType) {
        try {
            this.stepAction = "Go to Policy > Search and provide " + policyType + "  Policy number[" + policyNumber + "] and click on Search"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            await this.scrollToTop();
            await policyTabBar.tabBarPolicyTab_ExpandIcon.click();
            await searchPoliciesScreen.searchPolicyRetrievalItem.setValue(policyNumber);
            await policyTabBar.policyTabPolicyTab_PolicyRetrievalItemButton.click();
            await t.wait(5000)
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Policy Menu Search"
            this.verdict = "Failed"
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
    async verifyPolicySummaryDisplayed(fileobj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify if the Policy number searched displayed under Summary screen"
        if (await summary.PolicyNumberVeroficationOnPolicySummmery.component.visible) {
            this.stepAR = "Successfully verified the searched  Policy number [" + await summary.PolicyNumberVeroficationOnPolicySummmery.component.innerText + "] appears under the Summary screen"
            this.verdict = "Passed"
        } else {
            this.stepAR = `Searched Policy number failed to retrieve and display on screen`
            this.verdict = "Failed"
        }
        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

    }
    async verifyPolicyMenuPolicySearch(fileobj) {
        // PL account search
        await this.searchPolicyUnderPolicyMenu(fileobj, t.ctx.plPolicyNumber, "PL");
        await this.verifyPolicySummaryDisplayed(fileobj)
        console.log("Verified PL type Policy search")
        // CL account search
        await this.searchPolicyUnderPolicyMenu(fileobj, t.ctx.clPolicyNumber, "CL");
        await this.verifyPolicySummaryDisplayed(fileobj)
        console.log("Verified CL type Policy search")
    }
    async verifySearchPolicyPagePolicySearch(fileobj, data) {
        try {
            let plContactFirstName = data.P_FirstName;
            let plContactLastName = data.P_LastName;
            let zipCode = data.ZipCode;
            let clContactName = data.C_Name;

            // PL Policy search
            await this.navigateToSearchPolicyScreen(fileobj);
            await this.resetButtonForSearchFilter(fileobj);
            await this.unCheckFilterCheckbox(fileobj);
            await this.enterSearchFields(fileobj, '', plContactFirstName, plContactLastName, zipCode);

            this.stepAction = "Click Search button";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            await searchPoliciesScreen.searchPoliciesScreenSearchButton.click();
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            await this.verifyPolicyExists(fileobj);
            t.ctx.plPolicyNumber = await searchPoliciesScreen.searchPoliciesScreenPolicySearchResults.component.innerText;
            console.log("PL policy number: " + t.ctx.plPolicyNumber)

            // CL account search
            await this.scrollToTop();
            await this.navigateToSearchPolicyScreen(fileobj);
            await this.resetButtonForSearchFilter(fileobj);
            await this.unCheckFilterCheckbox(fileobj);
            await this.enterSearchFields(fileobj, clContactName, '', '', zipCode);

            this.stepAction = "Click Search button";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            await searchPoliciesScreen.searchPoliciesScreenSearchButton.click();
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            await this.verifyPolicyExists(fileobj);
            t.ctx.clPolicyNumber = await searchPoliciesScreen.searchPoliciesScreenPolicySearchResults.component.innerText;
            console.log("CL policy number: " + t.ctx.clPolicyNumber)

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Search Account"
            this.verdict = "Failed"
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async searchPolicyByAccountnumber(fileobj, data) {

        if (data.searchPolicyBy != "") {
            for (let i = 0; i < data.searchPolicyBy.length; i++) {
                console.log(`Verify Retrival of Policy detailes on Policy search window`)
                this.stepAction = "Verification Step , Action N/A "
                this.stepER = `To Verify  Policy results with help of Account number on ${this.pageName}`
                await this.resetButtonForSearchFilter(fileobj);
                await this.unCheckFilterCheckbox(fileobj);
                // await this.navigateToSearchPolicyScreen(fileobj);
                await searchPoliciesScreen.searchPoliciesScreenAdvancedTab.click();
                await t.wait(3000);
                await searchPoliciesScreen.searchPoliciesScreenAccountNumber.setValue(data.searchPolicyBy[i].AccountNumber);
                await t.wait(3000);
                await searchPoliciesScreen.searchPoliciesScreenSearchButton.click();

                const verifyPolicySearchAccountResults = await searchPoliciesScreen.searchPoliciesScreenAccountSearchResults.component.innerText;

                if (data.searchPolicyBy[i].AccountNumber == verifyPolicySearchAccountResults) {
                    this.stepAR = `Policy result are verified successfully with account number on ${this.pageName}`
                    this.verdict = "Passed"
                } else {
                    this.stepAR = `Policy result with account number  validation are Failed on  ${this.pageName}`
                    this.verdict = "Failed"
                }
                await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            }
        }
    }


    async checkPolicySearchResult(fileobj) {
        try {

            this.stepAction = "Verification step, Action N/A"
            this.stepER = "Verify the Policy search return results greater than zero"
            this.stepAR = ""
            this.verdict = ""

            let count = await searchPoliciesScreen.searchPoliciesScreenResults.count;
            count = count - 1;//excluding header
            console.log("Polices found: " + count);

            if (count > 0) {
                this.stepAR = "As Expected, " + count + " Polices were found"
                this.verdict = "Passed"
            }
            else {
                this.stepAR = "Not as Expected, No Polices were found"
                this.verdict = "Failed"
                captureScreenshot();
            }
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        }
        catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async confirmPageNavigation(fileobj) {
        this.stepAction = "Verification step, Action N/A"
        this.stepER = "Verify that you are taken to Search Policies Page"
        this.stepAR = ""
        this.verdict = ""
        if (await searchPoliciesScreen.searchPoliciesScreenTitleBar.component.visible) {
            this.stepAR = "Successfully navigated to Search Policies Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to Search Policies Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }
}
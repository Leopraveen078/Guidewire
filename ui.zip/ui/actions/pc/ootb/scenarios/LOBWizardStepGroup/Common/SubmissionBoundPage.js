'use strict';
import { t } from 'testcafe';
import { SubmissionBoundScreen } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/SubmissionBoundScreen";
import { JobWizardInfoBar } from "./JobWizardInfoBar";
import { Summary } from '../../../../../../pages/gw/generated/policycenter/pages/policy/Summary';
import { captureScreenshot } from "../../../../../../util/common/helper.js";


const submissionBoundScreen = new SubmissionBoundScreen();
const jobWizardInfoBar = new JobWizardInfoBar();
const summary = new Summary();
export class SubmissionBoundPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
        this.pageName = "Issuance Bound Page"
    }

    //To Confirm Page Navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        await submissionBoundScreen.submissionBoundScreenTitleBar.visible
        if (await submissionBoundScreen.submissionBoundScreenTitleBar.exists) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the  ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    //To view policy details and capture in submission bound page
    async viewPolicyDetails(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);
            await jobWizardInfoBar.assertSubmissionState(fileObj, "Issuance (Issued)");
            t.ctx.policyNumber = await this.assertPolicyNumberGenerated(fileObj);
            this.stepAction = `Click the View your policy link from ${this.pageName}`
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Clicking on View your policy ...`)
            await submissionBoundScreen.submissionBoundScreenViewPolicy.click();
            await t.wait(3000);

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            //Store Policy Number
            t.ctx.policyNumber = await summary.policyDetailsDetailViewTile_DVPolicyNumber.innerText;

            console.log("Stored Policy number:", t.ctx.policyNumber);

            // Verify the Policy number is not null or undefined
            await t.expect(t.ctx.policyNumber).notEql(null, 'Policy Number should not be null');
            await t.expect(t.ctx.policyNumber).notEql(undefined, 'Policy Number should not be undefined');
            console.log("Policy Number successfully stored and verified.");
            this.stepAction = "Verification Step, Action N/A"
            this.stepER = `Verify that policy has been issued successfully`
            this.stepAR = "Successfully created the Policy - " + t.ctx.policyNumber;
            this.verdict = "Passed"

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    //To fetch policy number
    async capturePolicyNumber(fileObj, policyDetails) {
        try {
            await this.confirmPageNavigation(fileObj)
            this.stepAction = "Capture policy from " + this.pageName;
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Capture policy ...`)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            policyDetails.policyNumber = await this.assertPolicyNumberGenerated(fileObj)
            return policyDetails
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    //To verify that the policy number is generated
    async assertPolicyNumberGenerated(fileObj) {
        this.stepAction = `Verification Step. Action N/A`
        this.stepER = "Verify the Policy Number is generated"
        this.stepAR = ""
        this.verdict = ""
        let policyNumber = ""
        await submissionBoundScreen.submissionBoundScreenPolicyNumber.component.visible
        if (await submissionBoundScreen.submissionBoundScreenPolicyNumber.component.exists) {
            policyNumber = await submissionBoundScreen.submissionBoundScreenPolicyNumber.component.innerText
            console.log(`Capturing Policy Number:${policyNumber}`)
            this.stepAR = `AS EXPECTED,Policy Number - ${policyNumber} is generated successfully.`
            this.verdict = "Passed"
        } else {
            console.log(`NOT AS EXPECTED, Policy is NOT generated successfully.`)
            this.stepAR = `NOT AS EXPECTED, Policy is NOT generated successfully.`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        await fileObj.setPolicyNumber(policyNumber)
        return policyNumber
    }

    async assertSubmissionBound(fileObj) {
        await this.confirmPageNavigation(fileObj)
        await jobWizardInfoBar.assertSubmissionState(fileObj, "Submission (Bound)")
    }
}

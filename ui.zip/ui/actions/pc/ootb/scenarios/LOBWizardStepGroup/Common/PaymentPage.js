import { t } from 'testcafe';
import { WindowNavigation_Ext } from '../../../../../gw/WindowNavigation_Ext.js';
import { AccountTabBar_Ext } from '../../../../../../pages/gw/ScenarioPages/Navigation/AccountTabBar_Ext.js';
import { PaymentScreen } from '../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/PaymentsScreen';
import { UWBlockProgressIssuesPopup_Ext } from "../../PopUp/UWBlockProgressIssuesPopup_Ext";
import { RiskAnalysisScreen } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/RiskAnalysisScreen";
import { RiskApprovalDetailsPopup } from "../../../../../../pages/gw/generated/policycenter/pages/popup/Risk/RiskApprovalDetailsPopup";
import { RiskAnalysisPage } from "./RiskAnalysisPage";
import { TabBarScenarios } from "../../Navigation/TabBarScenarios";
import { SubmissionWizard } from "../../Navigation/SubmissionWizard";
import { PolicyReviewPage } from "./PolicyReviewPage";
import { onApp } from "../../../../../../pages/gw/registry/onApp";
import { setStepDescription } from "../../../../../../util/common/setStepDescription.js";
import { NextSubmissionWizard } from '../../../../../../pages/gw/generated/policycenter/pages/navigation/submissionWizard/NextSubmissionWizard.js';
import { PolicyMenuLinks } from '../../../../../../pages/gw/generated/policycenter/pages/navigation/menuLinks/PolicyMenuLinks.js';
import { Billing } from '../../../../../../pages/gw/generated/policycenter/pages/policy/Billing.js';
import { selectDropdown, captureScreenshot } from '../../../../../../util/common/helper.js';

const pageNameStaticContent = require('../../../../../../util/common/pageNameStaticContent.js');
const otherConstants = require('../../../../../../util/common/otherConstantsFile.js');
const stepDescription = new setStepDescription();
const paymentsScreen = new PaymentScreen();
const uwBlockProgressIssuesPopup = new UWBlockProgressIssuesPopup_Ext();
const riskAnalysisScreen = new RiskAnalysisScreen();
const riskAnalysisPage = new RiskAnalysisPage();
const riskApprovalDetailsPopup = new RiskApprovalDetailsPopup();
const tabBarScenarios = new TabBarScenarios();
const submissionWizard = new SubmissionWizard();
const policyReviewPage = new PolicyReviewPage();
const onPCApp = new onApp("PC");
let logoutFlag = '';
let releaseLockRequestFlag = '';
let submissionNumber = '';
const nextSubmissionWizard = new NextSubmissionWizard();
const policyMenuLinks = new PolicyMenuLinks();
const billing = new Billing();
const accountTabBar_Ext = new AccountTabBar_Ext();
const windowNavigation_Ext = new WindowNavigation_Ext();

export class PaymentPage {
    constructor() {
        this.pageName = "Payment Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async enterDetailsAndIssuePolicy(fileObj, data) {
        try {

            await this.verifyDefaultPaymentDetails(fileObj, data);
            //await this.enterPaymentDetails(fileObj, data);
            await this.clickIssuePolicy(fileObj);
            await this.checkForUWIssuesAndApprove(fileObj, data)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.PAYMENT_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async issuePolicyOld(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj);
            await this.clickIssuePolicy(fileObj);
            await this.checkObjectChangedByAnotherUserError(fileObj);
            await this.checkForUWIssuesAndApprove(fileObj)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.PAYMENT_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async issuePolicy(fileObj) {
        try {
            this.stepAction = "Verification Step, Action N/A"
            this.stepER = "Verify that downpayment paid is reflecting on PC"

            await this.verifyPaidAmount(fileObj, t.ctx.accountNumber, t.ctx.amount);

            this.stepAR = "Successfully verified the downpayment paid reflecting on PC"
            this.verdict = "Passed"

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            console.log("seaching the account on PC - " + t.ctx.accountNumber);
            await accountTabBar_Ext.accountTabAccountTab_ExpandIcon.click();
            await accountTabBar_Ext.accountTabAccountTab_AccountNumberSearchItem_ext.setValue(t.ctx.accountNumber);
            await accountTabBar_Ext.tabBarAccountTab_AccountNumberSearchItem_Button.click();

            this.stepAction = "Clicking on Issue options > Approve Submission";
            this.stepER = "Action Step, Verification N/A";

            await paymentsScreen.transactionHyperLink.click();

            await paymentsScreen.issueOption.click();
            await paymentsScreen.approveSubmission.click();

            //handle confirmation pop up 
            await t.setNativeDialogHandler(() => true);
            await t.wait(10000);

            this.stepAR = "Successfully clicked on 'Approve Submission' for policy issuance"
            this.verdict = "Passed"
            
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Issuance page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async verifyPaidAmount(fileObj, accountNumber, amount) {
        try {
            this.stepAction = "Verification Step, Action N/A";
            this.stepER = "Verify the paid down payment invoice under PC";
            const totalBilledAmount = amount;
            await accountTabBar_Ext.accountTabAccountTab_ExpandIcon.click();
            await accountTabBar_Ext.accountTabAccountTab_AccountNumberSearchItem_ext.setValue(accountNumber);
            await accountTabBar_Ext.tabBarAccountTab_AccountNumberSearchItem_Button.click();

            await paymentsScreen.accountSummaryPage_Term1_Policy.click();

            //click billing tab option 
            await policyMenuLinks.menuLinksPolicyFile_PolicyFile_Billing.click();
            //click verify the paid amount
            const billPaidAmount = await billing.policy_BillingScreenPaid.component.innerText;

            await t.expect(totalBilledAmount).eql(billPaidAmount, 'Total paid amount should equal billPaidAmount');
            this.stepER = "Successfully verified the paid down payment invoice under PC ";
            this.stepER = "Passed";

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in PC Account summary - payment details"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async enterOldPaymentDetails(fileObj, data) {
        this.stepAction = stepDescription.resetActionStep()
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
        this.stepAR = stepDescription.resetActualResultStep()
        this.verdict = stepDescription.resetVerdictStep()
        if ((data.billingLevelOption !== "") && (data.hasOwnProperty('billingLevelOption'))) {
            this.stepAction = `Select Billing Level as: ${data.billingLevelOption}, `
            await paymentsScreen.paymentPageBillingLevelDropdown.selectOptionByLabel(data.billingLevelOption);
        }
        if ((data.billingMethodOption !== "") && (data.hasOwnProperty('billingMethodOption'))) {
            this.stepAction = `${this.stepAction}Select Billing Method as: ${data.billingMethodOption}, `
            await paymentsScreen.paymentPageBillingMethodDropdown.selectOptionByLabel(data.billingMethodOption);
        }
        if ((data.otherBillingContact != '') && (data.hasOwnProperty('otherBillingContact'))) {
            this.stepAction = `${this.stepAction}Select Billing Contact as: ${data.otherBillingContact}, `
            await paymentsScreen.paymentScreenBillingContactArrowButton.click();
            await paymentsScreen.paymentPageBillingContactOtherContacts.click();
            await t.click(paymentsScreen.paymentPageBillingContactUnassignedContact.withText(data.otherBillingContact));
            await t.wait(2000);
        }
        if ((data.payerType != '') && (data.hasOwnProperty('payerType'))) {
            this.stepAction = `${this.stepAction}Select Payer Type as: ${data.payerType}`
            await paymentsScreen.paymentPagePayerTypeDropdown.selectOptionByLabel(data.payerType);
        }
        if ((data.selectPaymentPlanOption !== "") && (data.hasOwnProperty('selectPaymentPlanOption'))) {
            this.stepAction = `${this.stepAction}, Select Payment Plan as: ${data.selectPaymentPlanOption}`
            await t.click(paymentsScreen.paymentPagePaymentPlanTableRow.withText(data.selectPaymentPlanOption).find('div[role="radio"]'));
        }

        // update html if there is any details entered from above step actions.
        if (this.stepAction != "") {
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        }
    }

    async enterPaymentDetails(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);
            this.stepAction = "Enter Payment details as follows:<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Entering Payment Page...`)

            console.log(`Is this policy premium financed?: ${data.PMT_PolicyPremiumFinanced_YN}`);
            this.stepAction += "'Is this policy premium financed?: " + data.PMT_PolicyPremiumFinanced_YN + "', <br>";
            if ((data.PolicyPremiumFinanced_YN != "") && (data.hasOwnProperty('PMT_PolicyPremiumFinanced_YN'))) {
                if (data.PMT_PolicyPremiumFinanced_YN.includes('Yes')) {
                    await paymentsScreen.paymentPagePolicyPremiumFinanced_YesButton.click();
                } else if (data.PMT_PolicyPremiumFinanced_YN.includes('No')) {
                    await paymentsScreen.paymentPagePolicyPremiumFinanced_NoButton.click();
                }
            }

            console.log(`Billing Method: ${data.PMT_BillingMethod}`);
            this.stepAction += "'Billing Method: " + data.PMT_BillingMethod + "', <br>";
            await selectDropdown(paymentsScreen.paymentPageBillingMethod_Selector, data.PMT_BillingMethod);

            console.log(`Payment Plan: ${data.PMT_Installment}`);
            this.stepAction += "'Payment Plan: " + data.PMT_Installment + "', <br>";
            if ((data.PMT_Installment != "") && (data.hasOwnProperty('PMT_Installment'))) {
                if (data.PMT_Installment.includes('Full')) {
                    await paymentsScreen.paymentPageCitizensFullPay.click();
                } else if (data.PMT_Installment.includes('Semi Annual')) {
                    await paymentsScreen.paymentPageCitizensSemiAnnualPay.click();
                } else if (data.PMT_Installment.includes('Quarterly')) {
                    await paymentsScreen.paymentPageCitizensQuarterlyPay.click();
                }
            }

            console.log(`Click 'Request Approval' Button`);
            this.stepAction += "Clicking 'Request Approval' button<br>";
            await paymentsScreen.paymentPageRequestApproval.click();
            t.wait(10000);

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = stepDescription.setActionStep(otherConstants.VERIFICATION_STEP)
        this.stepER = stepDescription.setExpResultStep(`${otherConstants.VERIFY_PAGE_NAVIGATION} ${pageNameStaticContent.PAYMENT_PAGE}`)
        if (await paymentsScreen.paymentPageTitle.component.visible) {
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.PAGE_NAVIGATION_PASS} ${pageNameStaticContent.PAYMENT_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
        } else {
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.PAGE_NAVIGATION_FAIL} ${pageNameStaticContent.PAYMENT_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async verifyDefaultPaymentDetails(data) {
        if ((data.verifyBillingMethod != '') && (data.hasOwnProperty('verifyBillingMethod'))) {
            this.stepAction = stepDescription.setActionStep(otherConstants.VERIFICATION_STEP)
            this.stepER = 'Verify the default value displayed in Billing Method dropdown'
            if ((await paymentsScreen.paymentPageBillingMethodDropdown.getSelectedOptionLabel()) == data.verifyBillingMethod) {
                this.stepAR = `AS EXPECTED, Billing Method is displayed as: '${data.verifyBillingMethod}' in ${pageNameStaticContent.PAYMENT_PAGE}`
                this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
            } else {
                this.stepAR = `NOT AS EXPECTED, Billing Method is not displayed as: '${data.verifyBillingMethod}' in ${pageNameStaticContent.PAYMENT_PAGE}`
                this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

        }
    }

    async clickIssuePolicy(fileObj) {
        this.stepAction = stepDescription.resetActionStep()
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
        this.stepAR = stepDescription.resetActualResultStep()
        this.verdict = stepDescription.resetVerdictStep()
        if (await paymentsScreen.paymentPageBindOptions.component.exists) {
            this.stepAction = "Click Bind Options Menu"
            console.log(`Clicking on Bind Options > Issue Policy ...`)
            await paymentsScreen.paymentPageBindOptions.click();
            if (await paymentsScreen.paymentPageIssuePolicy.component.exists) {
                this.stepAction = this.stepAction + " > Issue Policy"
                await paymentsScreen.paymentPageIssuePolicy.click();
            } else if (await paymentsScreen.paymentPageIssueNowButton.component.exists) {
                this.stepAction = this.stepAction + " > Issue Now Policy"
                await paymentsScreen.paymentPageIssueNowButton.click();
            }
        } else if (await paymentsScreen.paymentPageIssueRewrite.component.exists) {
            this.stepAction = stepDescription.setActionStep(otherConstants.CLICK_ISSUE_POLICY)
            console.log(`Clicking on Issue Policy ...`)
            await paymentsScreen.paymentPageIssueRewrite.click();
        } else if (await paymentsScreen.paymentScreenPolicyChangeIssueButton.component.exists) {
            this.stepAction = stepDescription.setActionStep(otherConstants.CLICK_ISSUE_POLICY)
            console.log(`Clicking on Issue Policy ...`)
            await paymentsScreen.paymentScreenPolicyChangeIssueButton.click();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async bindOnly(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj)
            await this.clickBind(fileObj);
            if (await uwBlockProgressIssuesPopup.UWBlockProgressIssuesPopupUnderwriterIssuesTitle.component.visible) {
                console.log(`Issues that block Issuance Header displayed`)
                this.stepAction = 'Checking details for Issues that block Issuance';
                this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
                this.stepAR = stepDescription.resetActualResultStep()
                this.verdict = stepDescription.resetVerdictStep()
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
                await this.approveUWIssues(fileObj, data)
                await this.clickBind(fileObj);
            }
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.PAYMENT_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async clickBind(fileObj) {
        this.stepAction = "Click Bind Options Menu > Bind Only"
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
        this.stepAR = stepDescription.resetActualResultStep()
        this.verdict = stepDescription.resetVerdictStep()
        console.log(`Clicking on Bind Options > Bind Only Policy ...`)
        await paymentsScreen.paymentPageBindOptions.click();
        await paymentsScreen.paymentPageBindOnly.click();
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async approveUWIssues(fileObj, data) {
        try {
            if (await uwBlockProgressIssuesPopup.issuesScreenDetailsButton.component.exists) {
                this.stepAction = "Click the Issues Details Button to view UW issues";
                this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
                this.stepAR = stepDescription.resetActualResultStep()
                this.verdict = stepDescription.resetVerdictStep()
                console.log(`Clicking on Issues Details Button ...`)
                await uwBlockProgressIssuesPopup.issuesScreenDetailsButton.click();
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
                await riskAnalysisPage.confirmPageNavigation(fileObj);
            }
            if (await riskAnalysisScreen.riskAnalysisScreenUWIssueRowSetApproveButton.component.withAttribute('aria-disabled', 'true').exists) {
                await policyReviewPage.requestApproval(fileObj)
                releaseLockRequestFlag = "Yes";
                submissionNumber = await submissionWizard.getSubmissionNumber(fileObj)
                await onPCApp.logout();
                await onPCApp.loginWithUser("su", "gw");
                await tabBarScenarios.searchBySubmissionNumber(fileObj, submissionNumber);
                await submissionWizard.navigateToRiskAnalysisPage(fileObj);
                logoutFlag = "Yes";
            }
            if (await riskAnalysisScreen.riskAnalysisScreenUWIssueRowSetApproveButton.component.exists) {
                let issueButtonCount = await riskAnalysisScreen.riskAnalysisScreenUWIssueRowSetApproveButton.component.count
                for (let count = 0; count < issueButtonCount; count++) {
                    console.log(`Clicking on Approve Button ...`);
                    await riskAnalysisScreen.riskAnalysisScreenUWIssueRowSetApproveButton.click();
                    await riskAnalysisScreen.riskAnalysisScreenRiskApprovalDetailsTitle.component.visible
                    let uwIssueDescription = await riskAnalysisScreen.riskAnalysisApprovalScreenIssueDescriptionText.component.innerText
                    console.log(`Approving UW Issue: "${uwIssueDescription}"`);
                    this.stepAction = `For the UW Issue: "${uwIssueDescription}", Click the Approve > OK`;
                    this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
                    this.stepAR = stepDescription.resetActualResultStep()
                    this.verdict = stepDescription.resetVerdictStep()
                    await riskApprovalDetailsPopup.riskApprovalDetailsPopupUpdate.click();
                    await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
                }
                if (releaseLockRequestFlag === 'Yes') {
                    await policyReviewPage.releaseLock(fileObj);
                }
                if (logoutFlag === 'Yes') {
                    await onPCApp.logout();
                    let user = onPCApp.getUserForRole(data.role);
                    // Using this method instead of loginWithRole due to an issue were user does not login when used multiple times
                    await onPCApp.loginWithUser(user.username, user.password);
                    await tabBarScenarios.searchBySubmissionNumber(fileObj, submissionNumber);
                }
            }
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.PAYMENT_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw (err)
        }
    }

    async checkForUWIssuesAndApprove(fileObj, data = '') {
        if (await uwBlockProgressIssuesPopup.UWBlockProgressIssuesPopupUnderwriterIssuesTitle.component.visible) {
            console.log(`Issues that block Issuance Header displayed`)
            this.stepAction = "Checking details for Issues that block Issuance";
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            await this.approveUWIssues(fileObj, data);

            await this.clickIssuePolicy(fileObj);
        }
    }

    async clickReinstate(fileObj) {
        try {
            this.stepAction = 'Click Reinstate button in Payment Page'
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log(`Clicking on Reinstate button ...`)
            await paymentsScreen.paymentScreenReinstateButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.PAYMENT_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async checkObjectChangedByAnotherUserError(fileObj) {
        try {
            console.log(`Discard Unsaved Changes visible: ${await paymentsScreen.paymentScreenDiscardUnsavedChanges.visible}`)
            if (await paymentsScreen.paymentScreenDiscardUnsavedChanges.visible) {
                this.stepAction = `Checking if the 'The Object you are trying to update was changed by another user`
                this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
                this.stepAR = stepDescription.resetActualResultStep()
                this.verdict = stepDescription.resetVerdictStep()
                console.log(`Clicking on Discard Unsaved Changes...`)
                await t.click(paymentsScreen.paymentScreenDiscardUnsavedChanges)
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            }
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.PAYMENT_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}

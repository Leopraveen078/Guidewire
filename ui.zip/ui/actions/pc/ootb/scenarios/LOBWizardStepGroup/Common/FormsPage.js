import { NewFormsScreen } from '../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/NewFormsScreen';

const newFormsScreen = new NewFormsScreen()

export class FormsPage {
    constructor() {
        this.pageName = "Forms Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    //To Click next button in forms page
    async clickNextInFormsPage(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj);
            this.stepAction = "Click the Next button from " + this.pageName;
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Clicking on Next button ...`)
            await newFormsScreen.newFormsScreenNextButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    //To confirm page navigation
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the Forms Page"
        await newFormsScreen.newFormsScreenTitleBar.component.visible
        if (await newFormsScreen.newFormsScreenTitleBar.component.exists) {
            this.stepAR = "Successfully navigated to the Forms Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the Forms Page"
            this.verdict = "Failed"
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

}
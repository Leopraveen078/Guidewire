import { EditPolicyContactRolePopup } from "../../../../../../pages/gw/generated/policycenter/pages/popup/Edit/EditPolicyContactRolePopup.js";
import { PolicyInfoScreen_Ext } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/PolicyInfoScreen_Ext.js";
import { dateConversion, getTodayDateValue, selectDropdown, captureScreenshot } from "../../../../../../util/common/helper";
import { t } from "testcafe";
import { setStepDescription } from "../../../../../../util/common/setStepDescription";
import { SidePanel } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/SidePanel.js";
import { NewSubmission } from "../../../../../../pages/gw/generated/policycenter/pages/policy/NewSubmission";

const newSubmission = new NewSubmission();
const pageNameStaticContent = require('../../../../../../util/common/pageNameStaticContent.js');
const otherConstants = require('../../../../../../util/common/otherConstantsFile.js')
const editPolicyContactRolePopup = new EditPolicyContactRolePopup();
const policyInfoScreen = new PolicyInfoScreen_Ext();
const sidePanel = new SidePanel();
const stepDescription = new setStepDescription();

export class PolicyInfoPage {
    constructor() {
        this.pageName = "Policy Info Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async enterPolicyInfoDetails(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            this.stepAction = "Enter Policy Info Details as follows:<br>";
            this.stepER = "Action Step, Verification N/A";
            this.stepAR = "";
            this.verdict = "";

            console.log(`DOB: ${data.POL_Insured_DOB}`);
            this.stepAction += "'DOB: " + data.POL_Insured_DOB + "', <br>";
            await policyInfoScreen.accountInfoInputSetDOB.setValue(data.POL_Insured_DOB);

            console.log(`SSN: ${data.P_SSN}`);
            this.stepAction += "'SSN: " + data.P_SSN + "', <br>";
            await policyInfoScreen.accountInfoInputSetSSN.setValue(data.P_SSN);

            console.log(`Occupation: ${data.POL_Occupation}`);
            this.stepAction += "'Occupation: " + data.POL_Occupation + "', <br>";
            await policyInfoScreen.accountInfoInputSetOccupation.setValue(data.POL_Occupation);
            await t.pressKey('tab');

            await t.click(policyInfoScreen.policyInfoInputSetEffDateExt_Selector);
            await t.pressKey('ctrl+a');
            await t.pressKey('delete');
            
            console.log(`EffectiveDate: ${data.POL_EffectiveDate}`);
            let generatedEffDate = await dateConversion(data.POL_EffectiveDate, '')
            console.log('generated effective date - ' + generatedEffDate)
            this.stepAction += "'EffectiveDate: " + generatedEffDate + "', <br>";
            t.ctx.policyEffectiveDate = generatedEffDate;
            await policyInfoScreen.policyInfoInputSetEffDateExt.setValue(generatedEffDate);
            await t.pressKey('tab');

            let generatedOrgEffDate = generatedEffDate;
            console.log('generated original effective date - ' + generatedOrgEffDate)
            this.stepAction += "'Original EffectiveDate: " + generatedOrgEffDate + "', <br>";
            await policyInfoScreen.policyInfoInputSetOriginalPolicyEffDateExt.setValue(generatedOrgEffDate);
            await t.pressKey('tab');

            console.log(`PurchsdLeasedDate: ${data.POL_PurchsdLeasedDate}`);
            let generatedPurcDate = await dateConversion(data.POL_PurchsdLeasedDate, '')
            console.log('generated purchased date - ' + generatedPurcDate)
            this.stepAction += "'PurchsdLeasedDate: " + generatedPurcDate + "', <br>";
            await policyInfoScreen.policyInfoInputSetHOReasonPurchLeaseDateExt.setValue(generatedPurcDate);
            await t.pressKey('tab');

            console.log(`Has the applicant had any losses, whether or not paid by insurance?: ${data.POL_HasApplcntLosesNotPadInsurnc}`);
            this.stepAction += "'Has the applicant had any losses, whether or not paid by insurance?: " + data.POL_HasApplcntLosesNotPadInsurnc + "', <br>";
            await selectDropdown(policyInfoScreen.policyInfoInputSetPolicyPriorLoses_Selector, data.POL_HasApplcntLosesNotPadInsurnc);

            console.log(`Paperless Opt-In: Yes`);
            this.stepAction += "'Paperless Opt-In: Yes<br>";
            await policyInfoScreen.ePDDFlagDVUserConsentQuestion.click();

            console.log(`I have informed the applicant that a loss history report, which is a consumer credit report: Yes`);
            this.stepAction += "'I have informed the applicant that a loss history report, which is a consumer credit report: Yes<br>";
            await policyInfoScreen.hORequestLHRConfirmQuestionPanelSetUserConsentQuestionYes.click();

            console.log(`Have you had Multiperil Insurance on this property from an authorized insurer in the last 12 months?: ${data.POL_PriorPol_HavUHadMultiPerilInsurncFromAuthoInsurer}`);
            this.stepAction += "'Have you had Multiperil Insurance on this property from an authorized insurer in the last 12 months?: " + data.POL_PriorPol_HavUHadMultiPerilInsurncFromAuthoInsurer + "', <br>";
            await selectDropdown(policyInfoScreen.pCFUpgradeNCWNLT122Multiperil_Selector, data.POL_PriorPol_HavUHadMultiPerilInsurncFromAuthoInsurer);

            console.log(`Have you ever had previous coverage with Citizens that has been declined, cancelled or non-renewed?: ${data.POL_PriorPol_PrevCovWithCitizenDeclCanclNonRenwd}`);
            this.stepAction += "'Have you ever had previous coverage with Citizens that has been declined, cancelled or non-renewed?: " + data.POL_PriorPol_PrevCovWithCitizenDeclCanclNonRenwd + "', <br>";
            await selectDropdown(policyInfoScreen.pCFUpgradeNCWNLT122Citizens_Selector, data.POL_PriorPol_PrevCovWithCitizenDeclCanclNonRenwd);

            console.log(`Have you had Wind Insurance on this property?: ${data.POL_PriorPol_HavUHadWindInsurncOnThisProp}`);
            this.stepAction += "'Have you had Wind Insurance on this property?: " + data.POL_PriorPol_HavUHadWindInsurncOnThisProp + "', <br>";
            await selectDropdown(policyInfoScreen.pCFUpgradeNCWNLT122Wind_Selector, data.POL_PriorPol_HavUHadWindInsurncOnThisProp);

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = "";
            this.stepER = "";
            this.stepAR = "Error in " + this.pageName;
            this.verdict = "Failed";
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }

    async clickNextAndUpdateHtml(fileObj) {
        this.stepAction = `${otherConstants.CLICK_NEXT_BUTTON} ${pageNameStaticContent.POLICY_INFO_PAGE}`
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
        this.stepAR = stepDescription.resetActualResultStep()
        this.verdict = stepDescription.resetVerdictStep()
        console.log(`Clicking on Next Button ...`)
        await t.wait(3000)
        await policyInfoScreen.policyInfoNextButton.click();
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the Policy Info Page"
        if ((await policyInfoScreen.policyInfoPageTitle.component.visible)) {
            this.stepAR = "Successfully navigated to the Policy Info Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the Policy Info Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        await this.captureSubmissionNumber(fileObj);
    }

    async clickNextInPolicyInfoPage(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj);
            await this.clickNextAndUpdateHtml(fileObj);
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_INFO_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async assertValuesAndUpdateHTML(fileObj, fieldName, valueFromUI, valueToBeChecked) {
        if (valueFromUI == valueToBeChecked) {
            console.log("AS EXPECTED, '" + fieldName + "' is matched with the expected: " + valueFromUI);
            this.stepAR = `AS EXPECTED, '${fieldName}' is matched with the expected: ${valueFromUI}`
            this.verdict = "Passed"
        } else {
            console.log("NOT AS EXPECTED, '" + fieldName + "' is NOT matching with the expected: " + valueFromUI);
            this.stepAR = `NOT AS EXPECTED,'${fieldName}' is NOT matching with the expected:  ${valueFromUI}`
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async captureSubmissionNumber(fileObj) {
        try {
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log('Capturing Submission Number...')
            const submissionNumber = (await sidePanel.transactionWizardWestSidePanelTitle.innerText).replace("Submission ", "").replace("\nQuoted", "");
            this.stepAction = `Captured the Submission Number: '${submissionNumber}'`
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            await fileObj.setSubmissionNumber(submissionNumber);
            return submissionNumber
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_INFO_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}

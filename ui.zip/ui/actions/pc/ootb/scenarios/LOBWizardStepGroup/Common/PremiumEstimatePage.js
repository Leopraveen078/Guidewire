import { t } from "testcafe";
import { Homeowners } from "../../../../../../pages/gw/generated/policycenter/pages/lOBWizardStepGroup/Homeowners.js";
import { NextSubmissionWizard } from "../../../../../../pages/gw/generated/policycenter/pages/navigation/submissionWizard/NextSubmissionWizard.js";
import { captureScreenshot } from "../../../../../../util/common/helper.js";
import { RiskAnalysisPage } from "./RiskAnalysisPage.js"

const homeOwner = new Homeowners();
const nextSubmissionWizard = new NextSubmissionWizard();
const riskAnalysisPage = new RiskAnalysisPage();


export class PremiumEstimatePage {
    constructor() {
        this.pageName = "Premium Estimate Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await homeOwner.premiumEstimateScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async enterPremiumEstimateDetails(fileObj, data) {
        try {
            this.stepAction = "Clicking 'Premium Estimate' button"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            console.log(`Clicking 'Premium Estimate' button..`)

            await homeOwner.hoPremiumEstimate.click()
            await t.wait(5000);

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            await riskAnalysisPage.clearUWIssues(fileObj)

            await this.confirmPageNavigation(fileObj);
            
            this.stepAction = "Verification Step, Action N/A"
            this.stepER = "Verify that you are able to do Premium Estimate"
            this.stepAR = "Successfully Premium estimated"
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

            await nextSubmissionWizard.submissionWizardNext.click();

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
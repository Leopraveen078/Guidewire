import { RiskAnalysisScreen } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/RiskAnalysisScreen.js";
import { UWBlockProgressIssuesPopup_Ext } from "../../PopUp/UWBlockProgressIssuesPopup_Ext.js";
import { RiskApprovalDetailsPopup } from "../../../../../../pages/gw/generated/policycenter/pages/popup/Risk/RiskApprovalDetailsPopup.js";
import { captureScreenshot } from "../../../../../../util/common/helper.js";
import { Selector, t } from "testcafe";
import { RiskAnalysisSubmissionWizard } from "../../../../../../pages/gw/generated/policycenter/pages/navigation/submissionWizard/RiskAnalysisSubmissionWizard.js";

const riskAnalysisSubmissionWizard = new RiskAnalysisSubmissionWizard();
const riskAnalysisScreen = new RiskAnalysisScreen();
const uwBlockProgressIssuesPopup_Ext = new UWBlockProgressIssuesPopup_Ext();
const riskApprovalDetailsPopup = new RiskApprovalDetailsPopup();

export class RiskAnalysisPage {
    constructor() {
        this.stepAction = ""
        this.pageName = "Risk Analysis"
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    //To confirm page navigation to Risk Analysis page
    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await riskAnalysisScreen.submissionWizard_RiskAnalysisScreen.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            await captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async clearUWIssues(fileObj) {
        try {
            await t.wait(5000);

            if (await uwBlockProgressIssuesPopup_Ext.UWBlockProgressIssuesPopupUnderwriterIssuesTitle.component.visible) {

                await riskAnalysisSubmissionWizard.submissionWizardRiskAnalysis.click();

                await this.confirmPageNavigation(fileObj);

                console.log('UW issues triggered, calling UWissueApproveItems...');
                this.stepAction = "Clear UW issues triggered";
                this.stepER = "Action step, Verification N/A";
                this.stepAR = "";
                this.verdict = ""

                await captureScreenshot();
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

                await this.UWissueApproveItems(fileObj);
                if(await riskAnalysisScreen.riskAnalysisScreenQuoteButton.component.visible)
                    await riskAnalysisScreen.riskAnalysisScreenQuoteButton.click()
                await t.wait(5000);

            } else {
                console.log('No UW issues triggered');
            }

        } catch (err) {
            this.stepAction = "";
            this.stepER = "";
            this.stepAR = "Error in " + this.pageName;
            this.verdict = "Failed";
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }

    async UWissueApproveItems(fileObj) {
        try {
            // Define the selector for the specific panel in UW issue screen
            const listView = riskAnalysisSubmissionWizard.riskAnalysisCVRiskEvaluationPanelSet_listItems;

            // Get row count 
            const rowCount = await listView.rowCount();
            console.log(`Total UW issues count: ${rowCount - 1}`);

            // Handle "Approve" type - UW issues
            let uwIssueApproveExist = false;

            // select the checkbox requesting UW approval
            for (let rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                const row = await listView.getContentRow(rowIndex);
                const approveButton = row.find('tr.gw-RowWidget.gw-styleTag--ListViewWidget.gw-row.gw-standard-row div[role="button"]').withText('Approve');
                if (await approveButton.exists) {
                    // skipping not applicable uw rows
                    const ariaDisabled = await approveButton.getAttribute('aria-disabled');
                    if (ariaDisabled === 'true') {
                        console.log(`Approve button on row ${rowIndex} is disabled, thus skipping selection`);
                        continue;
                    } else {
                        const checkbox = row.find('tr.gw-RowWidget.gw-styleTag--ListViewWidget.gw-row.gw-standard-row div[role="checkbox"]');
                        await t.click(checkbox);
                        uwIssueApproveExist = true;
                        console.log(`UW issue on row-${rowIndex} is selected`);
                    }
                }
            }

            // providing approval for selected UW issues
            if (uwIssueApproveExist) {
                await riskAnalysisSubmissionWizard.riskAnalysisCVRiskEvaluationPanelSetApprove.click();
                await t.setNativeDialogHandler(() => true);
                await riskApprovalDetailsPopup.riskApprovalDetailsPopupUpdate.click();
                await t.setNativeDialogHandler(() => true);
            }

            // Handle "Special Approve" type - UW issues
            for (let rowIndex = 0; rowIndex < rowCount; rowIndex++) {
                const row = await listView.getContentRow(rowIndex);
                const specialApproveButton = row.find('tr.gw-RowWidget.gw-styleTag--ListViewWidget.gw-row.gw-standard-row div[role="button"]').withText('Special Approve');
                if (await specialApproveButton.exists) {
                    await t.click(specialApproveButton);
                    await t.setNativeDialogHandler(() => true);
                    await riskApprovalDetailsPopup.riskApprovalDetailsPopupUpdate.click();
                    await t.setNativeDialogHandler(() => true);
                }
            }

        } catch (err) {
            this.stepAction = "";
            this.stepER = "";
            this.stepAR = "Error on Risk Analysis - UW approvals";
            this.verdict = "Failed";
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }



}

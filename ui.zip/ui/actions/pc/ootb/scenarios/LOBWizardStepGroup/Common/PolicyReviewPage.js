import { t } from "testcafe";
import { PolicyReviewScreen } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/PolicyReviewScreen"
import { UWBlockProgressIssuesPopup_Ext } from "../../PopUp/UWBlockProgressIssuesPopup_Ext";
import { RiskAnalysisScreen } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/RiskAnalysisScreen";
import { RiskAnalysisPage } from "./RiskAnalysisPage";
import { RiskApprovalDetailsPopup } from "../../../../../../pages/gw/generated/policycenter/pages/popup/Risk/RiskApprovalDetailsPopup";
import { TabBarScenarios } from "../../Navigation/TabBarScenarios";
import { SubmissionWizard } from "../../Navigation/SubmissionWizard";
import { onApp } from "../../../../../../pages/gw/registry/onApp";
import { setStepDescription } from "../../../../../../util/common/setStepDescription.js"

const pageNameStaticContent = require('../../../../../../util/common/pageNameStaticContent.js');
const otherConstants = require('../../../../../../util/common/otherConstantsFile.js')
const stepDescription = new setStepDescription();

const policyReviewScreen = new PolicyReviewScreen()
const uwBlockProgressIssuesPopup = new UWBlockProgressIssuesPopup_Ext();
const riskAnalysisScreen = new RiskAnalysisScreen();
const riskAnalysisPage = new RiskAnalysisPage();
const riskApprovalDetailsPopup = new RiskApprovalDetailsPopup();
const tabBarScenarios = new TabBarScenarios();
const submissionWizard = new SubmissionWizard();
const onPCApp = new onApp("PC");
let logoutFlag = '';
let releaseLockRequestFlag = '';
let submissionNumber = '';

export class PolicyReviewPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    //To confirm page navigation to Policy Review page
    async confirmPageNavigation(fileObj) {
        this.stepAction = stepDescription.setActionStep(otherConstants.VERIFICATION_STEP);
        this.stepER = stepDescription.setExpResultStep(`${otherConstants.VERIFY_PAGE_NAVIGATION} ${pageNameStaticContent.POLICY_REVIEW_PAGE}`);
        await policyReviewScreen.policyReviewScreenTitleBar.visible;
        if (await policyReviewScreen.policyReviewScreenTitleBar.exists) {
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.PAGE_NAVIGATION_PASS} ${pageNameStaticContent.POLICY_REVIEW_PAGE}`);
            this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED);
        } else {
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.PAGE_NAVIGATION_FAIL} ${pageNameStaticContent.POLICY_REVIEW_PAGE}`);
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED);
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    //To click on Quote button in Policy Rew Page
    async clickQuoteInPolicyReview(fileObj, data = '') {
        try {
            await t.wait(20000);
            await this.clickingQuoteButton(fileObj);
            if (await uwBlockProgressIssuesPopup.UWBlockProgressIssuesPopupUnderwriterIssuesTitle.component.visible) {
                console.log("Issues that block Issuance Header displayed");
                this.stepAction = "Block Issuance Header displayed, Checking details";
                this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP);
                this.stepAR = stepDescription.resetActualResultStep();
                this.verdict = stepDescription.resetVerdictStep();
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
                await this.approvePreQuoteUWIssues(fileObj, data);
            }
            await t.wait(20000);
            if ((await policyReviewScreen.validationResults.component.visible) && (await policyReviewScreen.policyReviewScreenQuoteButton.component.visible) ){
                await this.clickingQuoteButton(fileObj);
                await t.wait(20000);
            }
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep();
            this.stepER = stepDescription.resetExpResultStep();
            this.stepAR = `${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_REVIEW_PAGE}`;
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED);
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw (err);
        }
    }

    //To click on Quote button in Policy Review Page
    async verifyPageNavigationAndEditPolicyTransaction(fileObj, data = '') {
        try {
            await this.confirmPageNavigation(fileObj);
            await this.clickEditPolicyTransaction(fileObj);
            await t.wait(10000);
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep();
            this.stepER = stepDescription.resetExpResultStep();
            this.stepAR = `${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_REVIEW_PAGE}`;
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED);
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw (err);
        }
    }

    async clickEditPolicyTransaction(fileObj) {
        this.stepAction = `Click the Edit Policy Transaction Button in ${pageNameStaticContent.POLICY_REVIEW_PAGE}`;
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP);
        this.stepAR = stepDescription.resetActualResultStep();
        this.verdict = stepDescription.resetVerdictStep();
        console.log(`Clicking on Edit Policy Transaction Button ...`);
        await policyReviewScreen.editPolicyTransactionButton.click();
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    async clickingQuoteButton(fileObj) {
        this.stepAction = `Click the Quote Button in ${pageNameStaticContent.POLICY_REVIEW_PAGE}`;
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP);
        this.stepAR = stepDescription.resetActualResultStep();
        this.verdict = stepDescription.resetVerdictStep();
        console.log(`Clicking on Quote Button ...`);
        await policyReviewScreen.policyReviewScreenQuoteButton.click();
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    async approvePreQuoteUWIssues(fileObj, data) {
        try {
            if (await uwBlockProgressIssuesPopup.issuesScreenDetailsButton.component.exists) {
                this.stepAction = "Click the Issues Details Button to view UW issues";
                this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP);
                this.stepAR = stepDescription.resetActualResultStep();
                this.verdict = stepDescription.resetVerdictStep();
                console.log(`Clicking on Issues Details Button ...`);
                await uwBlockProgressIssuesPopup.issuesScreenDetailsButton.click();
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
                await riskAnalysisPage.confirmPageNavigation(fileObj);
            }
            if (await riskAnalysisScreen.riskAnalysisScreenUWIssueRowSetApproveButton.component.withAttribute('aria-disabled', 'true').exists) {
                await this.requestApproval(fileObj);
                releaseLockRequestFlag = "Yes";
                submissionNumber = await submissionWizard.getSubmissionNumber(fileObj);
                await onPCApp.logout();
                await onPCApp.loginWithUser("su", "gw");
                await tabBarScenarios.searchBySubmissionNumber(fileObj, submissionNumber);
                await submissionWizard.navigateToRiskAnalysisPage(fileObj);
                logoutFlag = "Yes";
            }
            if ((data.viewIssuesBlocking !== "") && (data.hasOwnProperty('viewIssuesBlocking'))) {
                console.log(`List blocking issues`);
                this.stepAction = `Select Blocking Issues filter to be : ` + data.viewIssuesBlocking;
                this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP);
                this.stepAR = stepDescription.resetActualResultStep();
                this.verdict = stepDescription.resetVerdictStep();
                await riskAnalysisScreen.riskAnalysisScreenViewIssuesFilterDropdown.selectOptionByLabel(data.viewIssuesBlocking);
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            }
            if (await riskAnalysisScreen.riskAnalysisScreenUWIssueRowSetApproveButton.component.exists) {
                let issueButtonCount = await riskAnalysisScreen.riskAnalysisScreenUWIssueRowSetApproveButton.component.count;
                for (let count = 0; count < issueButtonCount; count++) {
                    console.log(`Clicking on Approve Button ...`);
                    await riskAnalysisScreen.riskAnalysisScreenUWIssueRowSetApproveButton.click();
                    await riskAnalysisScreen.riskAnalysisScreenRiskApprovalDetailsTitle.component.visible;
                    let uwIssueDescription = await riskAnalysisScreen.riskAnalysisApprovalScreenIssueDescriptionText.component.innerText;
                    console.log(`Approving UW Issue: "${uwIssueDescription}"`);
                    this.stepAction = `For the UW Issue: "${uwIssueDescription}", Click the Approve > OK`;
                    this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP);
                    this.stepAR = stepDescription.resetActualResultStep();
                    this.verdict = stepDescription.resetVerdictStep();
                    await riskApprovalDetailsPopup.riskApprovalDetailsPopupUpdate.click();
                    await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
                }
                if (releaseLockRequestFlag === 'Yes') {
                    await this.releaseLock(fileObj);
                }
            }
            if (logoutFlag === 'Yes') {
                await onPCApp.logout();
                let user = onPCApp.getUserForRole(data.role);
                // Using this method instead of loginWithRole due to an issue were user does not login when used multiple times
                await onPCApp.loginWithUser(user.username, user.password);
                await tabBarScenarios.searchBySubmissionNumber(fileObj, submissionNumber);
            }
            await this.clickingQuoteButton(fileObj);
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep();
            this.stepER = stepDescription.resetExpResultStep();
            this.stepAR = `${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_REVIEW_PAGE}`;
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED);
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw (err)
        }
    }

    async requestApproval(fileObj) {
        this.stepAction = `Click for UW Request Approval`;
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP);
        this.stepAR = stepDescription.resetActualResultStep();
        this.verdict = stepDescription.resetVerdictStep();
        await riskAnalysisScreen.riskAnalysisScreenRequestApprovalButton.click();
        await riskAnalysisScreen.riskAnalysisScreenSendRequestButton.click();
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    async releaseLock(fileObj) {
        this.stepAction = `Click Release Lock`;
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP);
        this.stepAR = stepDescription.resetActualResultStep();
        this.verdict = stepDescription.resetVerdictStep();
        await riskAnalysisScreen.riskAnalysisScreenReleaseLockButton.click();
        await riskAnalysisScreen.riskAnalysisScreenSendRequestButton.click();
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    // Save the Submission
    async clickSaveDraft(fileObj) {
        this.stepAction = `Click Save Draft`;
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP);
        this.stepAR = stepDescription.resetActualResultStep();
        this.verdict = stepDescription.resetVerdictStep();
        await policyReviewScreen.policyReviewScreenSaveDraftButton.click();
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    async saveSubmissionInDraft(fileObj) {
        await this.confirmPageNavigation(fileObj);
        await this.clickSaveDraft(fileObj);
    }

    async assertSubmssionStatus(fileObj, expectedSubmissionStatus) {
        console.log("exp Submission Status is " + expectedSubmissionStatus);
        this.stepAction = stepDescription.setActionStep(otherConstants.VERIFICATION_STEP);
        this.stepER = `Verify the submission is in ${expectedSubmissionStatus}`;
        await policyReviewScreen.policyReviewScreenSubmissionStatus.isAvailable();
        let appSubmissionStatus = await policyReviewScreen.policyReviewScreenSubmissionStatus.component.innerText;
        console.log("Actual Submission Status is " + appSubmissionStatus);
        if(expectedSubmissionStatus == appSubmissionStatus) {
            this.stepAR = `AS EXPECTED. the submission is in ${expectedSubmissionStatus}`;
            this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED);
        } else {
            this.stepAR = `NOT AS EXPECTED, the submission is NOT in ${expectedSubmissionStatus}, The actual is ${appSubmissionStatus}`;
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED);
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    // Click next button
    async clickNextAndUpdateHtml(fileObj) {
        this.stepAction = `Click the Next Button in ${pageNameStaticContent.POLICY_REVIEW_PAGE}`
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP);
        this.stepAR = stepDescription.resetActualResultStep();
        this.verdict = stepDescription.resetVerdictStep();
        console.log(`Clicking on Next Button ...`)
        await policyReviewScreen.nextButton.click();
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async editPolicyTransaction(fileObj) {
        await this.confirmPageNavigation(fileObj)
        try {
            this.stepAction = "Select Edit Policy Transaction in " + pageNameStaticContent.POLICY_REVIEW_PAGE;
            this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
            this.stepAR = stepDescription.resetActualResultStep()
            this.verdict = stepDescription.resetVerdictStep()
            console.log(`Clicking Edit Policy Transaction Button ...`)
            await policyReviewScreen.policyReviewScreenEditPolicyTransactionButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_REVIEW_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async clickNextInPolicyReviewPage(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj);
            await this.clickNextAndUpdateHtml(fileObj);
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.POLICY_REVIEW_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}

import { OfferingsScreen } from '../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/OfferingsScreen.js';
import { captureScreenshot } from '../../../../../../util/common/helper.js';

const offeringsScreen = new OfferingsScreen()

export class OfferingsPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async selectOfferings(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj)
            this.stepAction = ""
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            if ((data.policyType != "") && (data.hasOwnProperty('policyType'))) {
                console.log(`Enter Policy Type: ${data.policyType}`)
                this.stepAction = "Enter 'Policy Type' as : " + data.policyType
                await offeringsScreen.offeringsTypeDropdown.selectOptionByLabel(data.policyType);
            }
            if ((data.offeringSelection != "") && (data.hasOwnProperty('offeringSelection'))) {
                console.log(`Enter Offering Selection: ${data.offeringSelection}`)
                this.stepAction = this.stepAction + ", 'Offering Selection' as : " + data.offeringSelection
                await offeringsScreen.offeringsDropdown.selectOptionByLabel(data.offeringSelection)
            }

            this.stepAction = this.stepAction + " and click the Next button"
            console.log(`Clicking on Next Button ...`)
            await offeringsScreen.offeringsNextButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Offerings Page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async confirmPageNavigation(fileObj) {
        this.stepER = "Verification Step, Action N/A"
        this.stepAction = "Verify that you are taken to the Offerings Page"
        if (await offeringsScreen.offeringsTitle.component.visible) {
            this.stepAR = "Successfully navigated to the Offerings Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the Offerings Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async clickNextInOfferingsPageAndUpdateHTML(fileObj) {
        try {
            this.stepAction = "Click the Next Button in Offerings Page";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Clicking on Next Button ...`)
            await offeringsScreen.offeringsNextButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Clicking Next" + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}

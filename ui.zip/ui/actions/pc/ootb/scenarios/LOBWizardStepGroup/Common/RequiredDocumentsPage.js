
import { captureScreenshot } from "../../../../../../util/common/helper.js";
import { Homeowners } from "../../../../../../pages/gw/generated/policycenter/pages/lOBWizardStepGroup/Homeowners.js";

const homeOwner =new Homeowners();

export class RequiredDocumentsPage {
    constructor() {
        this.pageName = "Required Documents Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async enterRequiredDocuments(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj);
            await captureScreenshot();
            await this.confirmRequestedForApproval(fileObj);
            await captureScreenshot();
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await homeOwner.requiredDocumentsScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async confirmRequestedForApproval(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the Issuance section`
        if (await homeOwner.issuanceMessageBar.visible) {
            this.stepAR = `Successfully requested for Approval`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to do Request Approval`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

}

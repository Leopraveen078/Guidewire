import { t } from "testcafe";
import { QualificationScreen } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/QualificationScreen.js";
import QualificationPageConstants from "../../Constants/QualificationPageConstants.js"
import { captureScreenshot } from "../../../../../../util/common/helper.js";

const qualificationScreen = new QualificationScreen();

export class QualificationPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async enterQualificationDetails(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            this.stepAction = "Enter Qualification details - "
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            // Entering data for Payment Protection Insurance Questions
            if ((data.insuranceVoidedOrRefusedOrCancelledQuestion !== "") && (data.hasOwnProperty('insuranceVoidedOrRefusedOrCancelledQuestion'))) {
                this.stepAction = this.stepAction + ", ' " + QualificationPageConstants.insuranceVoidedOrRefusedOrCancelledQuestion + "' as : " + data.insuranceVoidedOrRefusedOrCancelledQuestion
                await this.selectRadioOption(QualificationPageConstants.insuranceVoidedOrRefusedOrCancelledQuestion, data.insuranceVoidedOrRefusedOrCancelledQuestion)
            }

            if ((data.policyEngagedInFixedTermQuestion !== "") && (data.hasOwnProperty('policyEngagedInFixedTermQuestion'))) {
                this.stepAction = this.stepAction + ", ' " + QualificationPageConstants.policyEngagedInFixedTermQuestion + "' as : " + data.policyEngagedInFixedTermQuestion
                await this.selectRadioOption(QualificationPageConstants.policyEngagedInFixedTermQuestion, data.policyEngagedInFixedTermQuestion)
            }

            if ((data.bloodPressureHeartTroubleDiabetesQuestion !== "") && (data.hasOwnProperty('bloodPressureHeartTroubleDiabetesQuestion'))) {
                this.stepAction = this.stepAction + ", ' " + QualificationPageConstants.bloodPressureHeartTroubleDiabetesQuestion + "' as : " + data.bloodPressureHeartTroubleDiabetesQuestion
                await this.selectRadioOption(QualificationPageConstants.bloodPressureHeartTroubleDiabetesQuestion, data.bloodPressureHeartTroubleDiabetesQuestion)
            }

            if ((data.healthIssuesInjuryOrIllnessQuestion !== "") && (data.hasOwnProperty('healthIssuesInjuryOrIllnessQuestion'))) {
                this.stepAction = this.stepAction + ", ' " + QualificationPageConstants.healthIssuesInjuryOrIllnessQuestion + "' as : " + data.healthIssuesInjuryOrIllnessQuestion
                await this.selectRadioOption(QualificationPageConstants.healthIssuesInjuryOrIllnessQuestion, data.healthIssuesInjuryOrIllnessQuestion)
            }

            if ((data.vehicleBeUsedForTheBusinessQuestion !== "") && (data.hasOwnProperty('vehicleBeUsedForTheBusinessQuestion'))) {
                this.stepAction = this.stepAction + ", ' " + QualificationPageConstants.vehicleBeUsedForTheBusinessQuestion + "' as : " + data.vehicleBeUsedForTheBusinessQuestion
                await this.selectRadioOption(QualificationPageConstants.vehicleBeUsedForTheBusinessQuestion, data.vehicleBeUsedForTheBusinessQuestion)
            }

            if ((data.applicantInsurancePolicyDeclinedQuestion !== "") && (data.hasOwnProperty('applicantInsurancePolicyDeclinedQuestion'))) {
                this.stepAction = this.stepAction + ", ' " + QualificationPageConstants.applicantInsurancePolicyDeclinedQuestion + "' as : " + data.applicantInsurancePolicyDeclinedQuestion
                await this.selectRadioOption(QualificationPageConstants.applicantInsurancePolicyDeclinedQuestion, data.applicantInsurancePolicyDeclinedQuestion)
            }

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            await this.clickNextInQualificationPage(fileObj);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Qualification Page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async confirmPageNavigation(fileObj) {
        this.stepER = "Verification Step, Action N/A"
        this.stepAction = "Verify that you are taken to the Qualification Page"
        if (await qualificationScreen.qualificationScreenTitleBar.component.visible) {
            this.stepAR = "Successfully navigated to the Qualification Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the Qualification Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async clickNextInQualificationPage(fileObj) {
        try {
            this.stepAction = "Click the Next Button in Qualification Page"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Clicking on Next Button ...`)
            await qualificationScreen.qualificationScreenNextButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Qualification Page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async selectRadioOption(question, optionValue) {
        console.log(`Entering selectRadioOption method...`)
        const radioButtonOptionFieldOption = qualificationScreen.qualificationScreenRadioButtonOptionField.withText(question).find('span').withText(optionValue);
        if (await radioButtonOptionFieldOption.exists) {
            console.log(`Select ` + question + ` as - ` + optionValue)
            await t.click(radioButtonOptionFieldOption);
        } else console.log(`Option Not displayed:  ` + question + ` as - ` + optionValue)
    }
}

import { JobWizardInfoBarScreen_Ext } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/JobWizardInfoBarScreen_Ext"
import { setStepDescription } from "../../../../../../util/common/setStepDescription.js"

const otherConstants = require('../../../../../../util/common/otherConstantsFile.js')
const jobWizardInfoBarScreen = new JobWizardInfoBarScreen_Ext()
const stepDescription = new setStepDescription();

export class JobWizardInfoBar {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async assertSubmissionState(fileObj, submissionState) {
        try {
            
            this.stepAction = stepDescription.setExpResultStep(otherConstants.VERIFICATION_STEP);
            this.stepER = `Verify the Policy is: ${submissionState}`;
    
            // Get the value from the UI
            const valueFromUI = await jobWizardInfoBarScreen.wizardInfoBarSubmissionState.component.innerText;
            
            // Log the policy submission status
            console.log("Policy Submission Status - " + valueFromUI);
    
            // Verify if the status matches the expected submission state
            if (valueFromUI.includes(submissionState)) {
                console.log("AS EXPECTED, Policy Submission Status: " + submissionState);
                this.stepAR = `AS EXPECTED, Policy Submission Status: ${submissionState}`;
                this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED);
            } else {
                console.log("NOT AS EXPECTED, Policy Submission Status is NOT " + submissionState);
                this.stepAR = `NOT AS EXPECTED, Policy Submission Status is NOT ${submissionState}`;
                this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED);
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = "Error in asserting submission state.";
            this.stepER = `Failed to verify the Policy Submission Status`;
            this.stepAR = `Error in ${this.pageName}: ${err.message}`;
            this.verdict = "Failed";
    
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }
    
}

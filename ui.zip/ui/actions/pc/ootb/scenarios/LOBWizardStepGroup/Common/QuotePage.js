import { t } from 'testcafe';
import { QuoteScreen } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/QuoteScreen.js";
import { JobWizardInfoBar } from "./JobWizardInfoBar.js";
import { setStepDescription } from "../../../../../../util/common/setStepDescription.js";

const pageNameStaticContent = require('../../../../../../util/common/pageNameStaticContent.js');
const otherConstants = require('../../../../../../util/common/otherConstantsFile.js');
const stepDescription = new setStepDescription();
const quoteScreen = new QuoteScreen();
const jobWizardInfoBar = new JobWizardInfoBar();

export class QuotePage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    // Verify Page Navigation
    async confirmPageNavigation(fileObj) {

        this.stepAction = stepDescription.setActionStep(otherConstants.VERIFICATION_STEP)
        this.stepER = stepDescription.setExpResultStep(`${otherConstants.VERIFY_PAGE_NAVIGATION} ${pageNameStaticContent.QUOTE_PAGE}`)
        if (await quoteScreen.quoteScreenTitleBar.component.visible) {
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.PAGE_NAVIGATION_PASS} ${pageNameStaticContent.QUOTE_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
        } else {
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.PAGE_NAVIGATION_FAIL} ${pageNameStaticContent.QUOTE_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    //To Navigate to next button in Quote Page
    async clickNextInQuotesPage(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj);

            await this.verifyPremiumGreaterThanZero(fileObj);

            await this.clickNextAndUpdateHtml(fileObj);
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`${otherConstants.ERROR_IN} ${pageNameStaticContent.QUOTE_PAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    //To assert that the Submission is successfully quoted
    async assertSubmissionQuoted(fileObj) {
        await this.confirmPageNavigation(fileObj);
        await jobWizardInfoBar.assertSubmissionState(fileObj, "Quoted")
        await this.verifyPremiumGreaterThanZero(fileObj);
    }

    // Verify Premium amount
    async verifyPremiumGreaterThanZero(fileObj) {

        this.stepAction = stepDescription.setExpResultStep(otherConstants.VERIFICATION_STEP)
        this.stepER = `Verify the Premium amount is generated and greater than zero`

        if (await quoteScreen.quoteScreenSubmissionTotalPremium.component.exists) {
            const premiumAmount = await quoteScreen.quoteScreenSubmissionTotalPremium.component.innerText;
            t.ctx.premiumValue = premiumAmount
            let amount = premiumAmount.replace("$", "").replace(",", "");
            const premiumValue = Number(amount)
            if (premiumValue > 0) {
                this.stepAR = `AS EXPECTED, Premium amount is generated and greater than zero, Premium Amount : ${premiumAmount}`
                this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
            } else {

                this.stepAR = `NOT AS EXPECTED, Premium amount is generated and NOT greater than zero, Premium Amount : ${premiumAmount}`
                this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            }
        } else {

            this.stepAR = `NOT AS EXPECTED, No Premium Amount is generated for this Quote`
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    // Click next and update HTML
    async clickNextAndUpdateHtml(fileObj) {
        this.stepAction = `${otherConstants.CLICK_NEXT_BUTTON} ${pageNameStaticContent.QUOTE_PAGE}`
        this.stepER = stepDescription.setExpResultStep(otherConstants.ACTION_STEP)
        this.stepAR = stepDescription.resetActualResultStep()
        this.verdict = stepDescription.resetVerdictStep()
        await quoteScreen.quoteScreenNextButton.click();
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

}

import { t } from 'testcafe';
import { BoundScreen } from '../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/Common/BoundScreen.js';
import { captureScreenshot } from '../../../../../../util/common/helper.js';
const renewalBoundScreen = new BoundScreen();

export class RenewalBoundPage {

    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
        this.pageName = "Renewal Bound Page"
    }

    async verifyRenewalBound(fileObj) {

        try {
            await this.confirmPageNavigation(fileObj)
            await this.assertRenewalBound(fileObj)
            await t.wait(2000)
        }
        catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the Renewal Bound Page"
        let RenewalpageExists = renewalBoundScreen.JobComplete_JobCompleteScreen_ttlBar.component.withText("Renewal Bound");
        if (await RenewalpageExists.innerText == "Renewal Bound") {
            this.stepAR = "Successfully navigated to the Renewal Bound Page "
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the to the Renewal Bound Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async assertRenewalBound(fileObj) {
        this.stepAction = `Verification Step. Action N/A`
        this.stepER = "Verify the Policy Renewal is bound."
        this.stepAR = ""
        this.verdict = ""
        let Renewalmsg = renewalBoundScreen.JobComplete_JobCompleteScreen_Message.component.withText(/^Your Renewal (.*) has been bound.$/).visible;
        if (await Renewalmsg) {
            let policyText = await renewalBoundScreen.JobComplete_JobCompleteScreen_JobCompleteDV_ViewPolicy.component.innerText;
            var policyNumber = policyText.replace('View your policy (#', '').replace(")", "");
            let TransactionText = await renewalBoundScreen.JobComplete_JobCompleteScreen_Message.component.innerText
            var TransactionNumber = TransactionText.replace('Your Renewal (#', '').replace(") has been bound.", "");
            console.log(`Capturing Policy Renewal Transaction Number:${TransactionNumber} and Policy Number:${policyNumber}`)
            this.stepAR = `AS EXPECTED, Policy Renewal is bound successfully.The Policy Renewal Transaction number is "${TransactionNumber}" for Policy - "${policyNumber}"`
            this.verdict = "Passed"
        }
        else {
            console.log(`NOT AS EXPECTED,Policy Renewal is NOT bound successfully.`)
            this.stepAR = `NOT AS EXPECTED,Policy Renewal is NOT bound successfully.`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async viewPolicyDetails(fileObj) {
        try {
            this.stepAction = "Click the View your policy link from " + this.pageName;
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Clicking on View your policy ...`)
            await renewalBoundScreen.JobComplete_JobCompleteScreen_JobCompleteDV_ViewPolicy.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            await t.wait(2000)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}
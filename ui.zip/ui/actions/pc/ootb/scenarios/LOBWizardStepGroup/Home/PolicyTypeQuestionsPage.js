import { t } from "testcafe";
import { NextSubmissionWizard } from "../../../../../../pages/gw/generated/policycenter/pages/navigation/submissionWizard/NextSubmissionWizard";
import { NewSubmission } from "../../../../../../pages/gw/generated/policycenter/pages/policy/NewSubmission";
import { selectDropdown, captureScreenshot } from "../../../../../../util/common/helper";

const newSubmission = new NewSubmission();
const nextSubmissionWizard = new NextSubmissionWizard();

export class PolicyTypeQuestionsPage {
    constructor() {
        this.pageName = "Policy Type Questions Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await newSubmission.preQualificationScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async enterPolicyTypeQuestionsDetails(fileObj, data) {

        try {
            await this.confirmPageNavigation(fileObj);
            this.stepAction = "Enter Policy Type Questions details as follows:<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "";
            this.verdict = ""
            console.log(`Entering Policy Type Questions Page...`)

            console.log(`Select the perils you want to quote: ${data.POL_Perils}`);
            this.stepAction += "'Select the perils you want to quote: " + data.POL_Perils + "', <br>";
            await newSubmission.SubmissionWizard_HOPreQualificationPanelSet_perils.selectOptionByLabel(data.POL_Perils);

            console.log(`Are you quoting Contents Only coverage?: ${data.POL_ContentsOnly}`);
            this.stepAction += "'Are you quoting Contents Only coverage?: " + data.POL_ContentsOnly + "', <br>";
            if ((data.POL_ContentsOnly != "") && (data.hasOwnProperty('POL_ContentsOnly'))) {
                if (data.POL_ContentsOnly.includes('Yes')) {
                    await newSubmission.SubmissionWizard_HOPreQualificationPanelSet_Contentsonly_YesButton.click();
                } else if (data.POL_ContentsOnly.includes('No')) {
                    await newSubmission.SubmissionWizard_HOPreQualificationPanelSet_Contentsonly_NoButton.click();
                }
            }
                        
            console.log(`Select the structure being covered: ${data.POL_StructureBeingCoverd}`);
            this.stepAction += "'Select the structure being covered: " + data.POL_StructureBeingCoverd + "', <br>";
            await selectDropdown(newSubmission.SubmissionWizard_HOPreQualificationPanelSet_ResidenceType_Selector, data.POL_StructureBeingCoverd);
            
            console.log(`Policy Type: ${data.POL_PolicyType}`);
            this.stepAction += "'Policy Type: " + data.POL_PolicyType + "', <br>";
            await selectDropdown(newSubmission.SubmissionWizard_HOPreQualificationPanelSet_HOPolicyType_Selector, data.POL_PolicyType);
            
            console.log(`Offer of coverage - Please read the definitions below before making a selection: (A. or B. must be selected to be eligible for coverage): ${data.POL_OfferofCoverage}`);
            this.stepAction += "'Offer of coverage - Please read the definitions below before making a selection: (A. or B. must be selected to be eligible for coverage): " + data.POL_OfferofCoverage + "', <br>";
            await selectDropdown(newSubmission.SubmissionWizard_HOPreQualificationPanelSet_offerofcoverage_Selector, data.POL_OfferofCoverage);
            
            console.log(`Has any applicant been canceled or nonrenewed for material misrepresentation on an application for insurance or on a claim in the past 15 years?: ${data.POL_AplicntCancld_MatrialMisrepPast7Yrs}`);
            this.stepAction += "'Has any applicant been canceled or nonrenewed for material misrepresentation on an application for insurance or on a claim in the past 15 years?: " + data.POL_AplicntCancld_MatrialMisrepPast7Yrs + "', <br>";
            if ((data.POL_AplicntCancld_MatrialMisrepPast7Yrs != "") && (data.hasOwnProperty('POL_AplicntCancld_MatrialMisrepPast7Yrs'))) {
                if (data.POL_AplicntCancld_MatrialMisrepPast7Yrs.includes('Yes')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_claimCancel7years_YesButton.click();
                } else if (data.POL_AplicntCancld_MatrialMisrepPast7Yrs.includes('No')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_claimCancel7years_NoButton.click();
                }
            }

            console.log(`Has any applicant been canceled, convicted or pleaded no contest for insurance fraud in the past 15 years?: ${data.POL_AplicntCancld_InsuranceFraudPast15Yrs}`);
            this.stepAction += "'Has any applicant been canceled, convicted or pleaded no contest for insurance fraud in the past 15 years?: " + data.POL_AplicntCancld_InsuranceFraudPast15Yrs + "', <br>";
            if ((data.POL_AplicntCancld_InsuranceFraudPast15Yrs != "") && (data.hasOwnProperty('POL_AplicntCancld_InsuranceFraudPast15Yrs'))) {
                if (data.POL_AplicntCancld_InsuranceFraudPast15Yrs.includes('Yes')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_claimCancel15years_YesButton.click();
                } else if (data.POL_AplicntCancld_InsuranceFraudPast15Yrs.includes('No')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_claimCancel15years_NoButton.click();
                }
            }
            
            console.log(`Has any applicant been convicted or pleaded no contest for arson in the past 15 years?: ${data.POL_AplicntConvicted_ArsonPast15Yrs}`);
            this.stepAction += "'Has any applicant been convicted or pleaded no contest for arson in the past 15 years?: " + data.POL_AplicntConvicted_ArsonPast15Yrs + "', <br>";
            if ((data.POL_AplicntConvicted_ArsonPast15Yrs != "") && (data.hasOwnProperty('POL_AplicntConvicted_ArsonPast15Yrs'))) {
                if (data.POL_AplicntConvicted_ArsonPast15Yrs.includes('Yes')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_isConvicted15years_YesButton.click();
                } else if (data.POL_AplicntConvicted_ArsonPast15Yrs.includes('No')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_isConvicted15years_NoButton.click();
                }
            }
            
            console.log(`Is home currently condemned?: ${data.POL_IsHomeCurrntlyCondemned}`);
            this.stepAction += "'Is home currently condemned?: " + data.POL_IsHomeCurrntlyCondemned + "', <br>";
            if ((data.POL_IsHomeCurrntlyCondemned != "") && (data.hasOwnProperty('POL_IsHomeCurrntlyCondemned'))) {
                if (data.POL_IsHomeCurrntlyCondemned.includes('Yes')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_isHomeCondemned_YesButton.click();
                } else if (data.POL_IsHomeCurrntlyCondemned.includes('No')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_isHomeCondemned_NoButton.click();
                }
            }
            
            console.log(`Any structure partially or entirely over water?: ${data.POL_AnyStructurePartiallyEntirlyOverWater}`);
            this.stepAction += "'Any structure partially or entirely over water?: " + data.POL_AnyStructurePartiallyEntirlyOverWater + "', <br>";
            if ((data.POL_AnyStructurePartiallyEntirlyOverWater != "") && (data.hasOwnProperty('POL_AnyStructurePartiallyEntirlyOverWater'))) {
                if (data.POL_AnyStructurePartiallyEntirlyOverWater.includes('Yes')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_isOnWater_YesButton.click();
                } else if (data.POL_AnyStructurePartiallyEntirlyOverWater.includes('No')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_isOnWater_NoButton.click();
                }
            }
            
            console.log(`Is the roof damaged or does the roof have visible signs of leaks?: ${data.POL_IsRoofDamagedOrVisibleSignsOfLeaks}`);
            this.stepAction += "'Is the roof damaged or does the roof have visible signs of leaks? " + data.POL_IsRoofDamagedOrVisibleSignsOfLeaks + "', <br>";
            if ((data.POL_IsRoofDamagedOrVisibleSignsOfLeaks != "") && (data.hasOwnProperty('POL_IsRoofDamagedOrVisibleSignsOfLeaks'))) {
                if (data.POL_IsRoofDamagedOrVisibleSignsOfLeaks.includes('Yes')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_isRoofDamaged_YesButton.click();
                } else if (data.POL_IsRoofDamagedOrVisibleSignsOfLeaks.includes('No')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_isRoofDamaged_NoButton.click();
                }
            }
            
            console.log(`Is the dwelling used as a fraternity or sorority house or any similar housing arrangement? ${data.POL_IsDwellingUsedFraternityOrSororityHouse}`);
            this.stepAction += "'Is the dwelling used as a fraternity or sorority house or any similar housing arrangement? " + data.POL_IsDwellingUsedFraternityOrSororityHouse + "', <br>";
            if ((data.POL_IsDwellingUsedFraternityOrSororityHouse != "") && (data.hasOwnProperty('POL_IsDwellingUsedFraternityOrSororityHouse'))) {
                if (data.POL_IsDwellingUsedFraternityOrSororityHouse.includes('Yes')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_isFraternityUse_YesButton.click();
                } else if (data.POL_IsDwellingUsedFraternityOrSororityHouse.includes('No')) {
                    await newSubmission.SubmissionWizard_PreQualificationScreen_HOPreQualificationPanelSet_isFraternityUse_NoButton.click();
                }
            }
            
            await nextSubmissionWizard.submissionWizardNext.click();

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
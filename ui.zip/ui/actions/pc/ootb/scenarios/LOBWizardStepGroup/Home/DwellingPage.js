import { t } from "testcafe";
import { Homeowners } from "../../../../../../pages/gw/generated/policycenter/pages/lOBWizardStepGroup/Homeowners.js";
import { NextSubmissionWizard } from "../../../../../../pages/gw/generated/policycenter/pages/navigation/submissionWizard/NextSubmissionWizard";
import { dateConversion, selectDropdown, captureScreenshot } from "../../../../../../util/common/helper.js";

const nextSubmissionWizard = new NextSubmissionWizard();
const homeOwner = new Homeowners();

export class DwellingPage {
    constructor() {
        this.pageName = "Dwelling Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await homeOwner.HODwellingHOEScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async enterDwellingDetails(fileObj, data) {

        try {
            await this.confirmPageNavigation(fileObj);
            this.stepAction = "Enter Dwelling details as follows:<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "";
            this.verdict = ""
            console.log(`Entering Dwelling Page...`)

            console.log(`Date occupied: ${data.Dwell_DateOccupied}`);
            let generatedOccupiedDate = await dateConversion(data.Dwell_DateOccupied, '')
            console.log('generated occupied date - ' + generatedOccupiedDate)
            this.stepAction += "'Date occupied: " + generatedOccupiedDate + "', <br>";
            await homeOwner.hODwellingDetailsHOEDVDateOccupied.setValue(generatedOccupiedDate);

            if ((data.Dwell_ResidencType != "") && (data.hasOwnProperty('Dwell_ResidencType'))) {
                console.log(`Residence Type: ${data.Dwell_ResidencType}`);
                this.stepAction += "'Residence Type: " + data.Dwell_ResidencType + "', <br>";
                await selectDropdown(homeOwner.hODwellingDetailsHOEDVResidenceType_Selector, data.Dwell_ResidencType);
            }

            console.log(`Number of Families: ${data.Dwell_NumOfFamilies}`);
            this.stepAction += "'Number of Families: " + data.Dwell_NumOfFamilies + "', <br>";
            await selectDropdown(homeOwner.hODwellingDetailsHOEDVNumOfFamilies_Selector, data.Dwell_NumOfFamilies);

            console.log(`Number of Roomers/Boarders: ${data.Dwell_NumOfRoomersBoarders}`);
            this.stepAction += "'Number of Roomers/Boarders: " + data.Dwell_NumOfRoomersBoarders + "', <br>";
            await selectDropdown(homeOwner.hODwellingDetailsHOEDVNumOfRoomersBorders_Selector, data.Dwell_NumOfRoomersBoarders);

            console.log(`How is the dwelling occupied?: ${data.Dwell_HowIsDwellOccupid}`);
            this.stepAction += "'How is the dwelling occupied?: " + data.Dwell_HowIsDwellOccupid + "', <br>";
            await selectDropdown(homeOwner.hODwellingDetailsHOEDVOccupancy_Selector, data.Dwell_HowIsDwellOccupid);

            console.log(`How is the dwelling customarily used?: ${data.Dwell_HowIsDwellCustmirlyUsed}`);
            this.stepAction += "'How is the dwelling customarily used?: " + data.Dwell_HowIsDwellCustmirlyUsed + "', <br>";
            await selectDropdown(homeOwner.hODwellingDetailsHOEDVUsage_Selector, data.Dwell_HowIsDwellCustmirlyUsed);

            if ((data.Dwell_IdentfyMnthsUnoccupid_None != "") && (data.hasOwnProperty('Dwell_IdentfyMnthsUnoccupid_None'))) {
                console.log(`Identify All Months Unoccupied: None`);
                this.stepAction += "Identify All Months Unoccupied: None <br>";
                if (data.Dwell_IdentfyMnthsUnoccupid_None.includes('Yes')) {
                    await homeOwner.hODwellingDetailsHOEDVNoMonthsOccupied.click();
                }
            }

            if ((data.Dwell_IdentfyMnthsUnoccupid_Jan != "") && (data.hasOwnProperty('Dwell_IdentfyMnthsUnoccupid_Jan'))) {
                console.log(`Identify All Months Unoccupied: January`);
                this.stepAction += "Identify All Months Unoccupied: January <br>";
                if (data.Dwell_IdentfyMnthsUnoccupid_Jan.includes('Yes')) {
                    await t.click(homeOwner.hODwellingDetailsHOEDVMonthsUnoccupied1_Selector.withText('January'));
                }
            }

            if ((data.Dwell_IdentfyMnthsUnoccupid_Feb != "") && (data.hasOwnProperty('Dwell_IdentfyMnthsUnoccupid_Feb'))) {
                console.log(`Identify All Months Unoccupied: February`);
                this.stepAction += "Identify All Months Unoccupied: February <br>";
                if (data.Dwell_IdentfyMnthsUnoccupid_Feb.includes('Yes')) {
                    await t.click(homeOwner.hODwellingDetailsHOEDVMonthsUnoccupied1_Selector.withText('February'));
                }
            }

            if ((data.Dwell_IdentfyMnthsUnoccupid_Mar != "") && (data.hasOwnProperty('Dwell_IdentfyMnthsUnoccupid_Mar'))) {
                console.log(`Identify All Months Unoccupied: March`);
                this.stepAction += "Identify All Months Unoccupied: March <br>";    
                if (data.Dwell_IdentfyMnthsUnoccupid_Mar.includes('Yes')) {
                    await t.click(homeOwner.hODwellingDetailsHOEDVMonthsUnoccupied1_Selector.withText('March'));
                }
            }

            if ((data.Dwell_ProofPrimaryResidence != "") && (data.hasOwnProperty('Dwell_ProofPrimaryResidence'))) {
                console.log(`What Proof of Primary Residence is Available?: ${data.Dwell_ProofPrimaryResidence}`);
                this.stepAction += "'What Proof of Primary Residence is Available?  : " + data.Dwell_ProofPrimaryResidence + "', <br>";
                await selectDropdown(homeOwner.nonPrimaryResidenceInputSetProofOfPrimaryResidence_Selector, data.Dwell_ProofPrimaryResidence);
            }

            if ((data.Dwell_BurglarAlarmType != "") && (data.hasOwnProperty('Dwell_BurglarAlarmType'))) {
                console.log(`Burglar Alarm Type: ${data.Dwell_BurglarAlarmType}`);
                this.stepAction += "'Burglar Alarm Type: " + data.Dwell_BurglarAlarmType + "', <br>";
                await selectDropdown(homeOwner.hODwellingDetailsHOEDVBurglarAlarm_Selector, data.Dwell_BurglarAlarmType);
            }
            console.log(`Fire Alarm Type: ${data.Dwell_FireAlarmType}`);
            this.stepAction += "'Fire Alarm Type: " + data.Dwell_FireAlarmType + "', <br>";
            await selectDropdown(homeOwner.hODwellingDetailsHOEDVFireAlarm_Selector, data.Dwell_FireAlarmType);

            console.log(`Sprinkler System Type: ${data.Dwell_SprinklrSysType}`);
            this.stepAction += "'Sprinkler System Type: " + data.Dwell_SprinklrSysType + "', <br>";
            await selectDropdown(homeOwner.hODwellingDetailsHOEDVSprinklerSystem_Selector, data.Dwell_SprinklrSysType);

            console.log(`Locked Security Gate: ${data.Dwell_LockdSecurtyGate}`);
            this.stepAction += "'Locked Security Gate: " + data.Dwell_LockdSecurtyGate + "', <br>";
            if ((data.Dwell_LockdSecurtyGate != "") && (data.hasOwnProperty('Dwell_LockdSecurtyGate'))) {
                if (data.Dwell_LockdSecurtyGate.includes('Yes')) {
                    await homeOwner.hODwellingDetailsHOEDVSecurityGuard_YesButton.click();
                } else if (data.Dwell_LockdSecurtyGate.includes('No')) {
                    await homeOwner.hODwellingDetailsHOEDVSecurityGuard_NoButton.click();
                }
            }

            console.log(`Security Guard: ${data.Dwell_SecurityGuard}`);
            this.stepAction += "'Security Guard: " + data.Dwell_SecurityGuard + "', <br>";
            if ((data.Dwell_SecurityGuard != "") && (data.hasOwnProperty('Dwell_SecurityGuard'))) {
                if (data.Dwell_SecurityGuard.includes('Yes')) {
                    await homeOwner.hODwellingDetailsHOEDVSecurityGate_YesButton.click();
                } else if (data.Dwell_SecurityGuard.includes('No')) {
                    await homeOwner.hODwellingDetailsHOEDVSecurityGate_NoButton.click();
                }
            }

            console.log(`Is the dwelling under construction or renovation?: ${data.Dwell_IsDwellUndrConstrRenov}`);
            this.stepAction += "'Is the dwelling under construction or renovation?: " + data.Dwell_IsDwellUndrConstrRenov + "', <br>";
            await selectDropdown(homeOwner.hODwellingDetailsHOEDVConstruction_Selector, data.Dwell_IsDwellUndrConstrRenov);

            await captureScreenshot();

            await nextSubmissionWizard.submissionWizardNext.click();

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
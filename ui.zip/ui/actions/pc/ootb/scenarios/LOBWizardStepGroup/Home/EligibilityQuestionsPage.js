import { t } from "testcafe";
import { NextSubmissionWizard } from "../../../../../../pages/gw/generated/policycenter/pages/navigation/submissionWizard/NextSubmissionWizard";
import { NewSubmission } from "../../../../../../pages/gw/generated/policycenter/pages/policy/NewSubmission";
import { captureScreenshot } from "../../../../../../util/common/helper.js";

const newSubmission = new NewSubmission();
const nextSubmissionWizard = new NextSubmissionWizard();

export class EligibilityQuestionsPage {
    constructor() {
        this.pageName = "Eligibility Questions Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await newSubmission.eligibilityQuestionsScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }


    async enterEligibilityQuestionsDetails(fileObj, data) {

        try {
            await this.confirmPageNavigation(fileObj);
            this.stepAction = "Enter Eligibility Questions details as follows: <br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "";
            this.verdict = ""
            console.log(`Entering Eligibility Questions Page...`)

            this.stepAction += "Clicking 'Answer Eligibility Questions' button <br>";

            await newSubmission.SubmissionWizard_AnswerEligibilityQuestions.click();
            await nextSubmissionWizard.submissionWizardNext.click();

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
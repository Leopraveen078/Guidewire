import { t } from "testcafe";
import { Homeowners } from "../../../../../../pages/gw/generated/policycenter/pages/lOBWizardStepGroup/Homeowners.js";
import { AddNewHOExternalInspectorPopup } from "../../../../../../pages/gw/generated/policycenter/pages/popup/Add/AddNewHOExternalInspectorPopup.js";
import { NextSubmissionWizard } from "../../../../../../pages/gw/generated/policycenter/pages/navigation/submissionWizard/NextSubmissionWizard";
import { dateConversion, selectDropdown, captureScreenshot, randomNameGenerator } from "../../../../../../util/common/helper.js";

const nextSubmissionWizard = new NextSubmissionWizard();
const homeOwner = new Homeowners();
const addNewHOExternalInspectorPopup = new AddNewHOExternalInspectorPopup();

export class DwellingConstructionPage {
    constructor() {
        this.pageName = "Dwelling Construction Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await homeOwner.HODwellingConstructionHOEScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async enterDwellingConstructionDetails(fileObj, data) {

        try {
            await this.confirmPageNavigation(fileObj);
            this.stepAction = "Enter Dwelling Construction details as follows:<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "";
            this.verdict = ""
            console.log(`Entering Dwelling Construction Page...`)

            let prod = await homeOwner.jobWizardInfoBar_hOPolicyType.component.innerText;
            console.log(`Product Name - ` + prod)

            if (prod === ('DP-3 D') || prod === ('HO-8') || prod === ('HO-3') || prod === ('DP-1 D')) {
                await t.expect(await homeOwner.hODwellingConstructionDetailsHOEDVNumStories_Label.component.innerText).eql(data.Cov_NumberOfStories);
                console.log("Verified number of stories: " + data.Cov_NumberOfStories)
            } else if (prod === ('MHO-3')) {
                await t.expect(await homeOwner.hODwellingConstructionDetailsHOEDVTotalLivingArea_Label.component.innerText).eql(data.Cov_TotalLivingArea);
                console.log("Verified Total Living areas: " + data.Cov_TotalLivingArea)
            } else {
                if ((data.DC_NumberOfStories != "") && (data.hasOwnProperty('DC_NumberOfStories'))) {
                    console.log(`Number of Stories: ${data.DC_NumberOfStories}`);
                    this.stepAction += "'Number of Stories: " + data.DC_NumberOfStories + "', <br>";
                    await homeOwner.hODwellingConstructionDetailsHOEDVNumStories.setValue(data.DC_NumberOfStories);
                }
            }

            if ((data.DC_FloorUnitsLoctdOn != "") && (data.hasOwnProperty('DC_FloorUnitsLoctdOn'))) {
                console.log(`Floor Unit Located On: ${data.DC_FloorUnitsLoctdOn}`);
                this.stepAction += "'Floor Unit Located On: " + data.DC_FloorUnitsLoctdOn + "', <br>";
                await homeOwner.hODwellingConstructionDetailsHOEDVFloorUnitLocatedOn.setValue(data.DC_FloorUnitsLoctdOn);
            }

            if ((data.DC_NumUnitsInBldg != "") && (data.hasOwnProperty('DC_NumUnitsInBldg'))) {
                console.log(`Number of Units in Building: ${data.DC_NumUnitsInBldg}`);
                this.stepAction += "'Number of Units in Building: " + data.DC_NumUnitsInBldg + "', <br>";
                await homeOwner.hODwellingConstructionDetailsHOEDVNumUnitsBuilding.setValue(data.DC_NumUnitsInBldg);
            }

            if (prod.includes('DP-3 D') || prod.includes('HO-8') || prod === ('HO-3') || prod === ('DP-1 D')) {
                await t.expect(homeOwner.hODwellingConstructionDetailsHOEDVTotalLivingArea_Label.component.innerText).eql(data.Cov_TotalLivingArea);
                console.log("verified total living area: " + data.Cov_TotalLivingArea)
            } else {
                if ((data.DC_TotalLivingArea != "") && (data.hasOwnProperty('DC_TotalLivingArea'))) {
                    console.log(`Total Living Area (sq. ft): ${data.DC_TotalLivingArea}`);
                    this.stepAction += "'Total Living Area (sq. ft): " + data.DC_TotalLivingArea + "', <br>";
                    await homeOwner.hODwellingConstructionDetailsHOEDVTotalLivingArea.setValue(data.DC_TotalLivingArea);
                }
            }

            console.log(`Is the Primary Heat Source portable?: ${data.DC_IsPrimHeatSrcPortabl}`);
            this.stepAction += "'Is the Primary Heat Source portable?: " + data.DC_IsPrimHeatSrcPortabl + "', <br>";
            await homeOwner.hODwellingConstructionDetailsHOEDVPrimarySourceportableNo.click();

            console.log(`Does the Primary Heat Source have an open flame?: ${data.DC_DosPrimHetSrcHvFlame}`);
            this.stepAction += "'Does the Primary Heat Source have an open flame?: " + data.DC_DosPrimHetSrcHvFlame + "', <br>";
            await homeOwner.hODwellingConstructionDetailsHOEDVPrimaryHeatSourceFlameNo.click();

            if (prod.includes('DP-3 D') || prod.includes('HO-8') || prod === ('HO-3')) {
                await t.expect(homeOwner.hODwellingConstructionDetailsHOEDVYearBuilt_Label.component.innerText).eql(data.Cov_YrBuilt);
                console.log("verified year built: " + data.Cov_YrBuilt)
            } else {
                if ((data.DC_YrBuilt != "") && (data.hasOwnProperty('DC_YrBuilt'))) {
                    console.log(`Year Built: ${data.DC_YrBuilt}`);
                    this.stepAction += "'Year Built: " + data.DC_YrBuilt + "', <br>";
                    await homeOwner.hODwellingConstructionDetailsHOEDVYearBuilt.setValue(data.DC_YrBuilt);
                }
            }

            if ((data.DC_ConstrType != "") && (data.hasOwnProperty('DC_ConstrType'))) {
            console.log(`Construction Type: ${data.DC_ConstrType}`);
            this.stepAction += "'Construction Type: " + data.DC_ConstrType + "', <br>";
            await selectDropdown(homeOwner.hODwellingConstructionDetailsHOEDVConstructionType_Selector, data.DC_ConstrType);
            }
            
            if ((data.DC_RoofMaterial != "") && (data.hasOwnProperty('DC_RoofMaterial'))) {
                console.log(`Roof Remaning Useful Life(year): ${data.DC_RoofMaterial}`);
                this.stepAction += "'Roof Remaning Useful Life(year): " + data.DC_RoofMaterial + "', <br>";
                await selectDropdown(homeOwner.hODwellingConstructionDetailsHOEDVRoofMaterial_Selector, data.DC_RoofMaterial);
            }

            if ((data.DC_RoofRemainingLife != "") && (data.hasOwnProperty('DC_RoofRemainingLife'))) {
                console.log(`Roof Remaining Useful Life (years): ${data.DC_RoofRemainingLife}`);
                this.stepAction += "'Roof Remaining Useful Life (years): " + data.DC_RoofRemainingLife + "', <br>";
                await homeOwner.hODwellingConstructionDetailsHOEDVRemainingUsefullLife.setValue(data.DC_RoofRemainingLife);
            }

            if ((data.DC_NumOfUnitsInFirDiv != "") && (data.hasOwnProperty('DC_NumOfUnitsInFirDiv'))) {
                console.log(`Number of Units in Fire Division: ${data.DC_NumOfUnitsInFirDiv}`);
                this.stepAction += "'Number of Units in Fire Division: " + data.DC_NumOfUnitsInFirDiv + "', <br>";
                await selectDropdown(homeOwner.hODwellingConstructionDetailsHOEDVNumberofUnitsFireDivision_Selector, data.DC_NumOfUnitsInFirDiv);
            }

            if ((data.DC_AnyUnaccptblPlumbing != "") && (data.hasOwnProperty('DC_AnyUnaccptblPlumbing'))) {
                console.log(`Any Unacceptable Plumbing: ${data.DC_AnyUnaccptblPlumbing}`);
                this.stepAction += "'Any Unacceptable Plumbing: " + data.DC_AnyUnaccptblPlumbing + "', <br>";
                await selectDropdown(homeOwner.hODwellingConstructionDetailsHOEDVPlumbingType_Selector, data.DC_AnyUnaccptblPlumbing);
            }

            console.log(`Any Hazardous Electrical Wiring: ${data.DC_AnyHzrdousElctrWiring}`);
            this.stepAction += "'Any Hazardous Electrical Wiring: " + data.DC_AnyHzrdousElctrWiring + "', <br>";
            await selectDropdown(homeOwner.hODwellingConstructionDetailsHOEDVHazardouselectricalwiring_Selector, data.DC_AnyHzrdousElctrWiring);

            console.log(`Has the Aluminum Branch wiring been remediated?: ${data.DC_HasAlumBrnchWiringRem}`);
            this.stepAction += "'Has the Aluminum Branch wiring been remediated?: " + data.DC_HasAlumBrnchWiringRem + "', <br>";
            if ((data.DC_HasAlumBrnchWiringRem != "") && (data.hasOwnProperty('DC_HasAlumBrnchWiringRem'))) {
                if (data.DC_HasAlumBrnchWiringRem.includes('Yes')) {
                    await homeOwner.submissionWizardLOBWizardStepGroupHODwellingConstructionPanelSetAluminumBranchwiring_YesButton.click();
                } else if (data.DC_HasAlumBrnchWiringRem.includes('No')) {
                    await homeOwner.submissionWizardLOBWizardStepGroupHODwellingConstructionPanelSetAluminumBranchwiring_NoButton.click();
                }
            }

            console.log(`Electrical Service - Number of Amps: ${data.DC_ElectricServic_NumOfAmp}`);
            this.stepAction += "'Electrical Service - Number of Amps: " + data.DC_ElectricServic_NumOfAmp + "', <br>";
            await selectDropdown(homeOwner.hODwellingConstructionDetailsHOEDVNumberofAmps_Selector, data.DC_ElectricServic_NumOfAmp);

            if ((data.DC_BCEGSGrade != "") && (data.hasOwnProperty('DC_BCEGSGrade'))) {
                console.log(`BCEGS Grade: ${data.DC_BCEGSGrade}`);
                this.stepAction += "'BCEGS Grade: " + data.DC_BCEGSGrade + "', <br>";
                await selectDropdown(homeOwner.hODwellingConstructionDetailsHOEDVBCEGS_Selector, data.DC_BCEGSGrade);
            }

            if ((data.DC_FourPointInspectionDate != "") && (data.hasOwnProperty('DC_FourPointInspectionDate'))) {
                console.log(`Four Point Inspection Date: ${data.DC_FourPointInspectionDate}`);
                let generatedPurcDate = await dateConversion(data.DC_FourPointInspectionDate, '')
                console.log('generated purchased date - ' + generatedPurcDate)
                this.stepAction += "'Four Point Inspection Date: " + generatedPurcDate + "', <br>";
                await homeOwner.hODwellingConstructionDetailsHOEDVFourPointInspectionDate.setValue(generatedPurcDate);
                await t.pressKey('tab');
            }

            await captureScreenshot();
            //click on WLM
            if (await homeOwner.hODwellingConstructionPanelSetWLMTab.component.visible) {
                await homeOwner.hODwellingConstructionPanelSetWLMTab.click();

                if ((data.WLM_RoofCover != "") && (data.hasOwnProperty('WLM_RoofCover'))) {
                    console.log(`Roof Cover: ${data.WLM_RoofCover}`);
                    this.stepAction += "'Roof Cover: " + data.WLM_RoofCover + "', <br>";
                    await selectDropdown(homeOwner.hODwellingConstructionWLMDVMitRoofCoverExt_Selector, data.WLM_RoofCover);
                }

                if ((data.WLM_RoofShape != "") && (data.hasOwnProperty('WLM_RoofShape'))) {
                    console.log(`Roof Shape: ${data.WLM_RoofShape}`);
                    this.stepAction += "'Roof Shape: " + data.WLM_RoofShape + "', <br>";
                    await selectDropdown(homeOwner.hODwellingConstructionWLMDVMitRoofShapeExt_Selector, data.WLM_RoofShape);
                }

                if ((data.WLM_RoofDeckAttchmnt != "") && (data.hasOwnProperty('WLM_RoofDeckAttchmnt'))) {
                    console.log(`Roof Deck Attachment: ${data.WLM_RoofDeckAttchmnt}`);
                    this.stepAction += "'Roof Deck Attachment: " + data.WLM_RoofDeckAttchmnt + "', <br>";
                    await selectDropdown(homeOwner.hODwellingConstructionWLMDVMitRoofDeckAttExt_Selector, data.WLM_RoofDeckAttchmnt);
                }

                if ((data.WLM_RoofWallConnction != "") && (data.hasOwnProperty('WLM_RoofWallConnction'))) {
                    console.log(`Roof Wall Connection: ${data.WLM_RoofWallConnction}`);
                    this.stepAction += "'Roof Deck Attachment: " + data.WLM_RoofWallConnction + "', <br>";
                    await selectDropdown(homeOwner.hODwellingConstructionWLMDVMitRoofWallConnExt, data.WLM_RoofWallConnction);
                }

                if ((data.WLM_SecondryWaterResistence != "") && (data.hasOwnProperty('WLM_SecondryWaterResistence'))) {
                    console.log(`Secondary Water Resistance: ${data.WLM_SecondryWaterResistence}`);
                    this.stepAction += "'Secondary Water Resistance: " + data.WLM_SecondryWaterResistence + "', <br>";
                    await selectDropdown(homeOwner.hODwellingConstructionWLMDVMitSecWaterResExt_Selector, data.WLM_SecondryWaterResistence);
                }

                if ((data.WLM_OpeningProtection != "") && (data.hasOwnProperty('WLM_OpeningProtection'))) {
                    console.log(`Opening Protection: ${data.WLM_OpeningProtection}`);
                    this.stepAction += "'Opening Protection: " + data.WLM_OpeningProtection + "', <br>";
                    await selectDropdown(homeOwner.hODwellingConstructionWLMDVMitOpenProtExt_Selector, data.WLM_OpeningProtection);
                }

                if ((data.WLM_FBCWindSpeed != "") && (data.hasOwnProperty('WLM_FBCWindSpeed'))) {
                    console.log(`FBC Wind Speed: ${data.WLM_FBCWindSpeed}`);
                    this.stepAction += "'FBC Wind Speed: " + data.WLM_FBCWindSpeed + "', <br>";
                    await selectDropdown(homeOwner.hODwellingConstructionWLMDVMitFBCWindSpeedExt_Selector, data.WLM_FBCWindSpeed);
                }

                if ((data.WLM_FBCWindDesign != "") && (data.hasOwnProperty('WLM_FBCWindDesign'))) {
                    console.log(`FBC Wind Design: ${data.WLM_FBCWindDesign}`);
                    this.stepAction += "'FBC Wind Design: " + data.WLM_FBCWindDesign + "', <br>";
                    await selectDropdown(homeOwner.hODwellingConstructionWLMDVMitFBCWindDesignExt_Selector, data.WLM_FBCWindDesign);
                }

                await captureScreenshot();
            }
            //Entering to Mobile Home Tab
            if (prod === ('MHO-3')) {
                console.log(`Entering into Mobile Home screen: ${data.DC_MobileHome_Location}`);
                this.stepAction = "'Entering into Mobile Home screen: " + data.DC_MobileHome_Location + "', <br>";
                await homeOwner.hODwellingConstructionPanelSetMobileHomeTab.click();

                console.log(`Manufacturer: ${data.DC_MobileHome_Location}`);
                this.stepAction += "'Manufacturer: " + data.DC_MobileHome_Location + "', <br>";
                await homeOwner.hODwellingConstructionMHDVManufacturer.setValue(data.DC_MobileHome_Manufacturer);
                await t.pressKey('tab');

                console.log(`Trade Name (Model): ${data.DC_MobileHome_Location}`);
                this.stepAction += "'Trade Name (Model): " + data.DC_MobileHome_Location + "', <br>";
                await homeOwner.hODwellingConstructionMHDVModelID.setValue(data.DC_MobileHome_TradeName);
                await t.pressKey('tab');

                console.log(`Main Section Length (ft.): ${data.DC_MobileHome_Location}`);
                this.stepAction += "'Main Section Length (ft.): " + data.DC_MobileHome_Location + "', <br>";
                await homeOwner.hODwellingConstructionMHDVMobileHomeLength.setValue(data.DC_MobileHome_MainLength);
                await t.pressKey('tab');

                console.log(`Main Section Width (ft.): ${data.DC_MobileHome_Location}`);
                this.stepAction += "'Main Section Width (ft.): " + data.DC_MobileHome_Location + "', <br>";
                await homeOwner.hODwellingConstructionMHDVMobileHomeWidth.setValue(data.DC_MobileHome_MainWidth);
                await t.pressKey('tab');

                console.log(`Serial Number: ${data.DC_MobileHome_Location}`);
                this.stepAction += "'Serial Number: " + data.DC_MobileHome_Location + "', <br>";
                await homeOwner.hODwellingConstructionMHDVMobileHomeSN.setValue(data.DC_MobileHome_MainWidth);
                await t.pressKey('tab');

                console.log(`Mobile Home Installation Date: ${data.DC_MobileHome_Location}`);
                this.stepAction += "'Mobile Home Installation Date: " + data.DC_MobileHome_Location + "', <br>";
                await homeOwner.hODwellingConstructionMHDVMobileHomeSN.setValue(data.DC_MobileHome_MainWidth);
                await t.pressKey('tab');

                console.log(`Mobile Home Installation Date: ${data.DC_MobileHome_InstalDate}`);
                let generatedInstalDate = await dateConversion(data.DC_MobileHome_InstalDate, '')
                console.log('Mobile Home Installation Date - ' + generatedInstalDate)
                this.stepAction += "'Mobile Home Installation Date: " + generatedInstalDate + "', <br>";
                await homeOwner.hODwellingConstructionMHDVMobileHomeInstallationDate.setValue(generatedInstalDate);
                await t.pressKey('tab');

                if ((data.DC_MobileHome_ANSICredit != "") && (data.hasOwnProperty('DC_MobileHome_ANSICredit'))) {
                    console.log(`ANSI/ASCE Credit Apply?: ${data.DC_MobileHome_ANSICredit}`);
                    this.stepAction += "'ANSI/ASCE Credit Apply?: " + data.DC_MobileHome_ANSICredit + "', <br>";
                    if (data.DC_MobileHome_ANSICredit.includes('Yes')) {
                        await homeOwner.hODwellingConstructionMHDVMobileHomeANSIASCE_YesButton.click();
                    } else if (data.DC_MobileHome_ANSICredit.includes('No')) {
                        await homeOwner.hODwellingConstructionMHDVMobileHomeANSIASCE_NoButton.click();
                    }
                }

                if ((data.DC_MobileHome_AccordanceFloridaCode != "") && (data.hasOwnProperty('DC_MobileHome_AccordanceFloridaCode'))) {
                    console.log(`Is the mobile home permanently installed, anchored, and tied down in accordance with Sec. 320.8325, F.S, and Rule 15c-1, Florida Administrative Code?: ${data.DC_MobileHome_ANSICredit}`);
                    this.stepAction += "'Is the mobile home permanently installed, anchored, and tied down in accordance with Sec. 320.8325, F.S, and Rule 15c-1, Florida Administrative Code?: " + data.DC_MobileHome_ANSICredit + "', <br>";
                    if (data.DC_MobileHome_AccordanceFloridaCode.includes('Yes')) {
                        await homeOwner.hODwellingConstructionMHDVMobileHomePermInst_YesButton.click();
                    } else if (data.DC_MobileHome_AccordanceFloridaCode.includes('No')) {
                        await homeOwner.hODwellingConstructionMHDVMobileHomePermInst_NoButton.click();
                    }
                }

                console.log(`Mobile Home Location: ${data.DC_MobileHome_Location}`);
                this.stepAction += "'Mobile Home Location: " + data.DC_MobileHome_Location + "', <br>";
                await selectDropdown(homeOwner.hODwellingConstructionMHDVLocationType_Selector, data.DC_MobileHome_Location)

                await captureScreenshot();
            }


            //click on External Inspection
            await homeOwner.hODwellingConstructionPanelSetBuildingExternalInspectionsTab.click();

            const addExternalInspector = async (inspectionType) => {
                // NewExternalInspection_YesOrNo
                await homeOwner.externalInspectionsLV_tbAddNewInspection.click();

                console.log(`Company Name: ${data.NewExternalInspection_CompanyName}`);
                this.stepAction += "'Company Name: " + data.NewExternalInspection_CompanyName + "', <br>";
                await addNewHOExternalInspectorPopup.addNewHOExternalInspectorPopupInspectorContactScreenPolicyContactInputSetCompanyName.setValue(data.NewExternalInspection_CompanyName);

                console.log(`First Name: ${data.NewExternalInspection_FirstName}`);
                this.stepAction += "'First Name: " + data.NewExternalInspection_FirstName + "', <br>";
                await addNewHOExternalInspectorPopup.addNewHOExternalInspectorPopupInspectorContactScreenPolicyContactInputSetFirstName.setValue(data.NewExternalInspection_FirstName);

                const randomLastName = await randomNameGenerator();
                if (data.hasOwnProperty('NewExternalInspection_LastName') && data.NewExternalInspection_LastName !== "") {
                    data.NewExternalInspection_LastName = `${data.NewExternalInspection_LastName}${randomLastName}`;
                } else {
                    data.NewExternalInspection_LastName = randomLastName;
                }
                console.log(`Last Name: ${data.NewExternalInspection_LastName}`);
                this.stepAction += "'Last Name: " + data.NewExternalInspection_LastName + "', <br>";
                await addNewHOExternalInspectorPopup.addNewHOExternalInspectorPopupInspectorContactScreenPolicyContactInputSetLastName.setValue(data.NewExternalInspection_LastName);

                console.log(`License Type: ${data.NewExternalInspection_LicenseType}`);
                this.stepAction += "'License Type: " + data.NewExternalInspection_LicenseType + "', <br>";
                await selectDropdown(addNewHOExternalInspectorPopup.addNewHOExternalInspectorPopupInspectorContactScreenPolicyContactInputSetLicenseType_Selector, data.NewExternalInspection_LicenseType);

                console.log(`License Number: ${data.NewExternalInspection_LicenseNumber}`);
                this.stepAction += "'License Number: " + data.NewExternalInspection_LicenseNumber + "', <br>";
                await addNewHOExternalInspectorPopup.addNewHOExternalInspectorPopupInspectorContactScreenPolicyContactInputSetLicenseNumber.setValue(data.NewExternalInspection_LicenseNumber);

                console.log(`Work Phone: ${data.NewExternalInspection_WorkPhone}`);
                this.stepAction += "'Work Phone: " + data.NewExternalInspection_WorkPhone + "', <br>";
                await addNewHOExternalInspectorPopup.addNewHOExternalInspectorPopupInspectorContactScreenPolicyContactInputSetWorkPhoneGlobalPhoneInputSetNationalSubscriberNumber.setValue(data.NewExternalInspection_WorkPhone);
                await t.pressKey('tab');
                await t.pressKey('tab');

                console.log(`Inspection Type: ${data.NewExternalInspection_InspectionType}`);
                this.stepAction += "'Inspection Type: " + data.NewExternalInspection_InspectionType + "', <br>";
                await selectDropdown(addNewHOExternalInspectorPopup.inspectorContactScreenInspectionType_Selector, inspectionType);

                console.log(`Inspection Date: ${data.NewExternalInspection_InspectionDate}`);
                this.stepAction += "'Inspection Date: " + data.NewExternalInspection_InspectionDate + "', <br>";
                await addNewHOExternalInspectorPopup.inspectorContactScreenInspectionDate.setValue(await dateConversion(data.NewExternalInspection_InspectionDate, ''));

                await addNewHOExternalInspectorPopup.inspectorContactScreenForceDupCheckUpdate.click();
            };

            if (prod.includes('DP-3 D') || prod.includes('HO-8') || prod === ('HO-3')) {
                // Perform the action with inspection type 'Eligibility' only for MHO-3
                await addExternalInspector('Eligibility');
                await addExternalInspector('WLM');
            } else {
                // For all other products, perform the 'WLM' and possibly 'Eligibility' actions
                await addExternalInspector(data.NewExternalInspection_InspectionType);
            }
            await captureScreenshot();
            await nextSubmissionWizard.submissionWizardNext.click();

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
import { t } from "testcafe";

import { PrefillPopup } from "../../../../../../pages/gw/generated/policycenter/pages/popup/Prefill/PrefillPopup.js";
import { Homeowners } from "../../../../../../pages/gw/generated/policycenter/pages/lOBWizardStepGroup/Homeowners.js";
import { PolicyInfoScreen } from "../../../../../../pages/gw/generated/policycenter/pages/lOBWizardStepGroup/policyInfo/PolicyInfoScreen.js";
import { NextSubmissionWizard } from "../../../../../../pages/gw/generated/policycenter/pages/navigation/submissionWizard/NextSubmissionWizard";
import { selectDropdown, captureScreenshot } from "../../../../../../util/common/helper.js";

const policyInfoScreen =new PolicyInfoScreen();
const prefillPopup =new PrefillPopup();
const homeOwner =new Homeowners();
const nextSubmissionWizard = new NextSubmissionWizard();

export class PropertyAddressPage {
    constructor() {
        this.pageName = "Property Address Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await policyInfoScreen.policyInfoScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async enterPropertyAddressDetails(fileObj, data) {

        try {
            await this.confirmPageNavigation(fileObj);
            this.stepAction = "Enter Property Address details as follows: "
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "";
            this.verdict = ""
            console.log(`Entering Property Address Page...`)

            await policyInfoScreen.hORequestLHRPanelSet_tbRequestLossHistoryReport.click();

            console.log(`Property Information: ${data.L_PropertyInformation}`);
            this.stepAction += "'Property Information: " + data.L_PropertyInformation + "', <br>";
            await selectDropdown(homeOwner.submissionWizardLOBWizardStepGroupLineWizardStepSetHOLocationHOEScreenHOLocationHOEPanelSetLocationDetailDVLocationDetailInputSetTargetedAddressInputSetglobalAddressContainerGlobalAddressInputSetPropertyInfoStatus_Selector, data.L_PropertyInformation);
            await t.wait(5000);
            await prefillPopup.prefillPopupAcceptReturned.click();

            console.log(`Distance from Hydrant (ft.): ${data.L_DistncFromHydrant}`);
            this.stepAction += "'Distance from Hydrant (ft.): " + data.L_DistncFromHydrant + "', <br>";
            await homeOwner.locationPropertyInfoInputSetDisFromHydrant.setValue(data.L_DistncFromHydrant);

            console.log(`Is risk within City Limits: ${data.L_IsRiskWithnCityLimts}`);
            this.stepAction += "'Is risk within City Limits: " + data.L_IsRiskWithnCityLimts + "', <br>";
            if ((data.L_IsRiskWithnCityLimts != "") && (data.hasOwnProperty('L_IsRiskWithnCityLimts'))) {
                if (data.L_IsRiskWithnCityLimts.includes('Yes')) {
                    await homeOwner.locationPropertyInfoInputSetRiskInCityLimits_YesButton.click();
                } else if (data.L_IsRiskWithnCityLimts.includes('No')) {
                    await homeOwner.locationPropertyInfoInputSetRiskInCityLimits_NoButton.click();
                }
            } 
            
            if ((data.L_IsMHMoreThanTwoMiles != "") && (data.hasOwnProperty('L_IsMHMoreThanTwoMiles'))) {
            console.log(`Is the mobilehome more than two miles from open water (including bays, ocean, gulf or Intracoastal Waterway)?: ${data.L_IsMHMoreThanTwoMiles}`);
            this.stepAction += "'Is the mobilehome more than two miles from open water (including bays, ocean, gulf or Intracoastal Waterway)?: " + data.L_IsMHMoreThanTwoMiles + "', <br>";
            await selectDropdown(homeOwner.locationDetailDVMobile2Miles_Selector, data.L_IsMHMoreThanTwoMiles);
            }

            console.log(`Is there a Flood Policy in effect: ${data.L_IsTherFloddPolInEffct}`);
            this.stepAction += "'Is there a Flood Policy in effect: " + data.L_IsTherFloddPolInEffct + "', <br>";
            await selectDropdown(homeOwner.locationDetailDVFloodPolicyInEffect_Selector, data.L_IsTherFloddPolInEffct);

            await nextSubmissionWizard.submissionWizardNext.click();

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}
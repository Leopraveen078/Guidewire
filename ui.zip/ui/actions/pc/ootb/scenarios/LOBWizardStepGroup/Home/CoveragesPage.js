import { t } from "testcafe";
import { NextSubmissionWizard } from "../../../../../../pages/gw/generated/policycenter/pages/navigation/submissionWizard/NextSubmissionWizard";
import { Homeowners } from "../../../../../../pages/gw/generated/policycenter/pages/lOBWizardStepGroup/Homeowners.js";
import { selectDropdown, captureScreenshot } from "../../../../../../util/common/helper.js";
import { RCTCoverages } from "../../../../../../pages/gw/generated/policycenter/pages/policy/RCTCoverages.js";
import { WindowNavigation_Ext } from "../../../../../gw/WindowNavigation_Ext.js"
import { ClientFunction } from 'testcafe';

const nextSubmissionWizard = new NextSubmissionWizard();
const homeOwner = new Homeowners();
const rctCoverages = new RCTCoverages();
const windowNavigation_Ext = new WindowNavigation_Ext();
export class CoveragesPage {
    constructor() {
        this.pageName = "Coverages Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await homeOwner.HOCoveragesHOEScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async enterCoveragesDetails(fileObj, data) {

        try {
            await this.confirmPageNavigation(fileObj);
            this.stepAction = "Enter Coverages details as follows:<br>";
            this.stepER = "Action Step, Verification N/A";
            this.stepAR = "";
            this.verdict = ""
            console.log(`Entering Coverages Page...`);

            let prod = await homeOwner.jobWizardInfoBar_hOPolicyType.component.innerText;
            console.log(`Product Name - ` + prod)

            // let reconstructionCost_rct = 0;

            if (prod === ('DP-3 D') || prod === ('HO-8') || prod === ('HO-3') || prod === ('MHO-3')) {
                console.log(`Click on Calculate Button > enter RCT details and click Finish button..`)
                this.stepAction += "Click on Calculate Button > enter RCT details as below and click Finish button <br>";
                await homeOwner.hOCoverageValuationInputSetGFTButton.click();
                await t.wait(15000);

                await t.maximizeWindow();
                t.ctx.rctWindow = await t.getCurrentWindow();
                await t.switchToWindow(t.ctx.rctWindow)

                // close pop ups on UI
                if (rctCoverages.propertyImage.visible)
                    await t.click(rctCoverages.propertyImage);
                if (rctCoverages.rctAlterts_Close.visible)
                    await t.click(rctCoverages.rctAlterts_Close);
                if (rctCoverages.clickEdit.visible)
                    await t.click(rctCoverages.clickEdit);

                console.log(`Enter Year Built: ${data.Cov_YrBuilt}`);
                this.stepAction += "'Year Built: " + data.Cov_YrBuilt + "', <br>";
                await t.click(rctCoverages.yearBuild_Selector);
                await t.pressKey('ctrl+a');
                await t.pressKey('delete');
                await t.typeText(rctCoverages.yearBuild_Selector, data.Cov_YrBuilt);
                // 2 tab press mandatory
                await t.pressKey('tab')
                await t.pressKey('tab')

                console.log(`Enter Finished Living Area: ${data.Cov_TotalLivingArea}`);
                this.stepAction += "'Finished Living Area: " + data.Cov_TotalLivingArea + "', <br>";
                await t.click(rctCoverages.finishedLivingArea_Selector);
                await t.pressKey('ctrl+a');
                await t.pressKey('delete');
                await t.typeText(rctCoverages.finishedLivingArea_Selector, data.Cov_TotalLivingArea);
                await t.pressKey('shift+tab')
                await t.wait(3000)

                if ((data.Cov_NumberOfFamilies != "") && (data.hasOwnProperty('Cov_NumberOfFamilies'))) {
                    console.log(`Number of Families: ${data.Cov_NumberOfFamilies}`);
                    this.stepAction += "'Number of Families: " + data.Cov_NumberOfFamilies + "', <br>";
                    await t.click(rctCoverages.numberOfFamilies_Selector)
                    if (data.Cov_NumberOfStories === ('1')) {
                        await t.click(rctCoverages.numberOfFamilies_Option_1);
                    } else if (data.Cov_NumberOfStories === ('2')) {
                        await t.click(rctCoverages.numberOfFamilies_Option_2);
                    }
                }

                if ((data.Cov_NumberOfStories != "") && (data.hasOwnProperty('Cov_NumberOfStories'))) {
                    await t.click(rctCoverages.homeStyle);
                    console.log(`Home Style: ${data.Cov_NumberOfStories}`);
                    this.stepAction += "'Home Style: " + data.Cov_NumberOfStories + "', <br>";
                    if (data.Cov_NumberOfStories === ('1')) {
                        await t.click(rctCoverages.rctPageDropdownSelector_1Story);
                    } else if (data.Cov_NumberOfStories === ('2')) {
                        await t.click(rctCoverages.rctPageDropdownSelector_2Story);
                    }
                }

                await captureScreenshot();
                await t.click(rctCoverages.editBuildingInformation_SaveButton);
                await t.wait(5000);
                
                // close popups
                await t.click(rctCoverages.propertyImage);

                this.stepAction += "'Roof Style: " + data.Cov_RoofStyle + "', <br>";
                if ((data.Cov_RoofStyle != "") && (data.hasOwnProperty('Cov_RoofStyle'))) {
                    await t.click(rctCoverages.roofStyle_Selector);
                    await t.click(rctCoverages.roofStyle_Option.withExactText(data.Cov_RoofStyle));
                    await t.wait(2000);
                }

                if (await rctCoverages.valuationTools_CalculateButton.visible) {
                    this.stepAction += "'Click on Calculate Button', <br>";
                    await t.click(rctCoverages.valuationTools_CalculateButton);
                    await t.wait(2000);
                }
                // reconstructionCost_rct = await rctCoverages.reconstructionCostAmount_Selector.innerText;

                await captureScreenshot();
                await t.closeWindow();
                windowNavigation_Ext.switchToPCWindow(fileObj);

                await homeOwner.hOCoverageValuationInputSetGetValuationButton.click();
                await t.wait(5000)

                /*
                let estimatedReplacementCost = "$" + (await homeOwner.hOCoverageValuationInputSetitv360picker_Label.component.innerText);                
                // Verify the estimated amount retrieved from RCT
                if (reconstructionCost_rct === (estimatedReplacementCost)) {
                    console.log("Retrieved EstimatedReplacementCost from RCTExpress successfully")
                } else {
                    throw ("Invalid Cost/Unable to retrieve EstimatedReplacementCost from RCTExpress")
                }
                */
                await captureScreenshot();
            }

            // Check and enter Market Value if applicable
            if ((data.Cov_Valu_MarketValue != "") && (data.hasOwnProperty('Cov_Valu_MarketValue'))) {
                console.log(`Enter Market Value(Excluding Land): ${data.Cov_Valu_MarketValue}`);
                this.stepAction += "'Market Value(Excluding Land): " + data.Cov_Valu_MarketValue + "', <br>";
                await homeOwner.hOCoverageValuationInputSetMarketValueId.setValue(data.Cov_Valu_MarketValue);
                await t.pressKey('tab');
            }

            // Check and enter Purchase Price if applicable
            if ((data.Cov_Valu_PurchasePrice != "") && (data.hasOwnProperty('Cov_Valu_PurchasePrice'))) {
                console.log(`Enter Purchase Price: ${data.Cov_Valu_PurchasePrice}`);
                this.stepAction += "'Purchase Price: " + data.Cov_Valu_PurchasePrice + "', <br>";
                await homeOwner.hOCoverageValuationInputSetPurchasePriceId.setValue(data.Cov_Valu_PurchasePrice);
                await t.pressKey('tab');
            }

            if ((data.Cov_ValuationSource != "") && (data.hasOwnProperty('Cov_ValuationSource'))) {
                console.log(`Enter Valuation Source: ${data.Cov_ValuationSource}`);
                this.stepAction += "'Valuation Source: " + data.Cov_ValuationSource + "', <br>";
                await selectDropdown(homeOwner.hOCoverageValuationInputSetStatedValueSourceId_Selector, data.Cov_ValuationSource);
                await t.pressKey('tab');
            }

            // Check and enter Coverage A - Dwelling if applicable
            if ((data.Cov_PropCov_CovA_Dwelling != "") && (data.hasOwnProperty('Cov_PropCov_CovA_Dwelling'))) {
                console.log(`Enter Coverage A - Dwelling: ${data.Cov_PropCov_CovA_Dwelling}`);
                this.stepAction += "'Coverage A - Dwelling: " + data.Cov_PropCov_CovA_Dwelling + "', <br>";
                await homeOwner.submissionWizardLOBWizardStepGroupLineWizardStepSetHOCoveragesHOEScreenHOMainCoveragesHOEPanelSetPropertyCoveragesPanelRefHOPropertyCovDVHODWCovADwellingTermHOCovDirectTermInputSetDirectTermInput.setValue(data.Cov_PropCov_CovA_Dwelling);
                await t.pressKey('tab');
            }

            // Check and select Coverage B - Other Structures if applicable
            if ((data.Cov_PropCov_CovB_OtherStructure != "") && (data.hasOwnProperty('Cov_PropCov_CovB_OtherStructure'))) {
                console.log(`Select Coverage B - Other Structures: ${data.Cov_PropCov_CovB_OtherStructure}`);
                this.stepAction += "'Coverage B - Other Structures: " + data.Cov_PropCov_CovB_OtherStructure + "', <br>";
                await selectDropdown(homeOwner.hOPropertyCovDVHODWCovBOtherStructures, data.Cov_PropCov_CovB_OtherStructure);
                await t.pressKey('tab');
            }

            // Check and enter Coverage C - Personal Property if applicable
            if ((data.Cov_PropCov_CovC_PersProp != "") && (data.hasOwnProperty('Cov_PropCov_CovC_PersProp'))) {
                console.log(`Enter Coverage C - Personal Property: ${data.Cov_PropCov_CovC_PersProp}`);
                this.stepAction += "'Coverage C - Personal Property: " + data.Cov_PropCov_CovC_PersProp + "', <br>";
                await homeOwner.submissionWizardLOBWizardStepGroupLineWizardStepSetHOCoveragesHOEScreenHOMainCoveragesHOEPanelSetHOProperty2CovDVHODWCovCPersonalPropertyHOCovDirectTermInputSetDirectTermInput.setValue(data.Cov_PropCov_CovC_PersProp);
                await t.pressKey('tab');
            }

            // Check and select Coverage L - Personal Liability if applicable
            if ((data.Cov_LiabCov_CovL_PersLiab != "") && (data.hasOwnProperty('Cov_LiabCov_CovL_PersLiab'))) {
                console.log(`Select Coverage L - Personal Liability: ${data.Cov_LiabCov_CovL_PersLiab}`);
                this.stepAction += "'Coverage L - Personal Liability: " + data.Cov_LiabCov_CovL_PersLiab + "', <br>";
                await selectDropdown(homeOwner.hOCoverageInputSetCovPatternInputGroup0HOCovTermInputSetOptionTermInput, data.Cov_LiabCov_CovL_PersLiab);

            }

            // Check and select Deductibles Hurricane if applicable
            if ((data.Cov_Deduct_Hurricane != "") && (data.hasOwnProperty('Cov_Deduct_Hurricane'))) {
                this.stepAction += "'Deductibles Hurricane: " + data.Cov_Deduct_Hurricane + "', <br>";
                await selectDropdown(homeOwner.hODeductibleCovDVHOLICovHurricanTerm_Selector, data.Cov_Deduct_Hurricane);
                await t.pressKey('tab');
            }

            if ((data.Cov_OthrCov_PerProperRepCost != "") && (data.hasOwnProperty('Cov_OthrCov_PerProperRepCost'))) {
                this.stepAction += "'Personal Property Replacement Cost: " + data.Cov_OthrCov_PerProperRepCost + "', <br>";
                await selectDropdown(homeOwner.hOMainCoveragesHOEPanelSetotherDwellingCoveragesIterator0HOCoverageInputSetCovPatternInputGroup0HOCovTermInputSetOptionTermInput, data.Cov_OthrCov_PerProperRepCost);
                await t.pressKey('tab');
            }

            // Check and Select Sinkhole Loss Coverage
            if ((data.Cov_OthrCov_SinkholLossCov != "") && (data.hasOwnProperty('Cov_OthrCov_SinkholLossCov'))) {
                this.stepAction += "'Sinkhole Loss Coverage: " + data.Cov_OthrCov_SinkholLossCov + "', <br>";
                await selectDropdown(homeOwner.hOMainCoveragesHOEPanelSetotherDwellingCoveragesIterator0HOCoverageInputSetCovPatternInputGroup0HOCovTermInputSetOptionTermInput, data.Cov_OthrCov_SinkholLossCov);
                await t.pressKey('tab');
            }

            // Check and Select Other Sinkhole Loss Coverage
            if ((data.Cov_Seperate_SinkCoverage != "") && (data.hasOwnProperty('Cov_Seperate_SinkCoverage'))) {
                console.log(`Select Do you intend to submit a separate request for Sinkhole Loss Coverage?: ${data.Cov_Seperate_SinkCoverage}`);
                this.stepAction += "'Do you intend to submit a separate request for Sinkhole Loss Coverage?: " + data.Cov_Seperate_SinkCoverage + "', <br>";
                await selectDropdown(homeOwner.hOMainCoveragesHOEPanelSetrequestSinkholeCoverage, data.Cov_Seperate_SinkCoverage);
            }

            await nextSubmissionWizard.submissionWizardNext.click();

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

        } catch (err) {
            this.stepAction = "";
            this.stepER = "";
            this.stepAR = "Error in " + this.pageName;
            this.verdict = "Failed";
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }


}
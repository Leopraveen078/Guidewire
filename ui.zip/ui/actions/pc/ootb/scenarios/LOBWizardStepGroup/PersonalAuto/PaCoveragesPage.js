import { PaCoveragesScreen_Ext } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/PersonalAuto/PaCoveragesScreen_Ext";
import { captureScreenshot } from "../../../../../../util/common/helper.js";
import coveragesPageConstants from "../../Constants/CoveragesPageConstants.js"
import { t } from "testcafe";

const paCoveragesScreen_Ext = new PaCoveragesScreen_Ext();

export class PaCoveragesPage {

    constructor() {
        this.pageName = "PA Coverages Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    //To enter PA coverage details
    async enterPaCoverageDetails(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            this.stepAction = ""
            if ((data.autoLiabilityPackageValue !== "") && (data.hasOwnProperty('autoLiabilityPackageValue'))) {
                this.stepAction = "Enter 'Auto Liability Package' as : " + data.autoLiabilityPackageValue + ". "
                await paCoveragesScreen_Ext.paCoveragesPageAutoLiabilityPackageDropdown.selectOptionByLabel(data.autoLiabilityPackageValue)
            }
            if ((data.medicalLimitValue !== "") && (data.hasOwnProperty('medicalLimitValue'))) {
                this.stepAction = this.stepAction + "Enter 'Medical Limit' as : " + data.medicalLimitValue + ". "
                await t.click(await paCoveragesScreen_Ext.paCoveragesPageOptionTermInputDropdown.withText(coveragesPageConstants.medicalLimit).find('select')).click(await paCoveragesScreen_Ext.paCoveragesPageOptionTermInputDropdown.withText(coveragesPageConstants.medicalLimit).find('option').withText(data.medicalLimitValue));
            }
            if ((data.uninsuredMotoristBILimits !== "") && (data.hasOwnProperty('uninsuredMotoristBILimits'))) {
                this.stepAction = this.stepAction + "Enter 'Uninsured Motorist - BI Limits' as : " + data.uninsuredMotoristBILimits + ". "
                await t.click(await paCoveragesScreen_Ext.paCoveragesPagePackageTermInputDropdown.withText(coveragesPageConstants.uninsuredMotoristBILimits).find('select')).click(await paCoveragesScreen_Ext.paCoveragesPagePackageTermInputDropdown.withText(coveragesPageConstants.uninsuredMotoristBILimits).find('option').withText(data.uninsuredMotoristBILimits));
            }
            if ((data.comprehensiveDeductibleValue !== "") && (data.hasOwnProperty('comprehensiveDeductibleValue'))) {
                this.stepAction = this.stepAction + "Enter 'Comprehensive Deductible' as : " + data.comprehensiveDeductibleValue + ". "
                await t.click(await paCoveragesScreen_Ext.paCoveragesPageOptionTermInputDropdown.withText(coveragesPageConstants.comprehensiveDeductible).find('select')).click(await paCoveragesScreen_Ext.paCoveragesPageOptionTermInputDropdown.withText(coveragesPageConstants.comprehensiveDeductible).find('option').withText(data.comprehensiveDeductibleValue));
            }
            if ((data.collisionDeductibleValue !== "") && (data.hasOwnProperty('collisionDeductibleValue'))) {
                this.stepAction = this.stepAction + "Enter 'Collision Deductible' as : " + data.comprehensiveDeductibleValue + ". "
                await t.click(await paCoveragesScreen_Ext.paCoveragesPageOptionTermInputDropdown.withText(coveragesPageConstants.collisionDeductible).find('select')).click(await paCoveragesScreen_Ext.paCoveragesPageOptionTermInputDropdown.withText(coveragesPageConstants.collisionDeductible).find('option').withText(data.collisionDeductibleValue));
            }
            if ((data.towingAndLaborLimitValue !== "") && (data.hasOwnProperty('towingAndLaborLimitValue'))) {
                this.stepAction = this.stepAction + "Enter 'Towing and Labor Limit' as : " + data.towingAndLaborLimitValue + ". "
                await t.click(await paCoveragesScreen_Ext.paCoveragesPageOptionTermInputDropdown.withText(coveragesPageConstants.towingAndLaborLimit).find('select')).click(await paCoveragesScreen_Ext.paCoveragesPageOptionTermInputDropdown.withText(coveragesPageConstants.towingAndLaborLimit).find('option').withText(data.towingAndLaborLimitValue));
            }
            if ((data.rentalPackageValue !== "") && (data.hasOwnProperty('rentalPackageValue'))) {
                this.stepAction = this.stepAction + "Enter 'Rental Package' as : " + data.rentalPackageValue + ". "
                await t.click(await paCoveragesScreen_Ext.paCoveragesPagePackageTermInputDropdown.withText(coveragesPageConstants.rentalPackage).find('select')).click(await paCoveragesScreen_Ext.paCoveragesPagePackageTermInputDropdown.withText(coveragesPageConstants.rentalPackage).find('option').withText(data.rentalPackageValue));
            }
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            await this.clickNext(fileObj);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async clickNextInPaCoveragesPage(fileObj) {
        try {
            await this.confirmPageNavigation(fileObj);
            await this.clickNext(fileObj);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async clickNext(fileObj) {
        this.stepAction = "Click the Next button from " + this.pageName;
        this.stepER = "Action Step, Verification N/A"
        this.stepAR = ""
        this.verdict = ""
        console.log(`Clicking on Next button ...`)
        await paCoveragesScreen_Ext.paCoveragesPageNextButton.click();
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to " + this.pageName
        if (await paCoveragesScreen_Ext.paCoveragesPageTitle.component.visible) {
            this.stepAR = "Successfully navigated to " + this.pageName
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to " + this.pageName
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async clickNextInPACoveragesPageAndUpdateHTML(fileObj) {
        try {
            this.stepAction = "Click the Next Button in PA Coverages Page";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Clicking on Next Button ...`)
            await paCoveragesScreen_Ext.paCoveragesPageNextButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Clicking Next" + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}

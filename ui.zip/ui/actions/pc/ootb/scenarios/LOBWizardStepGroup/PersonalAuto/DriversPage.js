'use strict';
import { DriversScreen_Ext } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/PersonalAuto/DriversScreen_Ext.js";
import { Selector, t } from "testcafe";
import { captureScreenshot } from "../../../../../../util/common/helper.js";

const driversScreen_ext = new DriversScreen_Ext();

export class DriversPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
        this.pageName = "Drivers Page"
    }

    async updateDriverDetails(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj)
            await this.addUpdateExistingDriverDetails(fileObj, data);
            await this.clickNextInDriversPageAndUpdateHTML(fileObj, data);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async addUpdateExistingDriverDetails(fileObj, data) {
        try {
            if ((data.existingDriverList != "") && (data.hasOwnProperty('existingDriverList'))) {
                for (var i = 0; i < data.existingDriverList.length; i++) {
                    this.stepAction = ""
                    this.stepER = "Action Step, Verification N/A"
                    this.stepAR = ""
                    this.verdict = ""
                    var driversRowCount = await driversScreen_ext.PADriversScreenPADriversPanelSetDriversLV.rowCount();
                    if (driversRowCount > 0) {
                        let existingDriverRow = Selector('div[id*="-PADriversScreen-PADriversPanelSet-DriversListDetailPanel-DriversLV"]').withText(data.existingDriverList[i].driverName).parent('td');
                        if (await existingDriverRow.exists) {
                            console.log(`Select Existing Driver ${data.existingDriverList[i].driverName}`)
                            this.stepAction = `Select the Driver: '${data.existingDriverList[i].driverName}' displayed in the Drivers Table. `
                            var existingDriver = Selector('div[class="gw-value-readonly-wrapper"]').withText(data.existingDriverList[i].driverName);
                            await t.click(existingDriver).wait(1000)
                        }
                    } else {
                        console.log(`Click on Add > Existing Driver > ${data.existingDriverList[i].driverName}`)
                        this.stepAction = "Click on Add > Existing Driver > " + data.existingDriverList[i].driverName
                        this.driverLocator = Selector('div[id*="DriversListDetailPanel-DriversLV_tb-AddDriver-AddExistingContact-"]').withText(data.existingDriverList[i].driverName);
                        await driversScreen_ext.PADriversScreenDriversListDetailPanelDriversLVAddDriverBtn.click()
                        await t.hover(driversScreen_ext.PADriversScreenDriversLVAddDriverAddExistingContact)
                            .click(this.driverLocator);
                    }

                    console.log("Click Contact Details Tab")
                    await driversScreen_ext.PADriversScreenPolicyContactDetailCardTab.click();

                    if ((data.existingDriverList[i].dateOfBirth != "") && (data.existingDriverList[i].hasOwnProperty('dateOfBirth'))) {
                        console.log(`Enter the Date of Birth: ${data.existingDriverList[i].dateOfBirth}...`)
                        this.stepAction = this.stepAction + ", 'Date of Birth' as " + data.existingDriverList[i].dateOfBirth
                        await driversScreen_ext.PADriversScreenPolicyContactRoleNameInputSetDateOfBirth.setValue(data.existingDriverList[i].dateOfBirth);
                        await t.pressKey('tab');
                    }

                    if ((data.existingDriverList[i].maritalStatus != "") && (data.existingDriverList[i].hasOwnProperty('maritalStatus'))) {
                        console.log(`Select Marital Status  :${data.existingDriverList[i].maritalStatus}...`)
                        this.stepAction = this.stepAction + " Enter 'Marital Status' as " + data.existingDriverList[i].maritalStatus + ", "
                        await driversScreen_ext.PADriversScreenPolicyContactRoleInputSetNameMaritalStatusType.selectOptionByLabel(data.existingDriverList[i].maritalStatus);
                        await t.pressKey('tab');
                    }

                    if ((data.existingDriverList[i].licenseNumber != "") && (data.existingDriverList[i].hasOwnProperty('licenseNumber'))) {
                        console.log(`Enter the License Number: ${data.existingDriverList[i].licenseNumber}...`)
                        this.stepAction = this.stepAction + ", 'License Number' as " + data.existingDriverList[i].licenseNumber
                        await driversScreen_ext.PADriversScreenPolicyContactDetailsDVLicenseNumberInput.setValue(data.existingDriverList[i].licenseNumber);
                        await t.pressKey('tab');
                    }

                    if ((data.existingDriverList[i].licenseState != "") && (data.existingDriverList[i].hasOwnProperty('licenseState'))) {
                        console.log(`Enter the License State: ${data.existingDriverList[i].licenseState}...`)
                        this.stepAction = this.stepAction + ", 'License State' as " + data.existingDriverList[i].licenseState
                        await driversScreen_ext.PADriversScreenPolicyContactDetailsDVLicenseStateType.selectOptionByLabel(data.existingDriverList[i].licenseState);
                        await t.pressKey('tab');
                    }

                    console.log("Clicking on the Roles Tab")
                    this.stepAction = this.stepAction + ". Click on Roles Tab. "
                    await driversScreen_ext.PADriversScreenDriverDetailsCVRolesCardTab.click();

                    if ((data.existingDriverList[i].yearFirstLicensed != "") && (data.existingDriverList[i].hasOwnProperty('yearFirstLicensed'))) {
                        console.log(`Enter the Year First Licensed: ${data.existingDriverList[i].yearFirstLicensed}...`)
                        this.stepAction = this.stepAction + "Enter the 'Year First Licensed' as " + data.existingDriverList[i].yearFirstLicensed
                        await driversScreen_ext.PADriversScreenPolicyDriverInfoDVYearlicensedInput.setValue(data.existingDriverList[i].yearFirstLicensed);
                        await t.pressKey('tab');
                    }

                    if ((data.existingDriverList[i].numberOfAccidentsPolicyLevel != "") && (data.existingDriverList[i].hasOwnProperty('numberOfAccidentsPolicyLevel'))) {
                        console.log(`Enter the number Of Accidents PolicyLevel: ${data.existingDriverList[i].numberOfAccidentsPolicyLevel}...`)
                        this.stepAction = this.stepAction + ", 'Number Of Accidents PolicyLevel' as " + data.existingDriverList[i].numberOfAccidentsPolicyLevel
                        await driversScreen_ext.PADriversScreenPolicyContactRolePanelSetPolicyDriverNumberOfAccidentsType.selectOptionByLabel(data.existingDriverList[i].numberOfAccidentsPolicyLevel);
                        await t.pressKey('tab');
                    }
                    if ((data.existingDriverList[i].numberOfAccidentsAccountLevel != "") && (data.existingDriverList[i].hasOwnProperty('numberOfAccidentsAccountLevel'))) {
                        console.log(`Enter the number Of Accidents AccountLevel: ${data.existingDriverList[i].numberOfAccidentsAccountLevel}...`)
                        this.stepAction = this.stepAction + ", 'Number Of Accidents AccountLevel' as " + data.existingDriverList[i].numberOfAccidentsAccountLevel
                        await driversScreen_ext.PADriversScreenPolicyContactRolePanelSetDriverNumberOfAccidentsType.selectOptionByLabel(data.existingDriverList[i].numberOfAccidentsAccountLevel);
                        await t.pressKey('tab');
                    }
                    if ((data.existingDriverList[i].numberOfViolationsPolicyLevel != "") && (data.existingDriverList[i].hasOwnProperty('numberOfViolationsPolicyLevel'))) {
                        console.log(`Enter the number Of Violations PolicyLevel: ${data.existingDriverList[i].numberOfViolationsPolicyLevel}...`)
                        this.stepAction = this.stepAction + ", 'Number Of Violations PolicyLevel' as " + data.existingDriverList[i].numberOfViolationsPolicyLevel
                        await driversScreen_ext.PADriversScreenPolicyContactRolePanelSetPolicyDriverNumberOfViolationsType.selectOptionByLabel(data.existingDriverList[i].numberOfViolationsPolicyLevel);
                        await t.pressKey('tab');
                    }
                    if ((data.existingDriverList[i].numberOfViolationAccountLevel != "") && (data.existingDriverList[i].hasOwnProperty('numberOfViolationAccountLevel'))) {
                        console.log(`Enter the number Of Violation AccountLevel: ${data.existingDriverList[i].numberOfViolationAccountLevel}...`)
                        this.stepAction = this.stepAction + ", 'Number Of Violation AccountLevel' as " + data.existingDriverList[i].numberOfViolationAccountLevel
                        await driversScreen_ext.PADriversScreenPolicyContactRolePanelSetDriverNumberOfViolationsType.selectOptionByLabel(data.existingDriverList[i].numberOfViolationAccountLevel);
                        await t.pressKey('tab');
                    }
                    await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
                }
            }
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Updating Contact" + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async addExistingDriverDetails(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj)
            if ((data.existingDriverList != "") && (data.hasOwnProperty('existingDriverList'))) {
                this.stepER = "Action Step, Verification N/A"
                this.stepAR = ""
                this.verdict = ""
                for (var i = 0; i < data.existingDriverList.length; i++) {
                    await driversScreen_ext.PADriversScreenDriversListDetailPanelDriversLVAddDriverBtn.click()
                    await t.hover(driversScreen_ext.PADriversScreenDriversLVAddDriverAddExistingContact)
                    this.stepAction = "Click on Add > Existing Driver > "
                    this.driverLocator = `div[id*="UnassignedDriver"]`
                    let drivername = await Selector(this.driverLocator.replace('${i}', i)).innerText;
                    console.log("Info " + drivername)
                    if (data.existingDriverList[i].driverName == drivername) {
                        this.stepAction = this.stepAction + drivername
                        await t.click(this.driverLocator.replace('${i}', i));

                        console.log("Click Contact Details Tab")
                        await driversScreen_ext.PADriversScreenPolicyContactDetailCardTab.click();

                        if ((data.existingDriverList[i].maritalStatus != "") && (data.existingDriverList[i].hasOwnProperty('maritalStatus'))) {
                            console.log(`Select Marital Status  :${data.existingDriverList[i].maritalStatus}...`)
                            this.stepAction = this.stepAction + " Enter 'Marital Status' as " + data.existingDriverList[i].maritalStatus
                            await driversScreen_ext.PADriversScreenPolicyContactRoleInputSetNameMaritalStatusType.selectOptionByLabel(data.existingDriverList[i].maritalStatus);
                        }
                        if ((data.existingDriverList[i].licenseNumber != "") && (data.existingDriverList[i].hasOwnProperty('licenseNumber'))) {
                            console.log(`Enter the License Number: ${data.existingDriverList[i].licenseNumber}...`)
                            this.stepAction = this.stepAction + ", 'License Number' as " + data.existingDriverList[i].licenseNumber
                            await driversScreen_ext.PADriversScreenPolicyContactDetailsDVLicenseNumberInput.setValue(data.existingDriverList[i].licenseNumber);
                            await t.pressKey('tab');

                        }
                        if ((data.existingDriverList[i].licenseState != "") && (data.existingDriverList[i].hasOwnProperty('licenseState'))) {
                            console.log(`Enter the License State: ${data.existingDriverList[i].licenseState}...`)
                            this.stepAction = this.stepAction + ", 'License State' as " + data.existingDriverList[i].licenseState
                            await driversScreen_ext.PADriversScreenPolicyContactDetailsDVLicenseStateType.selectOptionByLabel(data.existingDriverList[i].licenseState);
                            await t.pressKey('tab');

                        }
                        console.log("Clicking on the Roles Tab")
                        this.stepAction = this.stepAction + ". Click on Roles Tab."
                        await driversScreen_ext.PADriversScreenDriverDetailsCVRolesCardTab.click();
                        await t.wait(1000);

                        if ((data.existingDriverList[i].yearFirstLicensed != "") && (data.existingDriverList[i].hasOwnProperty('yearFirstLicensed'))) {
                            console.log(`Enter the Year First Licensed: ${data.existingDriverList[i].yearFirstLicensed}...`)
                            this.stepAction = this.stepAction + "Enter 'Year First Licensed' as " + data.existingDriverList[i].yearFirstLicensed
                            await driversScreen_ext.yearFirstLicensed.setValue(data.existingDriverList[i].yearFirstLicensed);
                        }
                    }
                    await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
                }
            }
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            this.stepAction = "Click the Next Button in " + this.pageName
            await driversScreen_ext.nextButton.click();
            await t.wait(7000);
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the Drivers Page"
        await driversScreen_ext.PADriversScreenTitleBar.component.visible;
        if (await driversScreen_ext.PADriversScreenTitleBar.component.exists) {
            this.stepAR = "Successfully navigated to the Drivers Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the Drivers Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async assertValuesAndUpdateHTML(fieldName, valueFromUI, valueToBeChecked, fileObj) {
        console.log("Value from UI: " + valueFromUI);
        console.log("Value to be checked: " + valueToBeChecked);
        if (valueFromUI == valueToBeChecked) {
            console.log("AS EXPECTED, '" + fieldName + "' is matched with the expected: " + valueFromUI);
            this.stepAR = `AS EXPECTED, '${fieldName}' is matched with the expected: ${valueFromUI}`
            this.verdict = "Passed"
        } else {
            console.log("NOT AS EXPECTED, '" + fieldName + "' is NOT matching with the expected: " + valueToBeChecked + ", and available as: " + valueFromUI);
            this.stepAR = `NOT AS EXPECTED, '${fieldName}' is NOT matching with the expected: ${valueToBeChecked}, and available as: ${valueFromUI}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async clickNextInDriversPageAndUpdateHTML(fileObj) {
        try {
            this.stepAction = "Click the Next Button in " + this.pageName;
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Clicking on Next Button ...`)
            await driversScreen_ext.nextButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Clicking Next" + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async gotoDriversPageAndEditPolicyTransaction(fileObj) {
        try {
            this.stepAction = "Go to Drivers Page and Edit Policy Transaction";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Navigating to Drivers Page from Wizard ...`)
            await driversScreen_ext.PADriverScreenWizardPADriversButton.click();
            console.log(`Clicking Edit Policy Transaction Button ...`)
            if (!await driversScreen_ext.PADriversScreenPolicyWorkflowButton.component.visible) {
                await driversScreen_ext.prevButton.click();
            }
            await driversScreen_ext.PADriversScreenPolicyWorkflowButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in clicking Edit Policy Transaction" + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async selectRadioOption(question, optionValue) {
        console.log(`Entering selectRadioOption method...`)
        const radioButtonOptionField = Selector('div').withText(question).nextSibling(0).find('span').withText(optionValue).prevSibling(0).find('input');
        if (await radioButtonOptionField.exists) {
            console.log(`Select ` + question + ` as - ` + optionValue)
            await t.click(radioButtonOptionField).wait(1500);
        }
    }

    async enterInputValue(question, value) {
        var textField = Selector('div[class="gw-label"]').withText(question).parent('div').find('input[type="text"]');
        if (await textField.exists) {
            console.log(`Enter ${question} as ${value}`)
            await t.typeText(textField, value, { replace: true }).wait(2000);
        }
    }
}

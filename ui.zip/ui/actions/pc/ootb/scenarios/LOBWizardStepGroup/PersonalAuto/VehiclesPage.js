import { VehicleScreen_Ext } from "../../../../../../pages/gw/ScenarioPages/LOBWizardStepGroup/PersonalAuto/VehicleScreen_Ext";
import { t } from "testcafe";
import { captureScreenshot } from "../../../../../../util/common/helper";

const vehicleScreen_Ext = new VehicleScreen_Ext();

export class VehiclesPage {
    constructor() {

        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
        this.pageName = "Vehicles Page"
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the Vehicles Page"
        if (await vehicleScreen_Ext.vehiclesPageTitle.component.visible) {
            this.stepAR = "Successfully navigated to the Vehicles Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the Vehicles Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async addNewVehicle(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);
            await this.createNewVehicle(fileObj, data)
            console.log("Click the Next Button in " + this.pageName + "");
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            this.stepAction = "Click the Next Button in " + this.pageName
            await vehicleScreen_Ext.vehiclesPageNextButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        }
        catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async createNewVehicle(fileObj, data) {
        try {
            for (var i = 0; i < data.vehiclesList.length; i++) {
                if ((data.vehiclesList[i].selectExistingVehicle != "") && (data.vehiclesList[i].hasOwnProperty('selectExistingVehicle'))) {
                    console.log("Select the Existing Vehicle")
                    this.stepAction = "Select the Existing Vehicle. "
                } else {
                    this.stepAction = "Click on Create Vehicle. "
                    await vehicleScreen_Ext.vehiclesPageCreateVehicleButton.click();
                    await t.wait(2000);
                }

                this.stepER = "Action Step, Verification N/A"
                this.stepAR = ""
                this.verdict = ""

                if ((data.vehiclesList[i].vehicleType != "") && (data.vehiclesList[i].hasOwnProperty('vehicleType'))) {
                    console.log("Vehicle Type  :" + data.vehiclesList[i].vehicleType + "...")
                    this.stepAction = this.stepAction + ", 'Vehicle Type' as " + data.vehiclesList[i].vehicleType
                    await vehicleScreen_Ext.vehiclesPageVehicleTypeDropDown.selectOptionByLabel(data.vehiclesList[i].vehicleType);
                    await t.pressKey('tab')
                }

                if ((data.vehiclesList[i].vin != "") && (data.vehiclesList[i].hasOwnProperty('vin'))) {
                    console.log("VIN :" + data.vehiclesList[i].vin + "...")
                    this.stepAction = this.stepAction + ", 'VIN' as " + data.vehiclesList[i].vin
                    await vehicleScreen_Ext.vehiclesPageVehicleVINTextInput.setValue(data.vehiclesList[i].vin);
                    await t.pressKey('tab')
                }

                if ((data.vehiclesList[i].modelYear != "") && (data.vehiclesList[i].hasOwnProperty('modelYear'))) {
                    this.stepAction = this.stepAction + ", 'Model Year' as " + data.vehiclesList[i].modelYear
                    await vehicleScreen_Ext.vehiclesPageVehicleModelYearText.setValue(data.vehiclesList[i].modelYear);
                    await t.pressKey('tab')
                }

                if ((data.vehiclesList[i].make != "") && (data.vehiclesList[i].hasOwnProperty('make'))) {
                    this.stepAction = this.stepAction + ", 'Make' as " + data.vehiclesList[i].make
                    await vehicleScreen_Ext.vehiclesPageVehicleMakeText.setValue(data.vehiclesList[i].make);
                    await t.pressKey('tab')
                }

                if ((data.vehiclesList[i].model != "") && (data.vehiclesList[i].hasOwnProperty('model'))) {
                    this.stepAction = this.stepAction + ", 'Model' as " + data.vehiclesList[i].model
                    await vehicleScreen_Ext.vehiclesPageVehicleModelText.setValue(data.vehiclesList[i].model);
                    await t.pressKey('tab');
                }

                if ((data.vehiclesList[i].bodyType != "") && (data.vehiclesList[i].hasOwnProperty('bodyType'))) {
                    this.stepAction = this.stepAction + ", 'Body Type' as " + data.vehiclesList[i].bodyType
                    await vehicleScreen_Ext.vehiclesPageVehicleBodyTypeDropDown.selectOptionByLabel(data.vehiclesList[i].bodyType);
                    await t.pressKey('tab');
                }

                if ((data.vehiclesList[i].licenseState != "") && (data.vehiclesList[i].hasOwnProperty('licenseState'))) {
                    this.stepAction = this.stepAction + ", 'License State' as " + data.vehiclesList[i].licenseState
                    await vehicleScreen_Ext.personalAuto_VehicleDVLicenseState_DV.selectOptionByLabel(data.vehiclesList[i].licenseState);
                    await t.pressKey('tab');
                }

                if ((data.vehiclesList[i].vehicleGaragedAt != "") && (data.vehiclesList[i].hasOwnProperty('vehicleGaragedAt'))) {
                    console.log("Where is this vehicle Garaged At? :" + data.vehiclesList[i].vehicleGaraged + "...")
                    this.stepAction = this.stepAction + ", 'Where is this vehicle Garaged At?' as " + data.vehiclesList[i].vehicleGaragedAt
                    await vehicleScreen_Ext.vehiclesPageVehicleGarageAtDropdown.selectOptionByLabel(data.vehiclesList[i].vehicleGaragedAt);
                    await t.pressKey('tab');
                }

                if ((data.vehiclesList[i].costNew != "") && (data.vehiclesList[i].hasOwnProperty('costNew'))) {
                    console.log("Cost New :" + data.vehiclesList[i].costNew + "...")
                    this.stepAction = this.stepAction + ", 'Cost New' as " + data.vehiclesList[i].costNew
                    await vehicleScreen_Ext.vehiclesPageVehicleCostNewText.setValue(data.vehiclesList[i].costNew);
                    await t.pressKey('tab')
                }

                if ((data.vehiclesList[i].value != "") && (data.vehiclesList[i].hasOwnProperty('value'))) {
                    this.stepAction = this.stepAction + ", 'Value' as " + data.vehiclesList[i].value
                    await vehicleScreen_Ext.vehiclesPageVehicleStatedValue.setValue(data.vehiclesList[i].value);
                    await t.pressKey('tab');
                }

                if ((data.vehiclesList[i].annualMileage != "") && (data.vehiclesList[i].hasOwnProperty('annualMileage'))) {
                    console.log("Annual Mileage:" + data.vehiclesList[i].annualMileage + "...")
                    this.stepAction = this.stepAction + ", 'Annual Mileage' as " + data.vehiclesList[i].annualMileage
                    await vehicleScreen_Ext.vehiclesPageVehicleAnnualMileageText.setValue(data.vehiclesList[i].annualMileage);
                }
                if ((data.vehiclesList[i].vehicleUsedFor != "") && (data.vehiclesList[i].hasOwnProperty('vehicleUsedFor'))) {
                    console.log("How do you use this vehicle? :" + data.vehiclesList[i].vehicleUsedFor + "...")
                    this.stepAction = this.stepAction + ", 'How do you use this vehicle?' as " + data.vehiclesList[i].vehicleUsedFor
                    await vehicleScreen_Ext.vehiclesPageVehiclePrimaryUseDropDown.selectOptionByLabel(data.vehiclesList[i].vehicleUsedFor);
                    await t.wait(2000);
                }

                if ((data.vehiclesList[i].driver != "") && (data.vehiclesList[i].hasOwnProperty('driver'))) {
                    console.log("Assign driver " + data.vehiclesList[i].driver + " to " + data.vehiclesList[i].vin)
                    this.stepAction = this.stepAction + ", Assign driver " + data.vehiclesList[i].driver
                    await vehicleScreen_Ext.vehiclesPageAddAssignedDriverButton.click();
                    await t.click(vehicleScreen_Ext.vehiclesPageAssignedDriverMenu.component.withText(data.vehiclesList[i].driver));
                    await t.pressKey('tab')
                }

                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            }
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async clickNextAndUpdateHtml(fileObj) {
        try {
            this.stepAction = "Click the Next Button in Vehicles Page";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""
            console.log(`Clicking on Next Button ...`)
            await vehicleScreen_Ext.vehiclesPageNextButton.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in Clicking Next in Vehicles Page"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    
    //Delete all vehicles - Implemented here to use globally
    async removeAllVehicles(fileObj) {
        if (await vehicleScreen_Ext.vehicleList.component.exists) {
            var vehicleRowCount = await vehicleScreen_Ext.vehicleList.rowCount();
            console.log("Vehicle Count: " + vehicleRowCount)
        }
        if (vehicleRowCount > 0) {
            console.log("Select all Vehicle checkbox")
            await vehicleScreen_Ext.vehiclesLVSelectAllCheckbox.click();
            if (await vehicleScreen_Ext.vehiclesLVRemoveButton.component.exists) {
                this.stepER = "Action Step, Verification N/A"
                this.stepAR = ""
                this.verdict = ""
                this.stepAction = "Delete all Existing vehicles in " + this.pageName
                console.log("Select Remove Vehicle")
                await vehicleScreen_Ext.vehiclesLVRemoveButton.click();
                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            }
        }
    }
}

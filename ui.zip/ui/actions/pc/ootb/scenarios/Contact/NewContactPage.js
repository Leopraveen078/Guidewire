import { ContactTabBar } from "../../../../../pages/gw/generated/policycenter/pages/navigation/tabBar/ContactTabBar";
import { t } from "testcafe";
import { captureScreenshot } from "../../../../../util/common/helper";

const contactTabBar = new ContactTabBar();

export class NewContactPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = "Verify that you are taken to the New Contact Page"
        if (await contactTabBar.newContactScreenTitleBar.component.visible) {
            this.stepAR = "Successfully navigated to the New Contact Page"
            this.verdict = "Passed"
        } else {
            this.stepAR = "NOT able to navigate to the New Contact Page"
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    async createNewContact(fileobj, data) {
        try {
            if (data.newContact != "") {
                for (let i = 0; i < data.newContact.length; i++) {
                    //creating Company contact
                    if ((data.newContact[i].type != "") && (data.newContact[i].hasOwnProperty('type'))) {
                        if (data.newContact[i].type == "Company") {
                            console.log("Company contact")
                            this.stepAction = "Click Contact Tab from info bar and then Click New Company"
                            this.stepER = "Action step, Verification N/A"
                            this.stepAR = ""
                            this.verdict = ""
                            await this.selectContactTabNewContactNewCompany();
                            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

                            await this.confirmPageNavigation(fileobj);

                            this.stepAction = "Creating " + data.newContact[i].type + " Contact with"
                            this.stepER = "Action step, Verification N/A"
                            this.stepAR = ""
                            this.verdict = ""

                            if ((data.newContact[i].name != "") && (data.newContact[i].hasOwnProperty('name'))) {
                                console.log(" Creating Company with Name: " + data.newContact[i].name)
                                await newContact.newContactContactPanelSetContactCVContactDVContactNameInputSetGlobalContactNameInputSetName.setValue(data.newContact[i].name);
                                this.stepAction = this.stepAction + " , Name as ' " + data.newContact[i].name + "'"
                            }
                            if ((data.newContact[i].taxId != "") && (data.newContact[i].hasOwnProperty('taxId'))) {
                                console.log(" Creating contact with Tax ID: " + data.newContact[i].taxId)
                                await newContact.newContactContactPanelSetContactCVContactDVOfficialIDInputSetOfficialIDDV_Input.setValue(data.newContact[i].taxId);
                                this.stepAction = this.stepAction + ", tax ID as ' " + data.newContact[i].taxId + "'"
                            }
                        }
                        else if (data.newContact[i].type == "Person") {
                            console.log("Person contact")
                            this.stepAction = "Click Contact Tab from info bar and then Click New Person"
                            this.stepER = "Action step, Verification N/A"
                            this.stepAR = ""
                            this.verdict = ""
                            await this.selectContactTabNewContactNewPerson();
                            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

                            await this.confirmPageNavigation(fileobj);

                            this.stepAction = "Creating " + data.newContact[i].type + " Contact with"
                            this.stepER = "Action step, Verification N/A"
                            this.stepAR = ""
                            this.verdict = ""

                            if ((data.newContact[i].firstName != "") && (data.newContact[i].hasOwnProperty('firstName'))) {
                                console.log(" Creating Person with FirstName: " + data.newContact[i].firstName)
                                await newContact.newContactContactPanelSetContactCVContactDVContactNameInputSetGlobalPersonNameInputSetFirstName.setValue(data.newContact[i].firstName);
                                this.stepAction = this.stepAction + ", First Name as ' " + data.newContact[i].firstName + "'"
                            }
                            if ((data.newContact[i].lastName != "") && (data.newContact[i].hasOwnProperty('lastName'))) {
                                console.log(" Creating Person with LastName: " + data.newContact[i].lastName)
                                await newContact.newContactContactPanelSetContactCVContactDVContactNameInputSetGlobalPersonNameInputSetLastName.setValue(data.newContact[i].lastName);
                                this.stepAction = this.stepAction + ", Last Name as ' " + data.newContact[i].lastName + "'"
                            }
                            if ((data.newContact[i].taxId != "") && (data.newContact[i].hasOwnProperty('taxId'))) {
                                console.log(" Creating contact with Tax ID: " + data.newContact[i].taxId)
                                this.stepAction = this.stepAction + ", tax ID as ' " + data.newContact[i].taxId + "'"
                                await newContact.newContactContactPanelSetContactCVContactDVOfficialIDInputSetOfficialIDDV_Input.setValue(data.newContact[i].taxId);
                            }
                        }
                    }

                    //common fields                    
                    if ((data.addressLine1 != "") && (data.hasOwnProperty('addressLine1'))) {
                        console.log(" Creating contact with address: " + data.addressLine1)
                        await newContact.newContactContactPanelSetContactCVContactDVAddressInputSetglobalAddressContainerGlobalAddressInputSetAddressLine1.setValue(data.addressLine1);
                        this.stepAction = this.stepAction + ", address as ' " + data.addressLine1 + "'"
                    }

                    if ((data.city != "") && (data.hasOwnProperty('city'))) {
                        console.log(" Creating contact with city: " + data.city)
                        await newContact.newContactContactPanelSetContactCVContactDVAddressInputSetglobalAddressContainerGlobalAddressInputSetCity.setValue(data.city);
                        this.stepAction = this.stepAction + ", city as ' " + data.city + "'"
                        await t.pressKey('tab'); // trigger post on change
                    }

                    if ((data.state != "") && (data.hasOwnProperty('state'))) {
                        console.log(" Creating contact with state: " + data.state)
                        await newContact.newContactContactPanelSetContactCVContactDVAddressInputSetglobalAddressContainerGlobalAddressInputSetState.selectOptionByValue(data.state);
                        this.stepAction = this.stepAction + ", state as ' " + data.state + "'"
                    }

                    if ((data.addressType != "") && (data.hasOwnProperty('addressType'))) {
                        console.log(" addressType: " + data.addressType)
                        await newContact.contactDVAddressType.selectOptionByLabel(data.addressType);
                        this.stepAction = this.stepAction + ", addressType as ' " + data.addressType + "'"
                    }

                    await newContact.newContactUpdate.click();

                    this.stepAction = this.stepAction + " and Click  New Contact Update button"

                    await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
                }
            }
        }
        catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileobj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async openTabBarContactTabMenuItem() {
        !await contactTabBar.tabBarContactTab.component.hasClass('gw-hasOpenSubMenu') && await t.click(contactTabBar.tabBarContactTab.component.find('div.gw-action--expand-button'));
    }

    async selectContactTabNewContactNewCompany() {
        await this.openTabBarContactTabMenuItem();
        await t.hover(contactTabBar.contactTabNewContact.component)
        await contactTabBar.newContactNewCompany.click();
    }

    async selectContactTabNewContactNewPerson() {
        await this.openTabBarContactTabMenuItem();
        await t.hover(contactTabBar.contactTabNewContact.component)
        await contactTabBar.newContactNewPerson.click();
    }


}
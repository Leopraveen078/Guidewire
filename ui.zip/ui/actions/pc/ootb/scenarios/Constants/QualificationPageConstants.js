const QualificationPageConstants = {
     // Payment Protection Insurance Pre-Qualification Questions
     insuranceVoidedOrRefusedOrCancelledQuestion : "Have you or any other person who may benefit from this insurance ever had insurance voided, refused, cancelled, renewal not offered, special conditions imposed or a claim refused?",
     policyEngagedInFixedTermQuestion : "Are you or any other person to be covered by this policy engaged in fixed term, casual, intermittent or seasonal employment?",
     bloodPressureHeartTroubleDiabetesQuestion : "Have you or any other person to be covered by this policy ever received medical or other advice for: Blood pressure, heart trouble, diabetes, tumour, cancer, mental or nervous disorders, kidney or liver disease, blood disorder, asthma or lung disease, epilepsy, HIV infection or AIDS?",
     healthIssuesInjuryOrIllnessQuestion : "Are you or any other person to be covered by the policy presently aware of any health issues, injury or illness that could lead to becoming disabled or not able to work for a period of seven days or more?",
     vehicleBeUsedForTheBusinessQuestion : "Will the vehicle be used for the business of courier, delivery, security or rental or to carry passengers for fare or reward?",
     applicantInsurancePolicyDeclinedQuestion : "In the last 3 years has the applicant had an insurance policy or coverage declined, cancelled or non-renewed?"
}
export default QualificationPageConstants

const coveragesPageConstants = {
     // Personal Auto Coverages
     medicalLimit : "Medical Limit",
     uninsuredMotoristBILimits : "Uninsured Motorist - BI Limits",
     comprehensiveDeductible : "Comprehensive Deductible",
     collisionDeductible : "Collision Deductible",
     towingAndLaborLimit : "Towing and Labor Limit",
     rentalPackage : "Rental Package",

     //Homeowners Coverages
     lossOfRentalIncone : "Loss of Rental Income",
     windstormOrHail : "Windstorm or Hail"
}
export default coveragesPageConstants

import { PcfComponent } from '@gtui/gt-ui-framework';
import {UWBlockProgressIssuesPopup} from "../../../../../pages/gw/generated/policycenter/pages/popup/UWBlock/UWBlockProgressIssuesPopup";


export class UWBlockProgressIssuesPopup_Ext extends UWBlockProgressIssuesPopup {
    UWBlockProgressIssuesPopupUnderwriterIssuesTitle = PcfComponent('#UWBlockProgressIssuesPopup-IssuesScreen-PreQuoteIssueTitle');
}

import { onApp } from "../../pages/gw/registry/onApp.js";
import { DesktopTabBar } from "../../pages/gw/generated/policycenter/pages/navigation/tabBar/DesktopTabBar.js";
import { setStepDescription } from "../../util/common/setStepDescription.js";

const pageNameStaticContent = require('../../util/common/pageNameStaticContent.js' );
const otherConstants = require('../../util/common/otherConstantsFile.js')
const onCCApp = new onApp("CC");
const onPCApp = new onApp("PC");
const onBCApp = new onApp("BC");
const onCMApp = new onApp("CM");
const desktopTabBar = new DesktopTabBar();
const stepDescription = new setStepDescription();

export class LoginScenario_Ext {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async loginWithDefaultUser_ext(fileObj, data) {
        try {
            switch (data.app) {
                case "PC":
                    await onPCApp.loginWithDefaultUser();
                    this.stepAction = stepDescription.setActionStep(otherConstants.LOGIN_TO_PC)
                    break;
                case "BC":
                    await onBCApp.loginWithDefaultUser();
                    this.stepAction = stepDescription.setActionStep(otherConstants.LOGIN_TO_BC)
                    break;
                case "CC":
                    await onCCApp.loginWithDefaultUser();
                    this.stepAction = stepDescription.setActionStep(otherConstants.LOGIN_TO_CC)
                    break;
                case "CM":
                    await onCMApp.loginWithDefaultUser();
                    this.stepAction = stepDescription.setActionStep(otherConstants.LOGIN_TO_CM)
                    break;
                default:
                // code block
            }
            this.stepER = stepDescription.setExpResultStep(otherConstants.VERIFY_LANDING_PAGE)
            if (await this.assertDesktopTabBarVisibility()) {
                this.stepAR = stepDescription.setActualResultStep(otherConstants.LOGIN_IS_SUCCESSFUL)
                this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
            }
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`Error in ${pageNameStaticContent.LANDINGPAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            throw (err)
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        
    }

    async loginWithRole_ext(fileObj, data) {
        try {
            switch (data.app) {
                case "PC":
                    await onPCApp.loginWithRole(data.role);
                    break;
                case "BC":
                    await onBCApp.loginWithRole(data.role);
                    break;
                case "CC":
                    await onCCApp.loginWithRole(data.role);
                    break;
                case "CM":
                    await onCMApp.loginWithRole(data.role);
                    break;
                default:
                // code block
            }
            this.stepAction = stepDescription.setActionStep(`Login to '${data.app}' with the '${data.role}' Role`)
            this.stepER = stepDescription.setExpResultStep(otherConstants.VERIFY_LANDING_PAGE)
            if (await this.assertDesktopTabBarVisibility()) {
                this.stepAR = stepDescription.setActualResultStep(otherConstants.LOGIN_IS_SUCCESSFUL)
                this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
            }
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`Error in ${pageNameStaticContent.LANDINGPAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            throw (err)
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }

    async assertDesktopTabBarVisibility() {
        if (await desktopTabBar.tabBarDesktopTab.component.with({visibilityCheck: true})().exists) {
            return true
        } else {
            return false

        }
    }

    async loginWithUser_ext(fileObj, data) {
        switch (data.app) {
            case "PC":
                await onPCApp.loginWithUser(data.agentUsername, data.passWord);
                break;
            case "BC":
                await onBCApp.loginWithUser(data.agentUsername, data.passWord);
                break;
            case "CC":
                await onCCApp.loginWithUser(data.agentUsername, data.passWord);
                break;
            case "CM":
                await onCMApp.loginWithUser(data.agentUsername, data.passWord);
                break;
            default:
            // code block
        }
        try {
            this.stepAction = `Login to '${data.app}' with the User: '${data.agentUsername}'`
            this.stepER = stepDescription.setExpResultStep(otherConstants.VERIFY_LANDING_PAGE)
            if (await this.assertDesktopTabBarVisibility()) {
                this.stepAR = stepDescription.setActualResultStep(otherConstants.LOGIN_IS_SUCCESSFUL)
                this.verdict = stepDescription.setVerdictStep(otherConstants.PASSED)
            }
        } catch (err) {
            this.stepAction = stepDescription.resetActionStep()
            this.stepER = stepDescription.resetExpResultStep()
            this.stepAR = stepDescription.setActualResultStep(`Error in ${pageNameStaticContent.LANDINGPAGE}`)
            this.verdict = stepDescription.setVerdictStep(otherConstants.FAILED)
            throw (err)
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
    }
}

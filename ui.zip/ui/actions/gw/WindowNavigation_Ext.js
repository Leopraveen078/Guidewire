import { onApp } from "../../pages/gw/registry/onApp.js";
import { captureScreenshot } from "../../util/common/helper.js";
import { ClientFunction, t } from "testcafe";

const onCCApp = new onApp("CC");
const onPCApp = new onApp("PC");
const onBCApp = new onApp("BC");
const onCMApp = new onApp("CM");

export class WindowNavigation_Ext {
    constructor() {
        this.stepAction = "Window Navigation:"
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async openNewWindow(fileObj) {
        try {
            this.stepAction = "Opening New Window<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Opened New Window successfully"
            await t.openWindow('about:blank'); // Opening a blank window first

            console.log(`New browser window opened`);
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on opening new window"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }

    }

    async openNewPCWindow(fileObj) {
        try {
            this.stepAction = "Opening New PC Window<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Opened New PC Window successfully"
            t.ctx.pcWindow = await t.openWindow('about:blank'); // Opening a blank window first
            await t.switchToWindow(t.ctx.pcWindow);
            await onPCApp.navigateToApp();

            console.log(`New PC browser window opened`);
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on opening new window for PC"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }

    }

    async openNewBCWindow(fileObj) {
        try {
            this.stepAction = "Opening New BC Window<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Opened New BC Window successfully"
            t.ctx.bcWindow = await t.openWindow('about:blank'); // Opening a blank window first
            await t.switchToWindow(t.ctx.bcWindow);
            await onBCApp.navigateToApp();

            console.log(`New BC browser window opened`);
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on opening new window for BC"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }

    }

    async openNewCCWindow(fileObj) {
        try {
            this.stepAction = "Opening New CC Window<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Opened New CC Window successfully"
            t.ctx.ccWindow = await t.openWindow('about:blank'); // Opening a blank window first
            await t.switchToWindow(t.ctx.ccWindow);
            await onCCApp.navigateToApp();

            console.log(`New CC browser window opened`);
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on opening new window for CC"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async openNewCMWindow(fileObj) {
        try {
            this.stepAction = "Opening New CM Window<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Opened New CM Window successfully"
            t.ctx.cmWindow = await t.openWindow('about:blank'); // Opening a blank window first
            await t.switchToWindow(t.ctx.cmWindow);
            await onCMApp.navigateToApp();

            console.log(`New CM browser window opened`);
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on opening new window for CM"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async loginToPolicyCenter(fileObj, data) {
        try {
            this.stepAction = "Logging into Policy Center with role as " + data +"<br>";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Successfully logged into Policy Center"
            await onPCApp.loginWithRole(data);

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on logging into PC"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async loginToBillingCenter(fileObj, data) {
        try {
            this.stepAction = "Logging into Billing Center with role as " + data +"<br>";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Successfully logged into Billing Center"
            await onBCApp.loginWithRole(data);

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on logging into BC"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async loginToClaimCenter(fileObj, data) {
        try {
            this.stepAction = "Logging into Claim Center with role as " + data +"<br>";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Successfully logged into Claim Center"
            await onCCApp.loginWithRole(data);

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on logging into CC"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async loginToContactManager(fileObj, data) {
        try {
            this.stepAction = "Logging into Contact Manager with role as " + data +"<br>";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Successfully logged into Contact Manager"
            await onCMApp.loginWithRole(data);

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on logging into CM"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async switchToPCWindow(fileObj) {
        try {
            this.stepAction = "Switching to Policy Center<br>";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Successfully switched to Policy Center"
            await t.switchToWindow(t.ctx.pcWindow);
            console.log("Switching to Policy Center")

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on switching to PC window"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async switchToBCWindow(fileObj) {
        try {
            this.stepAction = "Switching to Billing Center<br>";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Successfully switched to Billing Center"
            await t.switchToWindow(t.ctx.bcWindow);
            console.log("Switching to Billing Center")

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on switching to BC window"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async switchToCCWindow(fileObj) {
        try {
            this.stepAction = "Switching to Claim Center<br>";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Successfully switched to Claim Center"
            await t.switchToWindow(t.ctx.ccWindow);
            console.log("Switching to Claim Center")

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on switching to CC window"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async switchToCMWindow(fileObj) {
        try {
            this.stepAction = "Switching to Contact Manager<br>";
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = "Successfully switched to Contact Manager"
            await t.switchToWindow(t.ctx.cmWindow);
            console.log("Switching to Contact Manager")

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on switching to CM window"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async windowRefresh(fileObj) {
        try {
            await ClientFunction(() => {
                document.location.reload();
            })();
            
            console.log("Browser window refreshed")
            
            this.stepAction = "Refreshing Page"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Page Refresh Failed"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
        
    }
}

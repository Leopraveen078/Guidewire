import { t, Selector, ClientFunction } from "testcafe"
import { LoginPage } from "../../pages/gw/generated/LoginPage"

const loginPage = new LoginPage();

export class Application_Ext {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async saveApplicationDate(fileObj) {
        try {
            await t.wait(2000);
            const getPageUrl = ClientFunction(() => window.location.href);

            // application date appears only under PC
            if ((await getPageUrl()).includes("PolicyCenter.do")) {
                this.stepAction = "Save the Application Date"
                this.stepER = "Action step, verification N/A"

                await loginPage.tabBarWidgetSettings.click();

                let dateString = await loginPage.usernameDateLabel.component.innerText;
                // sample on screen = Allison Horsley(ahorsley) | Aug 19, 2024

                dateString = dateString.replaceAll(" ", "");

                let date = ((dateString.split("|")[1]).split(",")[0]).substring(3);
                let month = ((dateString.split("|")[1]).split(",")[0]).substring(0, 3);
                switch (month) {
                    case 'Jan': month = '01'; break;
                    case 'Feb': month = '02'; break;
                    case 'Mar': month = '03'; break;
                    case 'Apr': month = '04'; break;
                    case 'May': month = '05'; break;
                    case 'Jun': month = '06'; break;
                    case 'Aug': month = '08'; break;
                    case 'Sep': month = '09'; break;
                    case 'Oct': month = '10'; break;
                    case 'Nov': month = '11'; break;
                    case 'Dec': month = '12'; break;
                }
                let year = (dateString.split("|")[1]).split(",")[1];

                let dateValue = month + '/' + (('0' + date).slice(-2)) + '/' + year;
                console.log('Application Date - ' + dateValue);
                t.ctx.appDate = dateValue;

                await loginPage.tabBarWidgetSettings.click();

                this.stepAR = "Saved the application date - " + t.ctx.appDate;

                await t.wait(2000);

                await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            } else {
                console.log("Skipping save date action since its not PC.");
            }
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on saving application date"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async saveEnv(fileObj) {
        try {
            const getPageUrlFn = ClientFunction(() => window.location.href);
            const pageUrl = await getPageUrlFn();
            const env = pageUrl.split("-")[1];
            t.ctx.appEnv = env;
            console.log("** Environment here - " + t.ctx.appEnv + " **")
            console.log("---> " + pageUrl)

            this.stepAction = "Save the Enviroment"
            this.stepER = "Action step, verification N/A"
            this.stepAR = "Environment - " + t.ctx.appEnv + "<br>" + " -> " + pageUrl;
            this.verdict = ""
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on saving Env"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}

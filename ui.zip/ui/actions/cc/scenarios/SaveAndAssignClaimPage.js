
import { FNOLWizard } from "../../../pages/gw/generated/claimcenter/pages/claim/FNOLWizard.js";
import { NewContactPopup } from "../../../pages/gw/generated/claimcenter/pages/popup/New/NewContactPopup.js";
import { t } from "testcafe";
import { AddressValidationSelectPopup } from "../../../pages/gw/generated/claimcenter/pages/popup/Address/AddressValidationSelectPopup.js";
import { captureScreenshot, dateConversion, selectDropdown } from "../../../util/common/helper.js";

const fNOLWizard = new FNOLWizard();
const contactPopup = new NewContactPopup();
const addressValidationSelectPopup = new AddressValidationSelectPopup();


export class SaveAndAssignClaimPage {
    constructor() {
        this.pageName = ""
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await fNOLWizard.claimTab_BasicinformationScreen2_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async saveAndAssignClaim(fileObj, data) {
        try {
            this.pageName = "Step 2 of 2: Basic information Page"
            console.log();

            await this.confirmPageNavigation(fileObj);

            this.stepAction = "Click on 'Finish' button to create Claim"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            await fNOLWizard.fNOLWizardFinish.click();

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

}

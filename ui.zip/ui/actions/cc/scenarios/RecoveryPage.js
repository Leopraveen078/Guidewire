import {SearchTabBar} from "../../../pages/gw/generated/claimcenter/pages/navigation/tabBar/SearchTabBar";
//import { NewRecoverySet_Ext } from "../../../pages/cc/NewRecoverySet"
import { ClaimMenuActions } from "../../../pages/gw/generated/claimcenter/pages/navigation/menuActions/ClaimMenuActions"
import { RecoverySearch } from "../../../pages/gw/generated/claimcenter/pages/search/RecoverySearch"
import { t } from 'testcafe';

const searchTabBar = new SearchTabBar();
//const newRecoverySet_Ext = new NewRecoverySet_Ext();
const claimMenuActions = new ClaimMenuActions();
const recoverySearch = new RecoverySearch();

export class RecoveryPage {
    constructor() {}

    async createRecovery() {
        await claimMenuActions.claimClaimMenuActions.click();
        await claimMenuActions.claimMenuActions_NewTransactionClaimMenuActions_NewOtherTrans.click();
        await claimMenuActions.claimMenuActions_NewTransactionClaimMenuActions_NewOtherTrans.click(); //click twice instead of hover
        await claimMenuActions.claimMenuActions_NewOtherTransClaimMenuActions_NewTransaction_RecoverySet.click();
        await newRecoverySet_Ext.payerDropdown.selectNthOption(1);
        await newRecoverySet_Ext.newRecoverySetNewRecoveryScreenRecoveryDetailDVReserveLineInputSetReserveLine.selectFirstOptionWithValue('New...')
        await newRecoverySet_Ext.newRecoverySetNewRecoveryScreenRecoveryDetailDVReserveLineInputSetCostType.selectNthOption(1);
        await newRecoverySet_Ext.newRecoverySetNewRecoveryScreenRecoveryDetailDVReserveLineInputSetCostCategory.selectNthOption(1);
        await newRecoverySet_Ext.recoveryDetailDVRecoveryCategory.selectNthOption(1);
        await newRecoverySet_Ext.firstLineItemAmount.setValue("500");
        await newRecoverySet_Ext.newRecoveryScreenUpdate.click();
      }
    
      async navigateToSearchRecoveriesPage() {
        !await searchTabBar.tabBarSearchTab.component.hasClass('gw-hasOpenSubMenu') && await t.click(searchTabBar.tabBarSearchTab.component.find('div.gw-action--expand-button'));
        await searchTabBar.searchTabSearch_RecoverySearch.click();
      }
    
      async searchRecoveryByClaimNumber() {
        await recoverySearch.recoverySearchRequiredInputSetClaimNumber.setValue(data.claimNumber);
        await recoverySearch.recoverySearchRecoverySearchScreenRecoverySearchDVRecoverySearchOptionalInputSetDateSearchDateSearchRangeValue.selectOptionByLabel("Today");
        await recoverySearch.recoverySearchRecoverySearchScreenRecoverySearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
      }
    
      async getRecoverySearchResultCount() {
        let resultCount = await recoverySearch.recoverySearchScreenRecoverySearchResultsLV.rowCount();
    
        return resultCount;
      }

      async selectPayer() {
        let payerOption = newRecoverySet.recoveryDetailDVPayer.component.find('option');
        await t.click(newRecoverySet.recoveryDetailDVPayer.component).click(payerOption.nth(1));
      }
      
}
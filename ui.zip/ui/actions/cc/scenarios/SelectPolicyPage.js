import { ClaimTabBar_Ext } from "../../../pages/gw/generated/claimcenter/pages/ClaimTabBar_Ext";
import { FNOLWizard } from "../../../pages/gw/generated/claimcenter/pages/claim/FNOLWizard";
import { Selector, t } from "testcafe";
import { captureScreenshot, dateConversion, getTodayDateValue } from "../../../util/common/helper";

const claimTabBar = new ClaimTabBar_Ext();
const fNOLWizard = new FNOLWizard();

export class SelectPolicyPage {
    constructor() {
        this.pageName = "Search Policy Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await fNOLWizard.claimTab_SearchPolicyScreen_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async selectPolicyWithLossData(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            this.stepAction = "Enter Search Policy details as follows<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            console.log(`Policy Number: ${t.ctx.policyNumber}`);
            this.stepAction += "'Policy Number: " + t.ctx.policyNumber + "', <br>";
            await fNOLWizard.fNOLWizardFindPolicyPanelSetpolicyNumber.setValue(t.ctx.policyNumber);

            const lossDate = await dateConversion(data.Claim_LossDate, '');
            console.log('Claim Loss Date: ', lossDate);
            this.stepAction += "'Claim Loss Date: " + lossDate + "', <br>";
            await fNOLWizard.fNOLWizardFindPolicyPanelSetdate.setValue(lossDate);

            await fNOLWizard.fNOLWizardFindPolicyPanelSetSearch.click();

            t.ctx.insuredName = await claimTabBar.claimTab_SearchPolicy_InsuredName.component.innerText;
            console.log("insured Name: " + t.ctx.insuredName);

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            await fNOLWizard.fNOLWizardNext.click();


        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async openAccount() {
        await accountTabBar_Ext.tabBarAccountTab.click();
        await accountTabBar_Ext.tabBarAccountTab.component.hasClass('gw-hasOpenSubMenu') && await t.click(accountTabBar_Ext.tabBarAccountTab.component.find('div.gw-action--expand-button'));
        await accountTabBar_Ext.accountTabAccountTab_AccountNumberSearchItem_ext.setValue(data.accountNumber.toString());
        await accountTabBar_Ext.tabBarAccountTab_AccounNumberSearchItem_Button.click();
    }

    async checkAccountOverview() {
        const accountStatus = await summary.accountDetailsDetailViewTile_DVAccountStatus.getValue();
        await t.expect(accountStatus).notEql(null);
    }

    async clickUpdateButton() {
        if (await newPersonAccountScreen.forceDupCheckUpdateButton.component.visible) {
            await newPersonAccountScreen.forceDupCheckUpdateButton.click();
        }
        else {
            await newPersonAccountScreen.updateButton.click();
        }
    }

}
import { SearchTabBar } from "../../../pages/gw/generated/claimcenter/pages/navigation/tabBar/SearchTabBar";
import { SimpleClaimSearch } from "../../../pages/gw/generated/claimcenter/pages/search/claimSearchesGroup/SimpleClaimSearch";
import { captureScreenshot } from "../../../util/common/helper";
import { t } from "testcafe";

const searchTabBar = new SearchTabBar();
const simpleClaimSearch = new SimpleClaimSearch();

export class SearchPage {

    constructor() {

    }
    async searchForPolicy() {
        await searchTabBar.tabBarSearchTab.click();
        await simpleClaimSearch.simpleClaimSearchDVPolicyNumber.setValue(data.policyNumber);
        await simpleClaimSearch.simpleClaimSearchSimpleClaimSearchScreenSimpleClaimSearchDVClaimSearchAndResetInputSetSearch.click();
    }
    async searchForClaim() {
        await searchTabBar.tabBarSearchTab.click();
        await simpleClaimSearch.simpleClaimSearchDVPolicyNumber.setValue(data.policyNumber);
        await simpleClaimSearch.simpleClaimSearchSimpleClaimSearchScreenSimpleClaimSearchDVClaimSearchAndResetInputSetSearch.click();
    }
    async findPolicyWithPolicyNumberExists() {
        const rowFilter = "not(.gw-header-row):not(.gw-footer-row):not(.gw-isSmartHeader)";
        await t.expect(simpleClaimSearch.simpleClaimSearchScreenSimpleClaimSearchResultsLV.component.find("tr:" + rowFilter).count).gt(0);
        let rowCount = await simpleClaimSearch.simpleClaimSearchScreenSimpleClaimSearchResultsLV.rowCount();
        for (let i = 0; i < rowCount; i++) {
            let searchResultValue = await simpleClaimSearch.simpleClaimSearchScreenSimpleClaimSearchResultsLV.getTextFromCellByColumnName(i, 'Policy')
            if (searchResultValue == data.policyNumber) {
                return;
            }
        }

        throw new Error('Policy Number not found');

    }

    async SearchByClaimNumber(fileObj, data) {
        try {
            // Initialize step action and expected result
            this.stepAction = `Searching for Claim Number: ${data}<br>`;
            this.stepER = "Claim number should be searched successfully.";

            // Log the Claim number and perform the search actions
            console.log(`Search the Claim number: ${data}`);
            this.stepAction += `'ClaimNumber: ${data}', <br>`;

            // Expand the Search tab and enter the Claim number

            await searchTabBar.tabBarClaimTab_ExpandIcon.click();
            await searchTabBar.searchTabSearch_ClaimSearchesGroup.click();

            this.stepAction += "and search the Claim.";
            await simpleClaimSearch.simpleClaimSearchDVClaimNumber.setValue(data);
            await simpleClaimSearch.simpleClaimSearchSimpleClaimSearchScreenSimpleClaimSearchDVClaimSearchAndResetInputSetSearch.click();
            await simpleClaimSearch.simpleClaimSearchScreenSimpleClaimSearchResultsLV.clickOnCellByColumnName(0, "Claim");

            this.stepAR = "Successfully searched the Claim by number.";
            this.verdict = "Passed";

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error on Claim Search"
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }


}
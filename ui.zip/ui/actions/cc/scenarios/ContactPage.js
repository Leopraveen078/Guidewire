//import { AddressBookSearch_Ext } from "../../../pages/cc/AddressBookSearch_Ext";
//import contactData from "../../../util/cc/contactData";
import {t} from "testcafe"
import {retryActionUntil} from "@gtui/gt-ui-framework";
//const addressBookTabBar = new AddressBookTabBar();
//const addressBookSearch_Ext = new AddressBookSearch_Ext();

export class ContactPage {

    constructor(){
        
    }

    async searchForContact(identifier) {
        await addressBookTabBar.tabBarAddressBookTab.click();
        await addressBookSearch_Ext.addressBookSearchAddressBookSearchScreenAddressBookSearchDVSearchAndResetInputSetSearchLinksInputSetReset.click();
        console.log ("identifier = " + identifier)
        if (identifier == "Last Name") {
            await addressBookSearch_Ext.addressBookSearchAddressBookSearchScreenAddressBookSearchDVNameInputSetGlobalContactNameInputSetName.setValue(contactData.lastName);
            console.log("Searching with last name " + contactData.lastName)
        } else if (identifier == "City and State") {
            await addressBookSearch_Ext.addressBookSearchAddressBookSearchScreenAddressBookSearchDVCCAddressBookSearchLocationInputSetCCAddressInputSetglobalAddressContainerglobalAddressGlobalAddressInputSetCity.setValue(contactData.city);
            await addressBookSearch_Ext.addressBookSearchAddressBookSearchScreenAddressBookSearchDVCCAddressBookSearchLocationInputSetCCAddressInputSetglobalAddressContainerglobalAddressGlobalAddressInputSetState.click();
            await addressBookSearch_Ext.addressBookSearchAddressBookSearchScreenAddressBookSearchDVCCAddressBookSearchLocationInputSetCCAddressInputSetglobalAddressContainerglobalAddressGlobalAddressInputSetState.selectOptionByLabel(contactData.state);
            console.log("Searching with City and State " + contactData.city + " " + contactData.state)
        } else {
            await addressBookSearch_Ext.aBSPostalCode.setValue(contactData.postalCode);
            console.log("Searching with zip code " + contactData.postalCode)
        }
        await addressBookSearch_Ext.addressBookSearchAddressBookSearchScreenAddressBookSearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
    }

    async verifyContactFound() {
        async function actionFunction(){
            //Do nothing placeholder
        }

        async function comparisonFunction(){
            let rowCount = await addressBookSearch_Ext.addressBookSearchScreenAddressBookSearchLV.rowCount();
            return rowCount != 0;
        }

        await retryActionUntil(actionFunction, comparisonFunction, `Contact ${contactData.fullName} not found`,
            {maxRetry:5, interval: 5000, initialDelay: 5000});

        let rowCount = await addressBookSearch_Ext.addressBookSearchScreenAddressBookSearchLV.rowCount();

        for (let i = 0; i < rowCount; i++) {
            let searchResultValue = await addressBookSearch_Ext.addressBookSearchScreenAddressBookSearchLV.getTextFromCellByColumnName(i,'Name')
            console.log('searchResultValue 1 = ' + searchResultValue)
            if ( searchResultValue == contactData.fullName){
                return;
            }
        }

        if (await addressBookSearch_Ext.aBSPagingNext.component.withAttribute('aria-disabled', 'false').exists) {
            await addressBookSearch_Ext.aBSPagingNext.click();
            console.log ('Clicked next on contact list')
            await this.verifyContactFound();
            return;
        }

        throw new Error('Contact ' + contactData.fullName + ' not found');

    }
}
import { FNOLWizard } from "../../../pages/gw/generated/claimcenter/pages/claim/FNOLWizard";
import { NewClaimBasicInfoPage } from "../../../pages/cc/NewClaimBasicInfoPage";
import { NewClaimSaved_Ext } from "../../../pages/cc/NewClaimSaved_Ext";
import { CCTabBarHelper } from "../../../util/cc/CCTabBarHelper";
import { CCUtil } from "../../../util/cc/CCUtil";
import { t } from "testcafe";

const fNOLWizard = new FNOLWizard();
const newClaimSaved_Ext = new NewClaimSaved_Ext();
const newClaimBasicInfoPage = new NewClaimBasicInfoPage();
const ccTabBarHelper = new CCTabBarHelper();
const ccUtil = new CCUtil();
let claimDataMap = new Map();

export class FNOLPage {

    constructor(){
        
    }

    async createPAClaimUsingFNOLFullWizardForCCScenario() {
        await ccTabBarHelper.goToFNOLWizard();
        console.log("On FNOL Wizard Page 1 - Find Policy");
        await fNOLWizard.fNOLWizardFindPolicyPanelSetPolicyType.selectOptionByLabel('Personal Auto');
        await fNOLWizard.fNOLWizardFindPolicyPanelSetSearch.click();
        claimDataMap.set('Insured', await fNOLWizard.fNOLWizardFindPolicyPanelSetPolicyResultLV.getTextFromCell(0,2));
        data.policyNumber = await fNOLWizard.fNOLWizardFindPolicyPanelSetPolicyResultLV.getTextFromCell(0,1);
        await fNOLWizard.fNOLWizardFindPolicyPanelSetPolicyResultLV.clickOnCell(0,0);
        await fNOLWizard.fNOLWizardFindPolicyPanelSetClaim_LossDate.setValue(await ccUtil.getDateForToday());
        await fNOLWizard.fNOLWizardNext.click();

        console.log("On FNOL Wizard Page 2 - Basic Info");
        await newClaimBasicInfoPage.nameDropdown.selectOptionByLabel(claimDataMap.get('Insured'));
        await fNOLWizard.fNOLWizardNext.click();
        
        console.log("On FNOL Wizard Page 3 - Loss Details");
        await fNOLWizard.lossDetailsAddressDVClaim_LossCause.selectOptionByLabel('Collision with motor vehicle');
        await fNOLWizard.fNOLWizardFullWizardStepSetFNOLWizard_NewLossDetailsScreenLossDetailsAddressDVAddressDetailInputSetRefCCAddressInputSetglobalAddressContainerAddress_Picker
            .selectFirstOptionWithValue();
        await fNOLWizard.categorizationDVNotification_Fault.selectOptionByLabel('No fault');
        await fNOLWizard.fNOLWizardNext.click();
        
        console.log("On FNOL Wizard Page 4 - Services")
        await fNOLWizard.fNOLWizardNext.click();
        
        console.log("On FNOL Wizard Page 5 - Save & Assign Claim")
        await fNOLWizard.fNOLWizardFinish.click();
        data.claimNumber = await this.getClaimNumber();
        console.log("Created new claim with number: " + data.claimNumber )

        claimDataMap.set('ClaimNumber', await this.checkClaimSuccessfullyCreatedConfirmation());
        claimDataMap.set('AssignedUser', await this.getAssignedUserOfNewCreatedClaim());
        claimDataMap.set('AssignedGroup', await this.getAssignedGroupOfNewCreatedClaim());
        return claimDataMap;
    }

    async getClaimNumber() {
        const confirmationValue = await newClaimSaved_Ext.claimSavedPromptInfo.component.textContent;
        const claimNumber = confirmationValue.split(" ")[1];
        return claimNumber;
    }

    async checkClaimSuccessfullyCreatedConfirmation() {
		const confirmationValue = await newClaimSaved_Ext.claimSavedPromptInfo.component.innerText;
		await t.expect(confirmationValue).match(/^Claim \d{3}-\d{2}-\d{6} has been successfully saved\./,
			'New claim has not been successfully created');
		return confirmationValue.match(/\d{3}-\d{2}-\d{6}/).toString();
	}

    async getAssignedUserOfNewCreatedClaim() {
		const assignedUserValue = await newClaimSaved_Ext.newClaimSavedDVAssignedUser.getValue();
		const startIndex = assignedUserValue.indexOf(":") + 2;
		return assignedUserValue.substr(startIndex);
	}

    async getAssignedGroupOfNewCreatedClaim() {
		const assignedGroupValue = await newClaimSaved_Ext.newClaimSavedDVAssignedGroup.getValue();
		const startIndex = assignedGroupValue.indexOf(":") + 2;
		return assignedGroupValue.substr(startIndex);
	}
}

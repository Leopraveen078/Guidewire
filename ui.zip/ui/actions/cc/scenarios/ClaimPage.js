import { ClaimTabBar_Ext } from "../../../pages/gw/generated/claimcenter/pages/ClaimTabBar_Ext";
import { ClaimMenuLinks } from "../../../pages/gw/generated/claimcenter/pages/navigation/menuLinks/ClaimMenuLinks";
import { ClaimSummary } from "../../../pages/gw/generated/claimcenter/pages/claim/claimSummaryGroup/ClaimSummary";
import { AxeScanWrapper } from "@gtui/gt-ui-framework"
import { NewClaimSaved } from "../../../pages/gw/generated/claimcenter/pages/other/NewClaimSaved.js";
import { captureScreenshot } from "../../../util/common/helper";
import { t } from "testcafe"

const claimTabBar_Ext = new ClaimTabBar_Ext();
const claimMenuLinks = new ClaimMenuLinks();
const newClaimSaved = new NewClaimSaved();

export class ClaimPage {
  constructor() {
    this.stepAction = ""
    this.stepER = ""
    this.stepAR = ""
    this.verdict = ""
  }


  async confirmPageNavigation(fileObj) {
    this.stepAction = "Verification Step, Action N/A"
    this.stepER = `Verify that you are taken to the ${this.pageName}`
    if (await newClaimSaved.newClaimSaved_ttlbar.component.visible) {
      this.stepAR = `Successfully navigated to the ${this.pageName}`
      this.verdict = "Passed"
    } else {
      this.stepAR = `NOT able to navigate to the ${this.pageName}`
      this.verdict = "Failed"
      captureScreenshot();
    }
    await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
  }

  async initiateClaim(fileObj) {
    try {
      this.stepAction = "Navigate to claim creation page.."
      this.stepER = "Action Step, Verification N/A"
      this.stepAR = ""
      this.verdict = ""
      await claimTabBar_Ext.tabBarClaimTabMoreOptions.click();
      await claimTabBar_Ext.claimTabClaimTab_FNOLWizard.click();

      captureScreenshot();
      await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    } catch (err) {
      this.stepAction = ""
      this.stepER = ""
      this.stepAR = "Error in " + this.pageName
      this.verdict = "Failed"
      await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
      throw (err)
    }
  }

  async viewCreatedClaim(fileObj) {
    try {
      this.pageName = "New Claim Saved"

      await this.confirmPageNavigation(fileObj);

      captureScreenshot();

      this.stepAction = "Verification Step, Action N/A"
      this.stepER = "Verify that claim has been created"

      let claimNumber = await newClaimSaved.newClaimSaved_ClaimIssuedInfo.component.innerText;
      t.ctx.claimNumber = claimNumber.split(" ")[1];

      console.log("New Claim number - " + t.ctx.claimNumber);

      this.stepAR = "Successfully claim has been created - " + t.ctx.claimNumber
      this.verdict = "Passed"

      captureScreenshot();

      await newClaimSaved.newClaimSavedDVGoToClaim.click();

      await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)

      captureScreenshot();

    } catch (err) {
      this.stepAction = ""
      this.stepER = ""
      this.stepAR = "Error in " + this.pageName
      this.verdict = "Failed"
      await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
      throw (err)
    }
  }

  async openClaim() {
    await claimTabBar_Ext.tabBarClaimTab.click();
    await claimTabBar_Ext.tabBarClaimTabMoreOptions.click();
    await claimTabBar_Ext.tabBarClaimTabClaimTab_FindClaim.setValue(data.claimNumber);
    await claimTabBar_Ext.tabBarClaimTabClaimTab_FindClaimButton.click();
  }

  async checkOverview(t) {
    await claimMenuLinks.claim_ClaimSummaryGroupClaimSummaryGroup_ClaimSummary.click();
    //Accessibility Scanning 
    let claimSummary = AxeScanWrapper(ClaimSummary, t);
    const lossDate = await claimSummary.claimSummaryScreenLossDate.getValue();
    await t.expect(lossDate).notEql(null);
  }

  today() {
    let date = new Date();
    return date.toLocaleDateString("en-US", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
    });
  }
}
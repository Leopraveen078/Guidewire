import { NewClaimSaved } from "../../../pages/gw/generated/claimcenter/pages/other/NewClaimSaved.js";
import { ClaimMenuActions } from "../../../pages/gw/generated/claimcenter/pages/navigation/menuActions/ClaimMenuActions.js";
import { NewCreateCheckWizard } from "../../../pages/gw/generated/claimcenter/pages/NewCreateCheckWizard.js";
import { SearchTabBar } from "../../../pages/gw/generated/claimcenter/pages/navigation/tabBar/SearchTabBar.js";
import { PaymentSearch } from "../../../pages/gw/generated/claimcenter/pages/search/checkSearchGroup_Ext/PaymentSearch.js";
import { t } from "testcafe";

const newClaimSaved = new NewClaimSaved();
const claimMenuActions = new ClaimMenuActions();
const newCreateCheckWizard = new NewCreateCheckWizard();
const searchTabBar = new SearchTabBar();
const paymentSearch = new PaymentSearch();

export class CheckPage {
    constructor() {
    }

    async createACheck(type, category, paymentType, amount) {
        let invoiceNumberRandom = Math.floor(Math.random() * 99999999 + 10000000);
        data.invoiceNumber = invoiceNumberRandom.toString();

        await newClaimSaved.newClaimSavedDVGoToClaim.click();
        await claimMenuActions.claimClaimMenuActions.click();
        await claimMenuActions.claimMenuActions_NewTransactionClaimMenuActions_NewTransaction_CheckSet.click();
        await newCreateCheckWizard.payeeName.selectNthOption(1);
        await newCreateCheckWizard.nextButton.click();

        await newCreateCheckWizard.reserveLine.selectOptionByLabel('New');
        await newCreateCheckWizard.costType.selectOptionByLabel(type);
        await newCreateCheckWizard.costCategory.selectOptionByLabel(category);
        await newCreateCheckWizard.paymentType.selectOptionByLabel(paymentType);
        await newCreateCheckWizard.lineItemAmount.setValue(amount);
        await newCreateCheckWizard.nextButton.click();
        await newCreateCheckWizard.invoiceNumber.setValue(data.invoiceNumber);
        await newCreateCheckWizard.finishButton.click();
    }

    async searchCheckByClaimNumber(claimNumber) {
        !await searchTabBar.tabBarSearchTab.component.hasClass('gw-hasOpenSubMen') && await t.click(searchTabBar.tabBarSearchTab.component.find('div.gw-action--expand-button'));
        await searchTabBar.tabBarSearchTabSearch_CheckSearchGroup_ExtCheckSearchGroup_Ext_PaymentSearch.click();
        await paymentSearch.paymentSearchPaymentSearchScreenPaymentSearchDVSearchAndResetInputSetSearchLinksInputSetReset.click();
        await paymentSearch.paymentSearchRequiredInputSetClaimNumber.setValue(claimNumber);
        await paymentSearch.paymentSearchPaymentSearchScreenPaymentSearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
    }

    async searchCheckByInvoiceNumber(invoiceNumber) {
        !await searchTabBar.tabBarSearchTab.component.hasClass('gw-hasOpenSubMen') && await t.click(searchTabBar.tabBarSearchTab.component.find('div.gw-action--expand-button'));
        await searchTabBar.tabBarSearchTabSearch_CheckSearchGroup_ExtCheckSearchGroup_Ext_PaymentSearch.click();
        await paymentSearch.paymentSearchPaymentSearchScreenPaymentSearchDVSearchAndResetInputSetSearchLinksInputSetReset.click();
        await paymentSearch.paymentSearchRequiredInputSetInvoiceNumber.setValue(invoiceNumber);
        await paymentSearch.paymentSearchPaymentSearchScreenPaymentSearchDVSearchAndResetInputSetSearchLinksInputSetSearch.click();
    }

    async findCheckWithClaimNumberExists(claimNumber) {
        let rowCount = await paymentSearch.paymentSearchScreenCheckSearchResultsLV.rowCount();
        for (let i = 0; i < rowCount; i++) {
            let searchResultValue = await paymentSearch.paymentSearchScreenCheckSearchResultsLV.getTextFromCellByColumnName(i, 'Claim')
            if (searchResultValue == claimNumber) {
                return;
            }
        }

        throw new Error('Claim Number not found');

    }

}
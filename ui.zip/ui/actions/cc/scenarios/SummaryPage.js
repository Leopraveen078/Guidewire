import { ClaimSummary } from "../../../pages/gw/generated/claimcenter/pages/claim/claimSummaryGroup/ClaimSummary.js";
import { t } from "testcafe";
import { captureScreenshot } from "../../../util/common/helper.js";

const claimSummaryPage = new ClaimSummary();

export class SummaryPage {

    constructor() {
        this.pageName = "Summary Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await claimSummaryPage.claimSummary_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async expectedFNOLReserve(fileObj, data) {
        try {
            this.confirmPageNavigation(fileObj);

            const expectedFNOLReserve = data.Claim_FNOLReserve;

            const actualFNOLReserve = await claimSummaryPage.claimSummaryHeadlinePanelSetFNOLReserve.component.innerText;

            if (actualFNOLReserve.trim() !== expectedFNOLReserve) {
                this.stepAction = "Verification Step, Action N/A"
                this.stepER = "Verify that FNOL Reserve of " + data.Claim_FNOLReserve + " is set"
                this.stepAR = "FNOL Reserve seems invalid, expected number - " + expectedFNOLReserve + " but actual number is - " + actualFNOLReserve;
                this.verdict = "Failed"
                captureScreenshot();

            } else {
                this.stepAction = "Verification Step, Action N/A"
                this.stepER = "Verify that FNOL Reserve of " + expectedFNOLReserve + " is set"
                this.stepAR = "Successfully verified the FNOL reserve amount set to " + expectedFNOLReserve;
                this.verdict = "Passed"
            }

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }
}
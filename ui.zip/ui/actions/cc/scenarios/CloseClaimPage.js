
import { NewClaimSaved } from "../../../pages/gw/generated/claimcenter/pages/other/NewClaimSaved.js";
import { captureScreenshot, selectDropdown } from "../../../util/common/helper";
import { t, Selector } from "testcafe"
import { ClaimMenuActions } from "../../../pages/gw/generated/claimcenter/pages/navigation/menuActions/ClaimMenuActions.js";
import { CloseClaimPopup } from "../../../pages/gw/generated/claimcenter/pages/popup/Close/CloseClaimPopup.js";
import { ClaimMenuLinks } from "../../../pages/gw/generated/claimcenter/pages/navigation/menuLinks/ClaimMenuLinks.js";
import { ClaimStatus } from "../../../pages/gw/generated/claimcenter/pages/claim/claimSummaryGroup/ClaimStatus.js";
import { ClaimWorkplan } from "../../../pages/gw/generated/claimcenter/pages/claim/ClaimWorkplan.js";
import { FNOLWizard } from "../../../pages/gw/generated/claimcenter/pages/claim/FNOLWizard.js";


const newClaimSaved = new NewClaimSaved();
const claimMenuActions = new ClaimMenuActions();
const closeClaimPopup = new CloseClaimPopup();
const claimMenuLinks = new ClaimMenuLinks();
const claimStatus = new ClaimStatus();
const claimWorkplan = new ClaimWorkplan();
const fnolWizard = new FNOLWizard();

export class CloseClaimPage {
    constructor() {
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
        this.pageName = "Close Claim"
    }


    async navigateToCloseClaim(fileObj) {
        try {

            this.stepAction = "' Click On Action ', <br>";
            this.stepER = "Action Step, Verification N/A"

            await claimMenuActions.claimClaimMenuActions.click();
            this.stepAction += "and Click on Close Claim.', <br>";
            await claimMenuActions.claimMenuActions_ClaimActionsClaimMenuActions_CloseClaim.click();
            await t.wait(5000);

            captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }


    async initiateCloseClaim(fileObj, data) {
        try {
            
            this.stepAction = " Step to Close claim > Close Claim<br>";
            this.stepER = "Action Step, Verification N/A"

            console.log(`Note: ${data.CloseClaimInfoDV_Note}`);
            this.stepAction += "'Note: " + data.CloseClaimInfoDV_Note + "', <br>";
            await t.typeText(closeClaimPopup.closeClaimInfoDVNote_Selector, data.CloseClaimInfoDV_Note);

            console.log(`Outcome: ${data.CloseClaimInfoDV_OutCome}`);
            this.stepAction += "'Outcome: " + data.CloseClaimInfoDV_OutCome + "', <br>";
            await selectDropdown(closeClaimPopup.closeClaimInfoDVOutcome_Selector, data.CloseClaimInfoDV_OutCome);

            await captureScreenshot();
            this.stepAction += "Click on Close Claim button  <br>";
            await closeClaimPopup.closeClaimScreenUpdate.click();

            this.stepAR = "Successfully Closed Claim";
            this.verdict = "Passed";

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = "Unable to Close Claim"
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }


    async handleMandatoryClaimActivities(fileObj, data) {

        await this.updateMoldPresenceStatus(fileObj);
        await this.workPlanScreenMangaeActivities(fileObj, data);
    }

    async updateMoldPresenceStatus(fileObj) {
        try {
            this.stepAction = "Navigate to Status Screen and Click on No for Mold Present";
            this.stepER = "Action Step, Verification N/A";

            await claimMenuLinks.claim_ClaimSummaryGroupClaimSummaryGroup_ClaimStatus.click();

            this.stepAction += "'Click on Edit button', <br>";
            await claimStatus.claimStatusEdit.click();

            console.log(`Is Mold Present?: No`);
            this.stepAction += "'Is Mold Present?: No', <br>";
            await claimMenuActions.ClaimStatusInputSetmoldPresent1ewrsStatus_NoButton.click();

            this.stepER = "Mold Present set to 'No' Successfully";
            this.verdict = "Passed";

            captureScreenshot();
            await claimStatus.claimStatusUpdate.click();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
        } catch (err) {
            this.stepAction = "";
            this.stepER = "";
            this.stepAR = "Error in " + this.pageName + ": " + err.message;
            this.verdict = "Failed";
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);
            throw err;
        }
    }

    async workPlanScreenMangaeActivities(fileObj, data) {
        try {
            this.stepAction = "Navigate to WorkPlan and Complete Pending Activity";
            this.stepER = "Action Step, Verification N/A";

            await claimMenuLinks.menuLinksClaim_ClaimWorkplan.click();

            // Define the selector for the specific panel in Workplan screen
            const listRow = claimWorkplan.claimWorkplanScreenWorkplanLV;

            let rowCount = await listRow.rowCount();

            while (rowCount > 0) {
                // Click the specific Subject Column in the first row
                await t.click(listRow.component.find('#ClaimWorkplan-ClaimWorkplanScreen-WorkplanLV-0-Subject_button'));
                await t.wait(5000);
                await newClaimSaved.activityDetailWorksheetActivityDetailScreenttlBar.component.visible;

                // Scroll down to Text field
                await t.scrollBy(claimWorkplan.activityDetailWorksheetActivityDetailScreen_Text, 0, 50); // Scroll by 100 pixels until the element is visible

                //Enter Text in Activity Detail Screen
                await t.typeText(claimWorkplan.activityDetailWorksheetActivityDetailScreen_Text, data.ActivityDetailScreen_Text);

                //Click on Complete Button 
                await claimWorkplan.activityDetailWorksheetActivityDetailScreen_CompleteButton.click();

                // Determine the number of remaining rows in the workplan list
                rowCount = await listRow.rowCount();
            }

            this.stepAR = "All pending activity completed successfully";
            this.verdict = "Passed";
            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

        } catch (err) {
            this.stepAction = "Error Handling";
            this.stepER = "Action Step, Verification N/A";
            this.stepAR = "Error in " + this.pageName + ": " + err.message;
            this.verdict = "Failed";
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            throw err;
        }
    }

    async verifyClaimCloseStatus(fileObj, expectedStatus) {
        try {
            this.stepAction = "Verify Claim Close Status";
            this.stepER = `Expected status: "${expectedStatus}"`;

            let currentStatus = await fnolWizard.ClaimClaimInfoBarState_Status.component.innerText;

            // Check if currentStatus matches the expected status
            if (currentStatus !== expectedStatus) {
                throw new Error(`Expected status to be "${expectedStatus}", but got "${currentStatus}".`);
            }

            this.stepAR = `Claim status matched expected status: "${currentStatus}"`;
            this.verdict = "Passed";

            await captureScreenshot();
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            return currentStatus;

        } catch (err) {
            this.stepAR = `Error occurred: ${err.message}`;
            this.verdict = "Failed";
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict);

            throw err;
        }
    }
}






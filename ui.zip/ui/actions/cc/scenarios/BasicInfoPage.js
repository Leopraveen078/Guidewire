
import { FNOLWizard } from "../../../pages/gw/generated/claimcenter/pages/claim/FNOLWizard.js";
import { NewContactPopup } from "../../../pages/gw/generated/claimcenter/pages/popup/New/NewContactPopup.js";
import { NewClaimSaved } from "../../../pages/gw/generated/claimcenter/pages/other/NewClaimSaved.js";
import { t } from "testcafe";
import { AddressValidationSelectPopup } from "../../../pages/gw/generated/claimcenter/pages/popup/Address/AddressValidationSelectPopup.js";
import { captureScreenshot, dateConversion, selectDropdown } from "../../../util/common/helper.js";

const fNOLWizard = new FNOLWizard();
const contactPopup = new NewContactPopup();
const claimSaved = new NewClaimSaved();
const addressValidationSelectPopup = new AddressValidationSelectPopup();


export class BasicInfoPage {
    constructor() {
        this.pageName = "Step 1 of 2: Basic information Page"
        this.stepAction = ""
        this.stepER = ""
        this.stepAR = ""
        this.verdict = ""
    }

    async confirmPageNavigation(fileObj) {
        this.stepAction = "Verification Step, Action N/A"
        this.stepER = `Verify that you are taken to the ${this.pageName}`
        if (await fNOLWizard.claimTab_BasicinformationScreen1_ttlBar.component.visible) {
            this.stepAR = `Successfully navigated to the ${this.pageName}`
            this.verdict = "Passed"
        } else {
            this.stepAR = `NOT able to navigate to the ${this.pageName}`
            this.verdict = "Failed"
            captureScreenshot();
        }
        await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
    }

    async enterBasicInformationDetails(fileObj, data) {
        try {
            await this.confirmPageNavigation(fileObj);

            this.stepAction = "Enter Basic information details as follows<br>"
            this.stepER = "Action Step, Verification N/A"
            this.stepAR = ""
            this.verdict = ""

            const dateOfNotice = await dateConversion(data.Claim_DateOfNotice, '');
            console.log('Date of Notice: ', dateOfNotice);
            this.stepAction += "'Date of Notice: " + dateOfNotice + "', <br>";
            await fNOLWizard.newClaimWizard_MainContactsScreenNotification_ReportedDate.setValue(dateOfNotice);

            console.log(`ReportedBy Name: ` + t.ctx.insuredName);
            this.stepAction += "'ReportedBy Name: " + t.ctx.insuredName + "', <br>";
            await selectDropdown(fNOLWizard.newClaimPeople1DVClaim_ReportedByName_Selector, t.ctx.insuredName);

            console.log(`Is Insured Primary Phone number correct?: ${data.Claim_IsPrimNumCorrect}`);
            this.stepAction += "'Is Insured Primary Phone number correct?: " + data.Claim_IsPrimNumCorrect + "', <br>";
            if ((data.Claim_IsPrimNumCorrect != "") && (data.hasOwnProperty('Claim_IsPrimNumCorrect'))) {
                if (data.Claim_IsPrimNumCorrect.includes('Yes')) {
                    await fNOLWizard.newClaimPeople3DVMailing_Adr_Same_As_Loss_Location_YesButton.click();
                } else if (data.Claim_IsPrimNumCorrect.includes('No')) {
                    await fNOLWizard.newClaimPeople3DVMailing_Adr_Same_As_Loss_Location_NoButton.click();
                }
            }

            console.log(`Is Insured email correct?: ${data.Claim_IsEmailCorrect}`);
            this.stepAction += "'Is Insured email correct?: " + data.Claim_IsEmailCorrect + "', <br>";
            if ((data.Claim_IsEmailCorrect != "") && (data.hasOwnProperty('Claim_IsEmailCorrect'))) {
                if (data.Claim_IsEmailCorrect.includes('Yes')) {
                    await fNOLWizard.newClaimPeople3DVIs_Insured_Email_Correct_YesButton.click();
                } else if (data.Claim_IsEmailCorrect.includes('No')) {
                    await fNOLWizard.newClaimPeople3DVIs_Insured_Email_Correct_NoButton.click();
                }
            }

            captureScreenshot();

            console.log(`Will you be the primary contact for the claim?: ${data.Claim_YouBePrimContactClaim}`);
            this.stepAction += "'Will you be the primary contact for the claim?: " + data.Claim_YouBePrimContactClaim + "', <br>";
            if ((data.Claim_YouBePrimContactClaim != "") && (data.hasOwnProperty('Claim_YouBePrimContactClaim'))) {
                if (data.Claim_YouBePrimContactClaim.includes('Yes')) {
                    await fNOLWizard.newClaimPeople3DVIsPrimaryContact_YesButton.click();
                } else if (data.Claim_YouBePrimContactClaim.includes('No')) {
                    await fNOLWizard.newClaimPeople3DVIsPrimaryContact_NoButton.click();
                }
            }

            console.log(`Is there a property manager?: ${data.Claim_IsTherePropManager}`);
            this.stepAction += "'Is there a property manager?: " + data.Claim_IsTherePropManager + "', <br>";
            if ((data.Claim_IsTherePropManager != "") && (data.hasOwnProperty('Claim_IsTherePropManager'))) {
                if (data.Claim_IsTherePropManager.includes('Yes')) {
                    await fNOLWizard.newClaimPeople3DVIsPropertyManager_YesButton.click();
                } else if (data.Claim_IsTherePropManager.includes('No')) {
                    await fNOLWizard.newClaimPeople3DVIsPropertyManager_NoButton.click();
                }
            }

            console.log(`Description: ${data.Claim_Description}`);
            this.stepAction += "'Description: " + data.Claim_Description + "', <br>";
            await t.typeText(fNOLWizard.newClaimWizard_MainContactsScreenDescription, data.Claim_Description);

            console.log(`Loss Cause: ${data.Claim_LossCause}`);
            this.stepAction += "'Loss Cause: " + data.Claim_LossCause + "', <br>";
            await selectDropdown(fNOLWizard.newClaimWizard_MainContactsScreenClaim_LossCause_Selector, data.Claim_LossCause);

            console.log(`Sub-Loss Cause: ${data.Claim_SubLossCause}`);
            this.stepAction += "'Sub-Loss Cause: " + data.Claim_SubLossCause + "', <br>";
            await selectDropdown(fNOLWizard.newClaimWizard_MainContactsScreenClaim_SubLossCause_Selector, data.Claim_SubLossCause);

            captureScreenshot();
            
            await fNOLWizard.fNOLWizardNext.click();

            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
        } catch (err) {
            this.stepAction = ""
            this.stepER = ""
            this.stepAR = "Error in " + this.pageName
            this.verdict = "Failed"
            await fileObj.insertHtmlRow(this.stepAction, this.stepER, this.stepAR, this.verdict)
            throw (err)
        }
    }

    async namePersonCreation() {
        await fNOLWizard.fNOLWizardNameRelatedContactsMenuIcon.click();
        await fNOLWizard.claimContactInputMenuItemSetcreateNewPersoPickerMenuItem.click();
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPersonNameInputSetGlobalPersonNameInputSetFirstName.setValue(data.firstName);
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPersonNameInputSetGlobalPersonNameInputSetLastName.setValue(data.lastName);
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPersonContactInfoInputSetHomeGlobalPhoneInputSetNationalSubscriberNumber.setValue(data.home);
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPersonContactInfoInputSetCellGlobalPhoneInputSetNationalSubscriberNumber.setValue(data.mobileNmumber);
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPersonContactInfoInputSetPrimary.setValue(data.mail);
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPrimaryAddressInputSetCCAddressInputSetglobalAddressContainerglobalAddressGlobalAddressInputSetAddressLine1.setValue(data.addressLine1);
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPrimaryAddressInputSetCCAddressInputSetglobalAddressContainerglobalAddressGlobalAddressInputSetCity.setValue(data.cityText);
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPrimaryAddressInputSetCCAddressInputSetglobalAddressContainerglobalAddressGlobalAddressInputSetState.click();
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPrimaryAddressInputSetCCAddressInputSetglobalAddressContainerglobalAddressGlobalAddressInputSetState.selectNthOption(1);
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPrimaryAddressInputSetCCAddressInputSetglobalAddressContainerglobalAddressGlobalAddressInputSetPostalCode.setValue(data.zipCode);
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPrimaryAddressInputSetCCAddressInputSetglobalAddressContainerglobalAddressGlobalAddressInputSetopselector2.click();
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDVPrimaryAddressInputSetCCAddressInputSetglobalAddressContainerglobalAddressGlobalAddressInputSetopselector2.selectOptionByLabel("Standardize");
        await addressValidationSelectPopup.addressValidationSelectScreensaveStd.click();
        await contactPopup.newContactPopupContactDetailScreenContactBasicsDV_tbContactDetailToolbarButtonSetCustomUpdateButton.click();
    }

}
